-- =====================================================================
--  NEXUS CRÉDIT — v18 : + preuve de versement Wave (capture obligatoire) ; l'échéance démarre quand le client voit la preuve
--                      (au plus tard 24 h après le versement) ; contrat NXC-CONTRAT-2026-11-C (section 5)
--  v17 : + contacts d'urgence obligatoires (2 personnes, WhatsApp) + contrat NXC-CONTRAT-2026-11-B
--  v15 : + restitution de la garantie (suivi et notification)
--  v12 : + messagerie complète (vocaux, photos, documents) + bouton Urgence
--  v11 : + messagerie client ↔ admin + coordonnées de contact (WhatsApp, appel)
--  v10 : + rappels SMS automatiques + badge de fiabilité
--                      + preuve de signature (empreinte SHA-256, date serveur, IP) + index de vitesse
--  v9 : + notifications push (appli installée) + notes de satisfaction
--  v8 : un seul prêt actif par client + contrat lu et accepté obligatoire
--                     + échéance = date de signature + délai (contrat, section 5)
--                     + exigibilité au 4e jour de retard, majoration 2 500 FCFA/jour (section 6)
--  v7 : + rappels automatiques d'échéance + modification du profil
--  (contenu v6 ci-dessous)
--  v6 : sécurité + garantie simple + statuts + notifications
--                     + reçu numéroté + échéance au versement
--                     + validation serveur de tous les champs + anti-spam
--  (script complet : remplace nexus_v4 à v14, se lance par-dessus sans risque)
--
--  À exécuter dans Supabase → SQL Editor → Run. Peut être relancé sans risque.
--  ⚠️ Supprime les tables de test des versions précédentes (guarantee_shipments,
--     loan_repayments) : la v4 n'en a plus besoin.
--
--  Statuts d'une demande :
--    pending → guarantee_received → paid → repayment_requested → done
--    (+ rejected ; « Pas reçu » sur un remboursement remet la demande en paid)
-- =====================================================================

-- 0. NETTOYAGE DES VERSIONS PRÉCÉDENTES ---------------------------------
drop table if exists public.guarantee_shipments cascade;
drop table if exists public.loan_repayments cascade;
drop function if exists public.guarantee_declare_payment(uuid, text, text);
drop function if exists public.guarantee_confirm_handover(uuid);
drop function if exists public.guarantee_mark_ordered(uuid);
drop function if exists public.guarantee_set_wave(uuid, text);
drop function if exists public.guarantee_cancel(uuid);
drop function if exists public.repayment_declare(uuid, int, text, text);
drop function if exists public.repayment_review(uuid, boolean, text);
drop function if exists public.guarantee_before_insert() cascade;

-- 1. RÔLES -----------------------------------------------------------------
create or replace function public.is_admin()
returns boolean language sql security definer set search_path = public stable as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;
grant execute on function public.is_admin() to authenticated;

-- Profil créé automatiquement à l'inscription, toujours en rôle "client".
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, full_name, phone, role)
  values (new.id, new.email, new.raw_user_meta_data->>'full_name', new.raw_user_meta_data->>'phone', 'client')
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

alter table public.profiles enable row level security;
do $$ declare p record; begin
  for p in select policyname from pg_policies where schemaname = 'public' and tablename = 'profiles' loop
    execute format('drop policy %I on public.profiles', p.policyname);
  end loop;
end $$;
create policy "profil: lire le sien"   on public.profiles for select using (auth.uid() = id);
create policy "profil: admin lit tout" on public.profiles for select using (public.is_admin());
-- (aucune modification directe : un client ne peut jamais changer son rôle)
grant select on public.profiles to authenticated;

-- 2. PARAMÈTRES (votre numéro Wave + adresse de réception) ---------------
create table if not exists public.app_settings (
  id int primary key default 1 check (id = 1),
  updated_at timestamptz not null default now()
);
alter table public.app_settings add column if not exists wave_number      text not null default '786325275';
alter table public.app_settings add column if not exists wave_name        text not null default 'Nexus Crédit';
alter table public.app_settings add column if not exists receiver_name    text not null default 'Nexus Crédit';
alter table public.app_settings add column if not exists receiver_phone   text not null default '786325275';
alter table public.app_settings add column if not exists receiver_address text not null default '496 Rue Serigne Ousmane Mbacké Noreyni, Gueule Tapée, Dakar';
alter table public.app_settings add column if not exists receiver_note    text not null default 'Appelez à l''arrivée.';
insert into public.app_settings (id) values (1) on conflict (id) do nothing;

alter table public.app_settings enable row level security;
drop policy if exists "parametres: lecture" on public.app_settings;
create policy "parametres: lecture" on public.app_settings for select to authenticated using (true);
drop policy if exists "parametres: admin modifie" on public.app_settings;
create policy "parametres: admin modifie" on public.app_settings for update to authenticated
  using (public.is_admin()) with check (public.is_admin());
grant select, update on public.app_settings to authenticated;

-- 3. DEMANDES DE PRÊT ----------------------------------------------------
alter table public.requests add column if not exists created_at            timestamptz not null default now();
alter table public.requests add column if not exists updated_at            timestamptz not null default now();
alter table public.requests add column if not exists status                text not null default 'pending';
alter table public.requests add column if not exists rejection_reason      text;
alter table public.requests add column if not exists pdf_url               text;
alter table public.requests add column if not exists pdf_filename          text;
alter table public.requests add column if not exists signature_data_url    text;
alter table public.requests add column if not exists message               text;
-- garantie
alter table public.requests add column if not exists guarantee_name        text;
alter table public.requests add column if not exists guarantee_phone       text;
alter table public.requests add column if not exists wave_number           text;
alter table public.requests add column if not exists guarantee_declared_at timestamptz;
alter table public.requests add column if not exists guarantee_received_at timestamptz;
-- versement & remboursement
alter table public.requests add column if not exists paid_at               timestamptz;
alter table public.requests add column if not exists paid_amount           int;
alter table public.requests add column if not exists repayment_amount      int;
alter table public.requests add column if not exists repayment_ref         text;
alter table public.requests add column if not exists repayment_requested_at timestamptz;
alter table public.requests add column if not exists repaid_at             timestamptz;
alter table public.requests add column if not exists admin_note            text;
-- reçu de prêt (numéro attribué par la base au moment du versement)
alter table public.requests add column if not exists receipt_number        text;
alter table public.requests add column if not exists receipt_issued_at     timestamptz;
create unique index if not exists requests_receipt_number_key on public.requests(receipt_number) where receipt_number is not null;
create sequence if not exists public.receipt_seq;
-- acceptation du contrat (preuve horodatée)
alter table public.requests add column if not exists contract_version     text;
alter table public.requests add column if not exists contract_accepted_at timestamptz;

-- Anciens statuts → nouveaux
do $$ declare c record; begin
  for c in select conname from pg_constraint
           where conrelid = 'public.requests'::regclass and contype = 'c' and pg_get_constraintdef(oid) ilike '%status%' loop
    execute format('alter table public.requests drop constraint %I', c.conname);
  end loop;
end $$;
update public.requests set status = 'pending' where status = 'approved';
update public.requests set status = 'paid'    where status = 'ongoing';
update public.requests set status = 'pending' where status not in ('pending','guarantee_received','paid','repayment_requested','done','rejected');
alter table public.requests add constraint requests_status_check
  check (status in ('pending','guarantee_received','paid','repayment_requested','done','rejected'));

create index if not exists requests_client_idx  on public.requests(client_id);
create index if not exists requests_status_idx  on public.requests(status);
create index if not exists requests_created_idx on public.requests(created_at desc);

-- À la création : montants et dates calculés PAR LA BASE (le navigateur ne peut pas tricher).
create or replace function public.requests_before_insert()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then new.client_id := auth.uid(); end if;
  if new.client_id is null then raise exception 'Non connecté.'; end if;
  if new.montant is null or new.montant < 5000 or new.montant > 500000 then
    raise exception 'Montant invalide (5 000 à 500 000 FCFA).';
  end if;
  if new.duree not in (7, 14) then raise exception 'Durée invalide (7 ou 14 jours).'; end if;
  -- Validation de chaque champ (le navigateur ne fait que pré-vérifier)
  new.nom := trim(coalesce(new.nom, ''));
  new.garantie := trim(coalesce(new.garantie, ''));
  new.passeport := upper(regexp_replace(coalesce(new.passeport, ''), '[^A-Za-z0-9]', '', 'g'));
  new.message := nullif(trim(coalesce(new.message, '')), '');
  if length(new.nom) < 2 or length(new.nom) > 80 then raise exception 'Nom invalide (2 à 80 caractères).'; end if;
  if length(regexp_replace(coalesce(new.telephone, ''), '\D', '', 'g')) not between 9 and 15 then raise exception 'Téléphone invalide.'; end if;
  if length(new.passeport) not between 5 and 20 then raise exception 'Numéro de passeport invalide (5 à 20 lettres ou chiffres).'; end if;
  if length(new.garantie) < 2 or length(new.garantie) > 120 then raise exception 'Bien mis en garantie invalide (2 à 120 caractères).'; end if;
  if length(coalesce(new.message, '')) > 500 then raise exception 'Message trop long (500 caractères max).'; end if;
  if new.signature_data_url is null or new.signature_data_url not like 'data:image/png;base64,%'
     or length(new.signature_data_url) > 400000 then raise exception 'Signature invalide.'; end if;
  -- Contrat obligatoirement lu et accepté (version en vigueur)
  if coalesce(new.contract_version, '') <> 'NXC-CONTRAT-2026-11' then
    raise exception 'Vous devez lire et accepter le contrat avant d''envoyer votre demande.';
  end if;
  new.contract_accepted_at := now();
  -- Un seul prêt à la fois + anti-spam (5 demandes par 24 h)
  if not public.is_admin() then
    if exists (select 1 from public.requests where client_id = new.client_id
               and status in ('pending', 'guarantee_received', 'paid', 'repayment_requested')) then
      raise exception 'Vous avez déjà un prêt en cours. Vous pourrez faire une nouvelle demande une fois celui-ci remboursé.';
    end if;
    if (select count(*) from public.requests where client_id = new.client_id and created_at > now() - interval '24 hours') >= 5 then
      raise exception 'Trop de demandes aujourd''hui. Réessayez demain.';
    end if;
  end if;
  new.total := round(new.montant * case when new.duree = 7 then 1.25 else 1.35 end);
  new.date_remboursement := (current_date + new.duree);
  new.status := 'pending';
  new.created_at := now();
  new.rejection_reason := null; new.admin_note := null;
  new.guarantee_declared_at := null; new.guarantee_received_at := null;
  new.paid_at := null; new.paid_amount := null;
  new.repayment_amount := null; new.repayment_ref := null; new.repayment_requested_at := null; new.repaid_at := null;
  new.pdf_url := null;
  new.receipt_number := null; new.receipt_issued_at := null;
  return new;
end $$;
drop trigger if exists requests_insert on public.requests;
create trigger requests_insert before insert on public.requests
  for each row execute function public.requests_before_insert();

create or replace function public.touch_updated_at() returns trigger
language plpgsql as $$ begin new.updated_at = now(); return new; end; $$;
drop trigger if exists requests_touch on public.requests;
create trigger requests_touch before update on public.requests
  for each row execute function public.touch_updated_at();

-- Règles d'accès : on repart de zéro.
alter table public.requests enable row level security;
do $$ declare p record; begin
  for p in select policyname from pg_policies where schemaname = 'public' and tablename = 'requests' loop
    execute format('drop policy %I on public.requests', p.policyname);
  end loop;
end $$;
create policy "demande: client lit les siennes" on public.requests for select using (auth.uid() = client_id);
create policy "demande: admin lit tout"         on public.requests for select using (public.is_admin());
create policy "demande: client crée"            on public.requests for insert to authenticated with check (auth.uid() = client_id);
-- Aucune modification directe : clients ET admin passent par les fonctions ci-dessous.
revoke update, delete on public.requests from authenticated, anon;
grant select, insert on public.requests to authenticated;

-- 4. ACTIONS DU CLIENT ---------------------------------------------------
-- Formulaire court de la garantie (nom, téléphone, numéro Wave). Modifiable tant que le prêt n'est pas payé.
create or replace function public.guarantee_declare(p_request uuid, p_name text, p_phone text, p_wave text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if length(trim(coalesce(p_name, ''))) not between 2 and 80 then raise exception 'Indiquez votre nom (2 à 80 caractères).'; end if;
  if length(regexp_replace(coalesce(p_phone, ''), '\D', '', 'g')) not between 9 and 15 then raise exception 'Téléphone invalide.'; end if;
  if length(regexp_replace(coalesce(p_wave, ''), '\D', '', 'g')) not between 9 and 15 then raise exception 'Numéro Wave invalide.'; end if;
  update public.requests
     set guarantee_name = trim(p_name), guarantee_phone = trim(p_phone), wave_number = trim(p_wave),
         guarantee_declared_at = coalesce(guarantee_declared_at, now())
   where id = p_request and client_id = auth.uid() and status in ('pending', 'guarantee_received');
  if not found then raise exception 'Cette demande ne peut plus être modifiée.'; end if;
end $$;

-- Le client a renvoyé l'argent sur le Wave de Nexus.
create or replace function public.repayment_request(p_request uuid, p_amount int, p_ref text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if coalesce(p_amount, 0) < 100 or p_amount > 1000000 then raise exception 'Montant invalide.'; end if;
  if trim(coalesce(p_ref, '')) !~ '^[A-Za-z0-9_.-]{4,40}$' then
    raise exception 'Référence Wave invalide (4 à 40 lettres ou chiffres, sans espace).';
  end if;
  update public.requests
     set status = 'repayment_requested', repayment_amount = p_amount, repayment_ref = trim(p_ref),
         repayment_requested_at = now(), admin_note = null
   where id = p_request and client_id = auth.uid() and status = 'paid';
  if not found then raise exception 'Remboursement impossible pour cette demande.'; end if;
end $$;

-- Rattache le contrat généré (une seule fois, dans le dossier du client).
create or replace function public.contract_attach(p_request uuid, p_path text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_path is null or split_part(p_path, '/', 1) <> auth.uid()::text then raise exception 'Chemin invalide.'; end if;
  update public.requests set pdf_url = p_path, pdf_filename = 'contrat.html'
   where id = p_request and client_id = auth.uid() and pdf_url is null;
end $$;

-- 5. ACTIONS DE L'ADMIN (transitions contrôlées) --------------------------
create or replace function public.admin_set_status(p_request uuid, p_status text, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare r public.requests;
begin
  if not public.is_admin() then raise exception 'Réservé à l''administrateur.'; end if;
  p_note := left(nullif(trim(coalesce(p_note, '')), ''), 300);
  select * into r from public.requests where id = p_request for update;
  if r.id is null then raise exception 'Demande introuvable.'; end if;

  if (r.status, p_status) not in (
      ('pending', 'guarantee_received'), ('pending', 'rejected'),
      ('guarantee_received', 'pending'), ('guarantee_received', 'paid'), ('guarantee_received', 'rejected'),
      ('paid', 'repayment_requested'),
      ('repayment_requested', 'done'), ('repayment_requested', 'paid'),
      ('rejected', 'pending')) then
    raise exception 'Passage de « % » à « % » impossible.', r.status, p_status;
  end if;
  if p_status = 'paid' and r.status = 'guarantee_received' and r.wave_number is null then
    raise exception 'Le client n''a pas encore donné son numéro Wave.';
  end if;

  -- Échéance : date de signature + délai (contrat, section 5) — fixée à la création, jamais modifiée.

  update public.requests set
    status = p_status,
    admin_note = p_note,
    rejection_reason      = case when p_status = 'rejected' then coalesce(p_note, 'Non précisé') else null end,
    guarantee_received_at = case when p_status = 'guarantee_received' then now()
                                 when p_status = 'pending' then null else guarantee_received_at end,
    paid_at               = case when p_status = 'paid' and r.status = 'guarantee_received' then now() else paid_at end,
    paid_amount           = case when p_status = 'paid' and r.status = 'guarantee_received' then r.montant else paid_amount end,
    receipt_number        = case when p_status = 'paid' and r.receipt_number is null
                                 then 'NXC-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('public.receipt_seq')::text, 5, '0')
                                 else receipt_number end,
    receipt_issued_at     = case when p_status = 'paid' and r.receipt_issued_at is null then now() else receipt_issued_at end,
    repayment_requested_at= case when p_status = 'repayment_requested' then coalesce(repayment_requested_at, now()) else repayment_requested_at end,
    repaid_at             = case when p_status = 'done' then now() else repaid_at end
  where id = p_request;
end $$;

revoke all on function public.guarantee_declare(uuid, text, text, text) from public, anon;
revoke all on function public.repayment_request(uuid, int, text)       from public, anon;
revoke all on function public.contract_attach(uuid, text)              from public, anon;
revoke all on function public.admin_set_status(uuid, text, text)       from public, anon;
grant execute on function public.guarantee_declare(uuid, text, text, text) to authenticated;
grant execute on function public.repayment_request(uuid, int, text)       to authenticated;
grant execute on function public.contract_attach(uuid, text)              to authenticated;
grant execute on function public.admin_set_status(uuid, text, text)       to authenticated;

-- Reçus pour les prêts déjà versés avant la v5
update public.requests
   set receipt_number = 'NXC-' || to_char(coalesce(paid_at, now()), 'YYYY') || '-' || lpad(nextval('public.receipt_seq')::text, 5, '0'),
       receipt_issued_at = coalesce(paid_at, now())
 where receipt_number is null and status in ('paid', 'repayment_requested', 'done');

-- 6. NOTIFICATIONS ---------------------------------------------------------
-- Une ancienne table "notifications" (autre format) est mise de côté, pas supprimée.
do $$ begin
  if exists (select 1 from information_schema.tables where table_schema = 'public' and table_name = 'notifications')
     and not exists (select 1 from information_schema.columns
                     where table_schema = 'public' and table_name = 'notifications' and column_name = 'read_at') then
    if exists (select 1 from information_schema.tables where table_schema = 'public' and table_name = 'notifications_ancienne') then
      execute 'drop table public.notifications_ancienne cascade';
    end if;
    alter table public.notifications rename to notifications_ancienne;
    begin
      alter publication supabase_realtime drop table public.notifications_ancienne;
    exception when others then null;
    end;
  end if;
end $$;
create table if not exists public.notifications (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users(id) on delete cascade,
  request_id uuid references public.requests(id) on delete cascade,
  title      text not null,
  body       text,
  read_at    timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_idx on public.notifications(user_id, created_at desc);
alter table public.notifications enable row level security;
drop policy if exists "notif: lire les siennes" on public.notifications;
create policy "notif: lire les siennes" on public.notifications for select using (auth.uid() = user_id);
grant select on public.notifications to authenticated;

create or replace function public.notifications_mark_read()
returns void language sql security definer set search_path = public as $$
  update public.notifications set read_at = now() where user_id = auth.uid() and read_at is null;
$$;
revoke all on function public.notifications_mark_read() from public, anon;
grant execute on function public.notifications_mark_read() to authenticated;

create or replace function public.notify_admins(p_request uuid, p_title text, p_body text)
returns void language sql security definer set search_path = public as $$
  insert into public.notifications (user_id, request_id, title, body)
  select id, p_request, p_title, p_body from public.profiles where role = 'admin';
$$;
revoke all on function public.notify_admins(uuid, text, text) from public, anon, authenticated;

-- Une notification à chaque étape (client + admin)
create or replace function public.requests_notify()
returns trigger language plpgsql security definer set search_path = public as $$
declare who text := coalesce(new.nom, 'Un client');
        fmt text := replace(to_char(new.montant, 'FM999,999,999'), ',', ' ') || ' FCFA';
begin
  if tg_op = 'INSERT' then
    perform public.notify_admins(new.id, '📝 Nouvelle demande', who || ' demande ' || fmt || '.');
    return new;
  end if;

  if old.guarantee_declared_at is null and new.guarantee_declared_at is not null then
    perform public.notify_admins(new.id, '📦 Garantie en route', who || ' va vous envoyer sa garantie par Yango. Wave : ' || new.wave_number);
  elsif old.guarantee_declared_at is not null and new.wave_number is distinct from old.wave_number then
    perform public.notify_admins(new.id, '⚠️ Numéro Wave modifié', who || ' a changé son numéro Wave : ' || coalesce(old.wave_number, '—') || ' → ' || new.wave_number);
  end if;

  if new.status is distinct from old.status then
    insert into public.notifications (user_id, request_id, title, body)
    select new.client_id, new.id, t.title, t.body from (values
      ('guarantee_received', '📦 Garantie reçue', 'Nous avons bien reçu votre garantie. L''argent va être envoyé sur votre Wave.'),
      ('paid', '💸 Argent envoyé', fmt || ' envoyés sur votre Wave ' || coalesce(new.wave_number, '') || '. À rembourser : '
               || replace(to_char(new.total, 'FM999,999,999'), ',', ' ') || ' FCFA avant le ' || to_char(new.date_remboursement::date, 'DD/MM/YYYY')
               || '. Votre reçu est disponible.'),
      ('repayment_requested', '⏳ Remboursement en vérification', 'Nous vérifions la réception de votre remboursement.'),
      ('done', '🎉 Prêt remboursé', 'Merci ! Votre prêt est entièrement remboursé.'),
      ('rejected', '❌ Demande refusée', coalesce(new.rejection_reason, 'Votre demande a été refusée.')),
      ('pending', '↩️ Demande remise en attente', coalesce(new.admin_note, 'Votre demande est de nouveau en attente.'))
    ) as t(st, title, body)
    where t.st = new.status
      and not (new.status = 'paid' and old.status = 'repayment_requested');
    if new.status = 'paid' and old.status = 'repayment_requested' then
      insert into public.notifications (user_id, request_id, title, body)
      values (new.client_id, new.id, '⚠️ Remboursement non trouvé', coalesce(new.admin_note, 'Nous n''avons pas trouvé votre paiement. Vérifiez la référence.'));
    end if;
    if new.status = 'repayment_requested' then
      perform public.notify_admins(new.id, '💰 Remboursement déclaré',
        who || ' dit avoir envoyé ' || replace(to_char(new.repayment_amount, 'FM999,999,999'), ',', ' ') || ' FCFA (réf. ' || coalesce(new.repayment_ref, '?') || ').');
    end if;
  end if;
  return new;
end $$;
drop trigger if exists requests_notify_ins on public.requests;
create trigger requests_notify_ins after insert on public.requests for each row execute function public.requests_notify();
drop trigger if exists requests_notify_upd on public.requests;
create trigger requests_notify_upd after update on public.requests for each row execute function public.requests_notify();

-- 7. TEMPS RÉEL --------------------------------------------------------------
do $$ begin alter publication supabase_realtime add table public.notifications; exception when duplicate_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.requests;      exception when duplicate_object then null; end $$;

-- 8. CONTRATS (stockage privé) -------------------------------------------------
insert into storage.buckets (id, name, public) values ('contracts', 'contracts', false)
on conflict (id) do update set public = false;
drop policy if exists "contrat: client envoie" on storage.objects;
create policy "contrat: client envoie" on storage.objects for insert to authenticated
  with check (bucket_id = 'contracts' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "contrat: lecture" on storage.objects;
create policy "contrat: lecture" on storage.objects for select to authenticated
  using (bucket_id = 'contracts' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));


-- =====================================================================
-- 9. PROFIL : le client modifie son nom et son téléphone (jamais son rôle)
-- =====================================================================
create or replace function public.profile_update(p_name text, p_phone text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Non connecté.'; end if;
  if length(trim(coalesce(p_name, ''))) not between 2 and 80 then raise exception 'Nom invalide (2 à 80 caractères).'; end if;
  if length(regexp_replace(coalesce(p_phone, ''), '\D', '', 'g')) not between 9 and 15 then raise exception 'Téléphone invalide.'; end if;
  update public.profiles set full_name = trim(regexp_replace(p_name, '\s+', ' ', 'g')), phone = trim(p_phone) where id = auth.uid();
end $$;
revoke all on function public.profile_update(text, text) from public, anon;
grant execute on function public.profile_update(text, text) to authenticated;

-- =====================================================================
-- 10. RAPPELS D'ÉCHÉANCE AUTOMATIQUES
--     J-2, jour J, 1 jour de retard, 3 jours de retard (somme exigible).
--     Chaque rappel n'est envoyé qu'une fois par prêt (journal reminder_log).
-- =====================================================================
create table if not exists public.reminder_log (
  request_id uuid not null references public.requests(id) on delete cascade,
  kind       text not null,
  sent_at    timestamptz not null default now(),
  primary key (request_id, kind)
);
alter table public.reminder_log enable row level security;  -- aucune règle : invisible depuis le site

create or replace function public.send_due_reminders()
returns int language plpgsql security definer set search_path = public as $$
declare r record; d int; k text; t text; b text; n int := 0;
        amount text;
begin
  for r in select * from public.requests where status = 'paid' and date_remboursement is not null loop
    begin
      d := (r.date_remboursement::date - current_date);
    exception when others then continue;  -- date illisible : on ignore
    end;
    amount := replace(to_char(r.total, 'FM999,999,999'), ',', ' ') || ' FCFA';
    k := case when d between 1 and 2 then 'j2' when d = 0 then 'j0'
              when d between -3 and -1 then 'late1' when d <= -4 then 'late4' end;
    continue when k is null;
    insert into public.reminder_log (request_id, kind) values (r.id, k) on conflict do nothing;
    continue when not found;
    if k = 'j2' then
      t := '⏰ Échéance dans ' || d || ' jour' || case when d > 1 then 's' else '' end;
      b := 'Pensez à rembourser ' || amount || ' avant le ' || to_char(r.date_remboursement::date, 'DD/MM/YYYY') || '.';
    elsif k = 'j0' then
      t := '⚠️ Remboursement aujourd''hui';
      b := 'Votre prêt (' || amount || ') est à rembourser aujourd''hui.';
    elsif k = 'late1' then
      t := '⚠️ Remboursement en retard';
      b := 'Votre remboursement de ' || amount || ' était dû le ' || to_char(r.date_remboursement::date, 'DD/MM/YYYY')
           || '. Majoration : 2 500 FCFA par jour de retard. À partir du 4e jour de retard, la totalité de la somme due devient exigible immédiatement.';
      perform public.notify_admins(r.id, '⚠️ Retard de paiement', coalesce(r.nom, 'Un client') || ' : ' || amount || ' en retard.');
    else
      t := '🚨 Somme exigible immédiatement';
      b := 'Plus de 3 jours de retard : la totalité de la somme due (' || amount || ' + 2 500 FCFA par jour de retard) est exigible immédiatement, conformément à votre contrat (section 6).';
      perform public.notify_admins(r.id, '🚨 Retard de plus de 3 jours', coalesce(r.nom, 'Un client') || ' : ' || amount || ' + majorations, exigible immédiatement.');
    end if;
    insert into public.notifications (user_id, request_id, title, body) values (r.client_id, r.id, t, b);
    n := n + 1;
  end loop;
  return n;
end $$;
revoke all on function public.send_due_reminders() from public, anon, authenticated;

-- Secours : le tableau de bord admin déclenche aussi les rappels (au cas où pg_cron n'est pas activé).
create or replace function public.admin_run_reminders()
returns int language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Réservé à l''administrateur.'; end if;
  return public.send_due_reminders();
end $$;
revoke all on function public.admin_run_reminders() from public, anon;
grant execute on function public.admin_run_reminders() to authenticated;

-- Planification quotidienne à 8 h (heure de Dakar = UTC) si l'extension pg_cron est activée.
do $$
begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    begin
      perform cron.unschedule('nexus-rappels-echeance');
    exception when others then null;
    end;
    perform cron.schedule('nexus-rappels-echeance', '0 8 * * *', 'select public.send_due_reminders()');
  end if;
exception when others then
  raise notice 'Planification pg_cron impossible : %', sqlerrm;
end $$;


-- =====================================================================
-- 11. NOTIFICATIONS PUSH (appli installée : Android, iPhone iOS 16.4+, ordinateur)
-- =====================================================================
alter table public.app_settings add column if not exists vapid_public_key text not null default '';

create table if not exists public.push_subscriptions (
  endpoint   text primary key,
  user_id    uuid not null references auth.users(id) on delete cascade,
  p256dh     text not null,
  auth       text not null,
  user_agent text,
  created_at timestamptz not null default now()
);
create index if not exists push_subscriptions_user_idx on public.push_subscriptions(user_id);
alter table public.push_subscriptions enable row level security;  -- aucune règle : accès uniquement par les fonctions

create or replace function public.push_subscribe(p_endpoint text, p_p256dh text, p_auth text, p_ua text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Non connecté.'; end if;
  if p_endpoint !~ '^https://' or length(p_endpoint) > 1000 or length(coalesce(p_p256dh, '')) not between 20 and 200
     or length(coalesce(p_auth, '')) not between 10 and 100 then raise exception 'Abonnement invalide.'; end if;
  insert into public.push_subscriptions (endpoint, user_id, p256dh, auth, user_agent)
  values (p_endpoint, auth.uid(), p_p256dh, p_auth, left(p_ua, 300))
  on conflict (endpoint) do update set user_id = excluded.user_id, p256dh = excluded.p256dh, auth = excluded.auth, user_agent = excluded.user_agent;
end $$;

create or replace function public.push_unsubscribe(p_endpoint text)
returns void language sql security definer set search_path = public as $$
  delete from public.push_subscriptions where endpoint = p_endpoint and user_id = auth.uid();
$$;
revoke all on function public.push_subscribe(text, text, text, text) from public, anon;
revoke all on function public.push_unsubscribe(text) from public, anon;
grant execute on function public.push_subscribe(text, text, text, text) to authenticated;
grant execute on function public.push_unsubscribe(text) to authenticated;

-- Réglages privés (adresse de la fonction d'envoi + secret partagé) : invisibles depuis le site.
create schema if not exists private;
revoke all on schema private from public, anon, authenticated;
create table if not exists private.push_config (
  id           int primary key default 1 check (id = 1),
  function_url text,
  secret       text
);

-- À chaque notification : demande l'envoi push (si l'extension pg_net et la configuration existent).
create or replace function public.notifications_push()
returns trigger language plpgsql security definer set search_path = public, private as $$
declare c private.push_config;
begin
  select * into c from private.push_config where id = 1;
  if c.function_url is null or c.secret is null then return new; end if;
  if not exists (select 1 from pg_extension where extname = 'pg_net') then return new; end if;
  if not exists (select 1 from public.push_subscriptions where user_id = new.user_id) then return new; end if;
  execute 'select net.http_post(url := $1, body := $2, headers := $3)'
    using c.function_url, jsonb_build_object('notification_id', new.id),
          jsonb_build_object('Content-Type', 'application/json', 'x-push-secret', c.secret);
  return new;
exception when others then
  raise warning 'push non envoyé : %', sqlerrm;
  return new;
end $$;
drop trigger if exists notifications_push on public.notifications;
create trigger notifications_push after insert on public.notifications
  for each row execute function public.notifications_push();

-- =====================================================================
-- 12. NOTE DE SATISFACTION (après remboursement)
-- =====================================================================
create table if not exists public.loan_ratings (
  request_id uuid primary key references public.requests(id) on delete cascade,
  client_id  uuid not null references auth.users(id) on delete cascade,
  rating     int not null check (rating between 1 and 5),
  comment    text check (length(comment) <= 500),
  created_at timestamptz not null default now()
);
alter table public.loan_ratings enable row level security;
drop policy if exists "note: client lit les siennes" on public.loan_ratings;
create policy "note: client lit les siennes" on public.loan_ratings for select using (auth.uid() = client_id);
drop policy if exists "note: admin lit tout" on public.loan_ratings;
create policy "note: admin lit tout" on public.loan_ratings for select using (public.is_admin());
grant select on public.loan_ratings to authenticated;

create or replace function public.rate_loan(p_request uuid, p_rating int, p_comment text default null)
returns void language plpgsql security definer set search_path = public as $$
declare r public.requests;
begin
  select * into r from public.requests where id = p_request and client_id = auth.uid();
  if r.id is null then raise exception 'Demande introuvable.'; end if;
  if r.status <> 'done' then raise exception 'Vous pourrez noter ce prêt une fois remboursé.'; end if;
  if p_rating not between 1 and 5 then raise exception 'Note invalide (1 à 5).'; end if;
  insert into public.loan_ratings (request_id, client_id, rating, comment)
  values (r.id, auth.uid(), p_rating, nullif(left(trim(coalesce(p_comment, '')), 500), ''))
  on conflict (request_id) do update set rating = excluded.rating, comment = excluded.comment, created_at = now();
  perform public.notify_admins(r.id, '⭐ Nouvelle note : ' || p_rating || '/5', coalesce(r.nom, 'Un client') || coalesce(' : « ' || nullif(left(trim(coalesce(p_comment, '')), 120), '') || ' »', ''));
end $$;
revoke all on function public.rate_loan(uuid, int, text) from public, anon;
grant execute on function public.rate_loan(uuid, int, text) to authenticated;

-- Remboursement confirmé : invitation à noter
create or replace function public.requests_rating_invite()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'done' and old.status is distinct from 'done' then
    insert into public.notifications (user_id, request_id, title, body)
    values (new.client_id, new.id, '⭐ Votre avis compte', 'Notez votre expérience Nexus Crédit en un clic.');
  end if;
  return new;
end $$;
drop trigger if exists requests_rating_invite on public.requests;
create trigger requests_rating_invite after update on public.requests
  for each row execute function public.requests_rating_invite();


-- =====================================================================
-- 13. VITESSE : index pour les listes, l'échéancier et les rappels
-- =====================================================================
create index if not exists requests_client_created_idx on public.requests(client_id, created_at desc);
create index if not exists requests_active_due_idx on public.requests(status, date_remboursement)
  where status in ('paid', 'repayment_requested');
create index if not exists notifications_unread_idx on public.notifications(user_id) where read_at is null;
analyze public.requests;

-- Lecture sûre d'une date (la colonne a pu être du texte dans d'anciennes versions)
create or replace function public.safe_date(t text) returns date
language plpgsql immutable as $$
begin return t::date; exception when others then return null; end $$;

-- =====================================================================
-- 14. BADGE DE FIABILITÉ (vert / orange / rouge) — un seul appel pour tous les clients
-- =====================================================================
create or replace function public.admin_client_scores()
returns table (client_id uuid, total int, done int, late_repaid int, very_late int, late_now int, rejected int)
language sql stable security definer set search_path = public as $$
  select r.client_id,
         count(*)::int,
         count(*) filter (where r.status = 'done')::int,
         count(*) filter (where r.status = 'done' and (r.repaid_at at time zone 'UTC')::date > public.safe_date(r.date_remboursement::text))::int,
         count(*) filter (where r.status = 'done' and (r.repaid_at at time zone 'UTC')::date > public.safe_date(r.date_remboursement::text) + 3)::int,
         count(*) filter (where r.status = 'paid' and public.safe_date(r.date_remboursement::text) < current_date)::int,
         count(*) filter (where r.status = 'rejected')::int
  from public.requests r
  where public.is_admin()
  group by r.client_id
$$;
revoke all on function public.admin_client_scores() from public, anon;
grant execute on function public.admin_client_scores() to authenticated;

-- =====================================================================
-- 15. PREUVE DE SIGNATURE
--     À l'envoi : date et heure du serveur, empreinte SHA-256 de la signature,
--     adresse IP et appareil. Ensuite, signature et contrat ne peuvent plus être modifiés.
-- =====================================================================
alter table public.requests add column if not exists signed_at         timestamptz;
alter table public.requests add column if not exists signature_sha256  text;
alter table public.requests add column if not exists signed_ip         text;
alter table public.requests add column if not exists signed_ua         text;

create or replace function public.requests_sign_evidence()
returns trigger language plpgsql security definer set search_path = public as $$
declare h json;
begin
  new.signed_at := now();
  new.signature_sha256 := encode(sha256(convert_to(new.signature_data_url, 'UTF8')), 'hex');
  new.signed_ua := nullif(left(coalesce(new.signed_ua, ''), 300), '');
  begin
    h := current_setting('request.headers', true)::json;
    new.signed_ip := left(trim(split_part(coalesce(h->>'x-forwarded-for', h->>'x-real-ip', ''), ',', 1)), 60);
    new.signed_ip := nullif(new.signed_ip, '');
  exception when others then new.signed_ip := null;
  end;
  return new;
end $$;
drop trigger if exists requests_sign_evidence on public.requests;
create trigger requests_sign_evidence before insert on public.requests
  for each row execute function public.requests_sign_evidence();   -- s'exécute après requests_insert (ordre alphabétique)

create or replace function public.requests_lock_signature()
returns trigger language plpgsql as $$
begin
  if new.signature_data_url is distinct from old.signature_data_url
     or new.signature_sha256 is distinct from old.signature_sha256
     or new.signed_at is distinct from old.signed_at
     or new.contract_version is distinct from old.contract_version
     or new.contract_accepted_at is distinct from old.contract_accepted_at then
    raise exception 'La signature et le contrat signé ne peuvent pas être modifiés.';
  end if;
  return new;
end $$;
drop trigger if exists requests_lock_signature on public.requests;
create trigger requests_lock_signature before update on public.requests
  for each row execute function public.requests_lock_signature();

-- =====================================================================
-- 16. RAPPELS SMS AUTOMATIQUES
--     Les SMS partent par la fonction send-sms (Orange SMS API Sénégal ou Twilio).
--     Rien n'est envoyé tant que « SMS activés » n'est pas coché dans Paramètres.
-- =====================================================================
alter table public.app_settings add column if not exists sms_enabled     boolean not null default false;
alter table public.app_settings add column if not exists sms_sender_name text not null default '';

create table if not exists public.sms_log (
  id          bigserial primary key,
  request_id  uuid references public.requests(id) on delete cascade,
  kind        text not null,
  phone       text not null,
  message     text not null,
  status      text not null default 'queued' check (status in ('queued', 'sent', 'failed')),
  provider    text,
  provider_id text,
  error       text,
  attempts    int not null default 0,
  created_at  timestamptz not null default now(),
  sent_at     timestamptz
);
create index if not exists sms_log_request_idx on public.sms_log(request_id, created_at desc);
create index if not exists sms_log_created_idx on public.sms_log(created_at desc);
alter table public.sms_log enable row level security;
drop policy if exists "sms: admin lit" on public.sms_log;
create policy "sms: admin lit" on public.sms_log for select to authenticated using (public.is_admin());
revoke insert, update, delete on public.sms_log from authenticated, anon;
grant select on public.sms_log to authenticated;

create table if not exists private.sms_config (
  id           int primary key default 1 check (id = 1),
  function_url text,
  secret       text
);

-- Numéro au format international sans « + » (ex. 221771234567) ; null si invalide
create or replace function public.sms_phone(p text) returns text
language plpgsql immutable as $$
declare d text := regexp_replace(coalesce(p, ''), '\D', '', 'g');
begin
  if d like '00221%' then d := substr(d, 3); end if;
  if length(d) = 9 and left(d, 1) in ('7', '3') then return '221' || d; end if;
  if length(d) = 12 and left(d, 3) = '221' then return d; end if;
  return null;
end $$;

create or replace function public.fcfa_txt(n numeric) returns text
language sql immutable as $$ select replace(to_char(coalesce(n, 0), 'FM999,999,999'), ',', ' ') || ' FCFA' $$;

-- Textes courts, sans accent ni émoji : 1 SMS (160 caractères) au tarif le plus bas.
create or replace function public.sms_text(r public.requests, k text) returns text
language plpgsql stable security definer set search_path = public as $$
declare wave text; due date := public.safe_date(r.date_remboursement::text); late int;
begin
  select wave_number into wave from public.app_settings where id = 1;
  late := greatest(0, current_date - due);
  return left(case k
    when 'paid'  then 'NEXUS CREDIT: ' || public.fcfa_txt(coalesce(r.paid_amount, r.montant)) || ' envoyes sur votre Wave. A rembourser: '
                      || public.fcfa_txt(r.total) || ' avant le ' || to_char(due, 'DD/MM/YYYY') || '. Merci!'
    when 'j2'    then 'NEXUS CREDIT: rappel, ' || public.fcfa_txt(r.total) || ' a rembourser avant le ' || to_char(due, 'DD/MM/YYYY')
                      || '. Paiement Wave au ' || coalesce(wave, '') || '.'
    when 'j0'    then 'NEXUS CREDIT: votre remboursement de ' || public.fcfa_txt(r.total) || ' est du AUJOURD''HUI. Wave: ' || coalesce(wave, '') || '. Merci!'
    when 'late1' then 'NEXUS CREDIT: remboursement en retard depuis le ' || to_char(due, 'DD/MM') || '. Du ce jour: '
                      || public.fcfa_txt(r.total + 2500 * late) || ' (+2 500 FCFA/jour). Wave: ' || coalesce(wave, '')
    when 'late4' then 'NEXUS CREDIT: plus de 3 jours de retard. Totalite exigible immediatement: ' || public.fcfa_txt(r.total + 2500 * late)
                      || ' (contrat, section 6). Wave: ' || coalesce(wave, '')
    else 'NEXUS CREDIT: ' || k end, 160);
end $$;
revoke all on function public.sms_text(public.requests, text) from public, anon, authenticated;

create or replace function public.queue_sms(p_request uuid, p_kind text, p_phone text, p_message text, p_force boolean default false)
returns bigint language plpgsql security definer set search_path = public as $$
declare ph text := public.sms_phone(p_phone); new_id bigint;
begin
  if not p_force and not coalesce((select sms_enabled from public.app_settings where id = 1), false) then return null; end if;
  if ph is null then
    insert into public.sms_log (request_id, kind, phone, message, status, error)
    values (p_request, p_kind, coalesce(nullif(p_phone, ''), '?'), p_message, 'failed', 'Numéro de téléphone invalide.')
    returning id into new_id;
  else
    insert into public.sms_log (request_id, kind, phone, message) values (p_request, p_kind, ph, p_message)
    returning id into new_id;
  end if;
  return new_id;
end $$;
revoke all on function public.queue_sms(uuid, text, text, text, boolean) from public, anon, authenticated;

-- Chaque SMS « en file » est transmis à la fonction send-sms (si pg_net et la configuration existent)
create or replace function public.sms_dispatch()
returns trigger language plpgsql security definer set search_path = public, private as $$
declare c private.sms_config;
begin
  if new.status <> 'queued' then return new; end if;
  select * into c from private.sms_config where id = 1;
  if c.function_url is null or c.secret is null then return new; end if;
  if not exists (select 1 from pg_extension where extname = 'pg_net') then return new; end if;
  execute 'select net.http_post(url := $1, body := $2, headers := $3)'
    using c.function_url, jsonb_build_object('sms_id', new.id),
          jsonb_build_object('Content-Type', 'application/json', 'x-sms-secret', c.secret);
  return new;
exception when others then
  raise warning 'SMS non transmis : %', sqlerrm;
  return new;
end $$;
drop trigger if exists sms_dispatch on public.sms_log;
create trigger sms_dispatch after insert or update of status on public.sms_log
  for each row execute function public.sms_dispatch();

-- Argent envoyé : SMS de confirmation avec la date butoir
create or replace function public.requests_sms_paid()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'paid' and old.status is distinct from 'paid' then
    perform public.queue_sms(new.id, 'paid', coalesce(nullif(new.telephone, ''), new.wave_number), public.sms_text(new, 'paid'));
  end if;
  return new;
exception when others then
  raise warning 'SMS paiement : %', sqlerrm;
  return new;
end $$;
drop trigger if exists requests_sms_paid on public.requests;
create trigger requests_sms_paid after update on public.requests
  for each row execute function public.requests_sms_paid();

-- Rappels d'échéance : notification dans l'appli + SMS
create or replace function public.send_due_reminders()
returns int language plpgsql security definer set search_path = public as $$
declare r record; d int; k text; t text; b text; n int := 0;
        amount text;
begin
  for r in select * from public.requests where status = 'paid' and date_remboursement is not null loop
    d := public.safe_date(r.date_remboursement::text) - current_date;
    continue when d is null;  -- date illisible : on ignore
    amount := public.fcfa_txt(r.total);
    k := case when d between 1 and 2 then 'j2' when d = 0 then 'j0'
              when d between -3 and -1 then 'late1' when d <= -4 then 'late4' end;
    continue when k is null;
    insert into public.reminder_log (request_id, kind) values (r.id, k) on conflict do nothing;
    continue when not found;
    if k = 'j2' then
      t := '⏰ Échéance dans ' || d || ' jour' || case when d > 1 then 's' else '' end;
      b := 'Pensez à rembourser ' || amount || ' avant le ' || to_char(public.safe_date(r.date_remboursement::text), 'DD/MM/YYYY') || '.';
    elsif k = 'j0' then
      t := '⚠️ Remboursement aujourd''hui';
      b := 'Votre prêt (' || amount || ') est à rembourser aujourd''hui.';
    elsif k = 'late1' then
      t := '⚠️ Remboursement en retard';
      b := 'Votre remboursement de ' || amount || ' était dû le ' || to_char(public.safe_date(r.date_remboursement::text), 'DD/MM/YYYY')
           || '. Majoration : 2 500 FCFA par jour de retard. À partir du 4e jour de retard, la totalité de la somme due devient exigible immédiatement.';
      perform public.notify_admins(r.id, '⚠️ Retard de paiement', coalesce(r.nom, 'Un client') || ' : ' || amount || ' en retard.');
    else
      t := '🚨 Somme exigible immédiatement';
      b := 'Plus de 3 jours de retard : la totalité de la somme due (' || amount || ' + 2 500 FCFA par jour de retard) est exigible immédiatement, conformément à votre contrat (section 6).';
      perform public.notify_admins(r.id, '🚨 Retard de plus de 3 jours', coalesce(r.nom, 'Un client') || ' : ' || amount || ' + majorations, exigible immédiatement.');
    end if;
    insert into public.notifications (user_id, request_id, title, body) values (r.client_id, r.id, t, b);
    begin
      perform public.queue_sms(r.id, k, coalesce(nullif(r.telephone, ''), r.wave_number),
                               public.sms_text((select x from public.requests x where x.id = r.id), k));
    exception when others then raise warning 'SMS rappel : %', sqlerrm;
    end;
    n := n + 1;
  end loop;
  return n;
end $$;
revoke all on function public.send_due_reminders() from public, anon, authenticated;

-- Admin : SMS de test et renvoi d'un SMS échoué
create or replace function public.admin_test_sms(p_phone text)
returns bigint language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Réservé à l''administrateur.'; end if;
  if public.sms_phone(p_phone) is null then raise exception 'Numéro invalide (9 chiffres, ex. 77 123 45 67).'; end if;
  return public.queue_sms(null, 'test', p_phone, 'NEXUS CREDIT: SMS de test. Les rappels automatiques fonctionnent.', true);
end $$;
revoke all on function public.admin_test_sms(text) from public, anon;
grant execute on function public.admin_test_sms(text) to authenticated;

create or replace function public.admin_resend_sms(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Réservé à l''administrateur.'; end if;
  update public.sms_log set status = 'queued', error = null where id = p_id and status = 'failed' and phone <> '?';
  if not found then raise exception 'Ce SMS ne peut pas être renvoyé.'; end if;
end $$;
revoke all on function public.admin_resend_sms(bigint) from public, anon;
grant execute on function public.admin_resend_sms(bigint) to authenticated;


-- =====================================================================
-- 17. MESSAGERIE CLIENT ↔ ADMIN + COORDONNÉES DE CONTACT
-- =====================================================================
alter table public.app_settings add column if not exists contact_whatsapp text not null default '786649062';
-- Numéro WhatsApp de Nexus Crédit : +221 78 664 90 62 (modifiable ensuite dans Paramètres)
update public.app_settings set contact_whatsapp = '786649062' where id = 1 and contact_whatsapp = '786325275';
alter table public.app_settings add column if not exists contact_phone    text not null default '786325275';
alter table public.app_settings add column if not exists contact_hours    text not null default 'Tous les jours, de 8 h à 21 h';

-- Lien ouvert quand on touche une notification (ex. /client/messages)
alter table public.notifications add column if not exists link text;

-- Coordonnées visibles par tous, même sans compte (seulement ces 3 champs)
create or replace function public.public_contact()
returns table (whatsapp text, phone text, hours text)
language sql stable security definer set search_path = public as $$
  select contact_whatsapp, contact_phone, contact_hours from public.app_settings where id = 1
$$;
revoke all on function public.public_contact() from public;
grant execute on function public.public_contact() to anon, authenticated;

create table if not exists public.messages (
  id          bigserial primary key,
  client_id   uuid not null references public.profiles(id) on delete cascade,
  sender      text not null check (sender in ('client', 'admin')),
  author_id   uuid references public.profiles(id) on delete set null,
  category    text check (category in ('question', 'probleme', 'remboursement_anticipe', 'autre')),
  request_id  uuid references public.requests(id) on delete set null,
  body        text not null check (length(body) between 1 and 1000),
  created_at  timestamptz not null default now(),
  read_at     timestamptz
);
create index if not exists messages_client_idx on public.messages(client_id, created_at desc);
create index if not exists messages_unread_idx on public.messages(client_id, sender) where read_at is null;
alter table public.messages enable row level security;
drop policy if exists "messages: lecture" on public.messages;
create policy "messages: lecture" on public.messages for select to authenticated
  using (client_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.messages from authenticated, anon;
grant select on public.messages to authenticated;

-- Client → admin
create or replace function public.send_message(p_body text, p_category text default 'question', p_request uuid default null)
returns bigint language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); b text := trim(coalesce(p_body, '')); who text; new_id bigint;
begin
  if uid is null then raise exception 'Non connecté.'; end if;
  if public.is_admin() then raise exception 'Utilisez la réponse depuis la conversation du client.'; end if;
  if length(b) < 2 then raise exception 'Écrivez votre message.'; end if;
  if length(b) > 1000 then raise exception 'Message trop long (1 000 caractères max).'; end if;
  if coalesce(p_category, 'question') not in ('question', 'probleme', 'remboursement_anticipe', 'autre') then raise exception 'Sujet invalide.'; end if;
  if p_request is not null and not exists (select 1 from public.requests where id = p_request and client_id = uid) then
    raise exception 'Demande introuvable.';
  end if;
  if (select count(*) from public.messages where client_id = uid and sender = 'client' and created_at > now() - interval '1 hour') >= 20 then
    raise exception 'Trop de messages envoyés. Réessayez dans un moment ou écrivez-nous sur WhatsApp.';
  end if;
  insert into public.messages (client_id, sender, author_id, category, request_id, body)
  values (uid, 'client', uid, coalesce(p_category, 'question'), p_request, b) returning id into new_id;
  select coalesce(nullif(full_name, ''), email, 'Un client') into who from public.profiles where id = uid;
  insert into public.notifications (user_id, request_id, title, body, link)
  select id, p_request,
         case p_category when 'remboursement_anticipe' then '💬 Remboursement anticipé demandé' when 'probleme' then '💬 Problème signalé' else '💬 Nouveau message' end,
         who || ' : ' || left(b, 120), '/admin/messages/' || uid
  from public.profiles where role = 'admin';
  return new_id;
end $$;
revoke all on function public.send_message(text, text, uuid) from public, anon;
grant execute on function public.send_message(text, text, uuid) to authenticated;

-- Admin → client
create or replace function public.admin_reply(p_client uuid, p_body text)
returns bigint language plpgsql security definer set search_path = public as $$
declare b text := trim(coalesce(p_body, '')); new_id bigint;
begin
  if not public.is_admin() then raise exception 'Réservé à l''administrateur.'; end if;
  if not exists (select 1 from public.profiles where id = p_client and role = 'client') then raise exception 'Client introuvable.'; end if;
  if length(b) < 1 then raise exception 'Écrivez votre réponse.'; end if;
  if length(b) > 1000 then raise exception 'Message trop long (1 000 caractères max).'; end if;
  insert into public.messages (client_id, sender, author_id, body) values (p_client, 'admin', auth.uid(), b) returning id into new_id;
  update public.messages set read_at = now() where client_id = p_client and sender = 'client' and read_at is null;
  insert into public.notifications (user_id, title, body, link)
  values (p_client, '💬 Réponse de Nexus Crédit', left(b, 140), '/client/messages');
  return new_id;
end $$;
revoke all on function public.admin_reply(uuid, text) from public, anon;
grant execute on function public.admin_reply(uuid, text) to authenticated;

-- Marquer comme lus (le client lit les réponses ; l'admin lit les messages d'un client)
create or replace function public.mark_messages_read(p_client uuid default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if public.is_admin() then
    update public.messages set read_at = now() where client_id = p_client and sender = 'client' and read_at is null;
  else
    update public.messages set read_at = now() where client_id = auth.uid() and sender = 'admin' and read_at is null;
  end if;
end $$;
revoke all on function public.mark_messages_read(uuid) from public, anon;
grant execute on function public.mark_messages_read(uuid) to authenticated;

-- Admin : liste des conversations (une ligne par client, la plus récente en premier)
drop function if exists public.admin_conversations();
create or replace function public.admin_conversations()
returns table (client_id uuid, full_name text, phone text, email text, last_body text, last_sender text, last_at timestamptz, unread int, total int)
language sql stable security definer set search_path = public as $$
  select m.client_id, p.full_name, p.phone, p.email,
         (array_agg(m.body order by m.created_at desc))[1],
         (array_agg(m.sender order by m.created_at desc))[1],
         max(m.created_at),
         count(*) filter (where m.sender = 'client' and m.read_at is null)::int,
         count(*)::int
  from public.messages m join public.profiles p on p.id = m.client_id
  where public.is_admin()
  group by m.client_id, p.full_name, p.phone, p.email
  order by max(m.created_at) desc
  limit 300
$$;
revoke all on function public.admin_conversations() from public, anon;
grant execute on function public.admin_conversations() to authenticated;


-- =====================================================================
-- 18. MESSAGERIE COMPLÈTE : messages vocaux, photos et documents
--     Fichiers privés dans le stockage « chat », rangés par client :
--     chat/<id du client>/<fichier>. Seuls le client concerné et l'admin y ont accès.
-- =====================================================================
alter table public.messages add column if not exists kind text not null default 'text';
alter table public.messages add column if not exists attachment_path text;
alter table public.messages add column if not exists attachment_name text;
alter table public.messages add column if not exists attachment_mime text;
alter table public.messages add column if not exists attachment_size int;
alter table public.messages add column if not exists duration_ms int;
alter table public.messages drop constraint if exists messages_kind_check;
alter table public.messages add constraint messages_kind_check check (kind in ('text', 'voice', 'image', 'file'));
alter table public.messages alter column body drop not null;
alter table public.messages drop constraint if exists messages_body_check;
alter table public.messages drop constraint if exists messages_content_check;
alter table public.messages add constraint messages_content_check check (
  (kind = 'text' and body is not null and length(body) between 1 and 1000)
  or (kind <> 'text' and attachment_path is not null and (body is null or length(body) <= 1000)));

-- Coordonnées : seul le numéro d'urgence (WhatsApp) reste utilisé
update public.app_settings set contact_whatsapp = '786649062' where id = 1 and coalesce(contact_whatsapp, '') in ('', '786325275');

-- Stockage privé des pièces jointes (10 Mo max par fichier)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('chat', 'chat', false, 10485760, array[
  'audio/webm', 'audio/ogg', 'audio/mp4', 'audio/mpeg', 'audio/aac', 'audio/x-m4a', 'audio/wav',
  'image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif',
  'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'text/plain'])
on conflict (id) do update set public = false, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "chat: envoi" on storage.objects;
create policy "chat: envoi" on storage.objects for insert to authenticated
  with check (bucket_id = 'chat' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));
drop policy if exists "chat: lecture" on storage.objects;
create policy "chat: lecture" on storage.objects for select to authenticated
  using (bucket_id = 'chat' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));

-- Texte affiché dans les notifications et la liste des conversations
create or replace function public.message_preview(p_kind text, p_body text, p_name text default null, p_duration int default null)
returns text language sql immutable as $$
  select case p_kind
    when 'voice' then '🎤 Message vocal' || case when p_duration > 0 then ' (' || (p_duration / 60000) || ':' || lpad(((p_duration / 1000) % 60)::text, 2, '0') || ')' else '' end
    when 'image' then '📷 Photo' || case when coalesce(p_body, '') <> '' then ' : ' || left(p_body, 100) else '' end
    when 'file'  then '📎 ' || coalesce(p_name, 'Document')
    else left(coalesce(p_body, ''), 140) end
$$;

-- Vérifie une pièce jointe : elle doit être dans le dossier du client et déjà envoyée
create or replace function public.check_attachment(p_client uuid, p_kind text, p_path text, p_mime text, p_size int)
returns void language plpgsql stable security definer set search_path = public, storage as $$
begin
  if p_kind not in ('voice', 'image', 'file') then raise exception 'Type de message invalide.'; end if;
  if p_path is null or p_path !~ ('^' || p_client::text || '/[A-Za-z0-9._-]{1,120}$') then raise exception 'Pièce jointe invalide.'; end if;
  if not exists (select 1 from storage.objects where bucket_id = 'chat' and name = p_path) then raise exception 'Fichier introuvable : réessayez l''envoi.'; end if;
  if coalesce(p_size, 0) > 10485760 then raise exception 'Fichier trop lourd (10 Mo maximum).'; end if;
  if p_kind = 'voice' and coalesce(p_mime, '') !~ '^audio/' then raise exception 'Message vocal invalide.'; end if;
  if p_kind = 'image' and coalesce(p_mime, '') !~ '^image/' then raise exception 'Photo invalide.'; end if;
end $$;
revoke all on function public.check_attachment(uuid, text, text, text, int) from public, anon, authenticated;

drop function if exists public.send_message(text, text, uuid);
create or replace function public.send_message(
  p_body text default null, p_category text default 'question', p_request uuid default null,
  p_kind text default 'text', p_path text default null, p_name text default null, p_mime text default null,
  p_size int default null, p_duration int default null)
returns bigint language plpgsql security definer set search_path = public as $$
declare uid uuid := auth.uid(); b text := nullif(trim(coalesce(p_body, '')), ''); who text; new_id bigint; k text := coalesce(p_kind, 'text');
begin
  if uid is null then raise exception 'Non connecté.'; end if;
  if public.is_admin() then raise exception 'Utilisez la réponse depuis la conversation du client.'; end if;
  if k = 'text' then
    if b is null or length(b) < 2 then raise exception 'Écrivez votre message.'; end if;
  else
    perform public.check_attachment(uid, k, p_path, p_mime, p_size);
  end if;
  if length(coalesce(b, '')) > 1000 then raise exception 'Message trop long (1 000 caractères max).'; end if;
  if coalesce(p_category, 'question') not in ('question', 'probleme', 'remboursement_anticipe', 'autre') then raise exception 'Sujet invalide.'; end if;
  if p_request is not null and not exists (select 1 from public.requests where id = p_request and client_id = uid) then
    raise exception 'Demande introuvable.';
  end if;
  if (select count(*) from public.messages where client_id = uid and sender = 'client' and created_at > now() - interval '1 hour') >= 40 then
    raise exception 'Trop de messages envoyés. Réessayez dans un moment.';
  end if;
  insert into public.messages (client_id, sender, author_id, category, request_id, body, kind, attachment_path, attachment_name, attachment_mime, attachment_size, duration_ms)
  values (uid, 'client', uid, coalesce(p_category, 'question'), p_request, b, k,
          case when k = 'text' then null else p_path end, left(p_name, 120), left(p_mime, 100), p_size,
          case when k = 'voice' then least(greatest(coalesce(p_duration, 0), 0), 600000) end)
  returning id into new_id;
  select coalesce(nullif(full_name, ''), email, 'Un client') into who from public.profiles where id = uid;
  insert into public.notifications (user_id, request_id, title, body, link)
  select id, p_request,
         case p_category when 'remboursement_anticipe' then '💬 Remboursement anticipé demandé' when 'probleme' then '💬 Problème signalé' else '💬 Nouveau message' end,
         who || ' : ' || public.message_preview(k, b, p_name, p_duration), '/admin/messages/' || uid
  from public.profiles where role = 'admin';
  return new_id;
end $$;
revoke all on function public.send_message(text, text, uuid, text, text, text, text, int, int) from public, anon;
grant execute on function public.send_message(text, text, uuid, text, text, text, text, int, int) to authenticated;

drop function if exists public.admin_reply(uuid, text);
create or replace function public.admin_reply(
  p_client uuid, p_body text default null,
  p_kind text default 'text', p_path text default null, p_name text default null, p_mime text default null,
  p_size int default null, p_duration int default null)
returns bigint language plpgsql security definer set search_path = public as $$
declare b text := nullif(trim(coalesce(p_body, '')), ''); new_id bigint; k text := coalesce(p_kind, 'text');
begin
  if not public.is_admin() then raise exception 'Réservé à l''administrateur.'; end if;
  if not exists (select 1 from public.profiles where id = p_client and role = 'client') then raise exception 'Client introuvable.'; end if;
  if k = 'text' then
    if b is null then raise exception 'Écrivez votre réponse.'; end if;
  else
    perform public.check_attachment(p_client, k, p_path, p_mime, p_size);
  end if;
  if length(coalesce(b, '')) > 1000 then raise exception 'Message trop long (1 000 caractères max).'; end if;
  insert into public.messages (client_id, sender, author_id, body, kind, attachment_path, attachment_name, attachment_mime, attachment_size, duration_ms)
  values (p_client, 'admin', auth.uid(), b, k, case when k = 'text' then null else p_path end, left(p_name, 120), left(p_mime, 100), p_size,
          case when k = 'voice' then least(greatest(coalesce(p_duration, 0), 0), 600000) end)
  returning id into new_id;
  update public.messages set read_at = now() where client_id = p_client and sender = 'client' and read_at is null;
  insert into public.notifications (user_id, title, body, link)
  values (p_client, '💬 Nouveau message de Nexus Crédit', public.message_preview(k, b, p_name, p_duration), '/client/messages/chat');
  return new_id;
end $$;
revoke all on function public.admin_reply(uuid, text, text, text, text, text, int, int) from public, anon;
grant execute on function public.admin_reply(uuid, text, text, text, text, text, int, int) to authenticated;

-- Liste des conversations : aperçu adapté (vocal, photo, document) et nouvelles conversations en haut
drop function if exists public.admin_conversations();
create or replace function public.admin_conversations()
returns table (client_id uuid, full_name text, phone text, email text, last_body text, last_sender text, last_at timestamptz,
               last_read boolean, unread int, total int)
language sql stable security definer set search_path = public as $$
  select m.client_id, p.full_name, p.phone, p.email,
         (array_agg(public.message_preview(m.kind, m.body, m.attachment_name, m.duration_ms) order by m.created_at desc))[1],
         (array_agg(m.sender order by m.created_at desc))[1],
         max(m.created_at),
         (array_agg(m.read_at is not null order by m.created_at desc))[1],
         count(*) filter (where m.sender = 'client' and m.read_at is null)::int,
         count(*)::int
  from public.messages m join public.profiles p on p.id = m.client_id
  where public.is_admin()
  group by m.client_id, p.full_name, p.phone, p.email
  order by (count(*) filter (where m.sender = 'client' and m.read_at is null) > 0) desc, max(m.created_at) desc
  limit 300
$$;
revoke all on function public.admin_conversations() from public, anon;
grant execute on function public.admin_conversations() to authenticated;

-- Temps réel : les nouveaux messages arrivent instantanément dans la conversation ouverte
do $$ begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'messages') then
    execute 'alter publication supabase_realtime add table public.messages';
  end if;
end $$;


-- =====================================================================
-- 19. RESTITUTION DE LA GARANTIE
--     Après le remboursement (ou un refus), l'admin indique que le bien et le
--     passeport ont été rendus ; le client est notifié et le voit dans son suivi.
-- =====================================================================
alter table public.requests add column if not exists guarantee_returned_at timestamptz;
alter table public.requests add column if not exists guarantee_return_note text;

create or replace function public.admin_guarantee_returned(p_request uuid, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare r public.requests; n text := left(nullif(trim(coalesce(p_note, '')), ''), 200);
begin
  if not public.is_admin() then raise exception 'Réservé à l''administrateur.'; end if;
  select * into r from public.requests where id = p_request for update;
  if not found then raise exception 'Demande introuvable.'; end if;
  if r.status not in ('done', 'rejected') then raise exception 'La garantie se rend une fois le prêt remboursé (ou la demande refusée).'; end if;
  if r.guarantee_received_at is null and r.status = 'rejected' then raise exception 'Aucune garantie n''a été reçue pour cette demande.'; end if;
  if r.guarantee_returned_at is not null then raise exception 'Garantie déjà indiquée comme restituée.'; end if;
  update public.requests set guarantee_returned_at = now(), guarantee_return_note = n where id = p_request;
  insert into public.notifications (user_id, request_id, title, body)
  values (r.client_id, r.id, '📦 Garantie restituée',
          'Votre garantie (' || coalesce(r.garantie, 'bien') || ' et passeport) vous a été rendue.' || coalesce(' ' || n, '') || ' Merci pour votre confiance !');
end $$;
revoke all on function public.admin_guarantee_returned(uuid, text) from public, anon;
grant execute on function public.admin_guarantee_returned(uuid, text) to authenticated;


-- =====================================================================
-- 20. CONTACTS D'URGENCE (v17)
--     Deux personnes à joindre sur WhatsApp en cas de non-remboursement.
--     Obligatoires à chaque nouvelle demande ; mentionnés dans le contrat
--     (nouvelle version NXC-CONTRAT-2026-11-B). Visibles par l'admin.
-- =====================================================================
alter table public.requests add column if not exists contact1_name  text;
alter table public.requests add column if not exists contact1_phone text;
alter table public.requests add column if not exists contact2_name  text;
alter table public.requests add column if not exists contact2_phone text;

create or replace function public.requests_before_insert()
returns trigger language plpgsql security definer set search_path = public as $$
declare c1 text; c2 text; me text;
begin
  if not public.is_admin() then new.client_id := auth.uid(); end if;
  if new.client_id is null then raise exception 'Non connecté.'; end if;
  if new.montant is null or new.montant < 5000 or new.montant > 500000 then
    raise exception 'Montant invalide (5 000 à 500 000 FCFA).';
  end if;
  if new.duree not in (7, 14) then raise exception 'Durée invalide (7 ou 14 jours).'; end if;
  -- Validation de chaque champ (le navigateur ne fait que pré-vérifier)
  new.nom := trim(coalesce(new.nom, ''));
  new.garantie := trim(coalesce(new.garantie, ''));
  new.passeport := upper(regexp_replace(coalesce(new.passeport, ''), '[^A-Za-z0-9]', '', 'g'));
  new.message := nullif(trim(coalesce(new.message, '')), '');
  if length(new.nom) < 2 or length(new.nom) > 80 then raise exception 'Nom invalide (2 à 80 caractères).'; end if;
  if length(regexp_replace(coalesce(new.telephone, ''), '\D', '', 'g')) not between 9 and 15 then raise exception 'Téléphone invalide.'; end if;
  if length(new.passeport) not between 5 and 20 then raise exception 'Numéro de passeport invalide (5 à 20 lettres ou chiffres).'; end if;
  if length(new.garantie) < 2 or length(new.garantie) > 120 then raise exception 'Bien mis en garantie invalide (2 à 120 caractères).'; end if;
  if length(coalesce(new.message, '')) > 500 then raise exception 'Message trop long (500 caractères max).'; end if;
  -- Contacts d'urgence : 2 personnes obligatoires, numéros WhatsApp distincts
  new.contact1_name := regexp_replace(trim(coalesce(new.contact1_name, '')), '\s+', ' ', 'g');
  new.contact2_name := regexp_replace(trim(coalesce(new.contact2_name, '')), '\s+', ' ', 'g');
  new.contact1_phone := regexp_replace(coalesce(new.contact1_phone, ''), '\D', '', 'g');
  new.contact2_phone := regexp_replace(coalesce(new.contact2_phone, ''), '\D', '', 'g');
  if length(new.contact1_name) not between 2 and 80 then raise exception 'Contact d''urgence 1 : indiquez le nom de la personne.'; end if;
  if length(new.contact2_name) not between 2 and 80 then raise exception 'Contact d''urgence 2 : indiquez le nom de la personne.'; end if;
  if length(new.contact1_phone) not between 9 and 15 then raise exception 'Contact d''urgence 1 : numéro WhatsApp invalide.'; end if;
  if length(new.contact2_phone) not between 9 and 15 then raise exception 'Contact d''urgence 2 : numéro WhatsApp invalide.'; end if;
  c1 := right(new.contact1_phone, 9); c2 := right(new.contact2_phone, 9);
  me := right(regexp_replace(coalesce(new.telephone, ''), '\D', '', 'g'), 9);
  if c1 = c2 then raise exception 'Les deux contacts d''urgence doivent avoir des numéros différents.'; end if;
  if c1 = me or c2 = me then raise exception 'Un contact d''urgence doit être une autre personne que vous (numéro différent du vôtre).'; end if;
  if new.signature_data_url is null or new.signature_data_url not like 'data:image/png;base64,%'
     or length(new.signature_data_url) > 400000 then raise exception 'Signature invalide.'; end if;
  -- Contrat obligatoirement lu et accepté (version en vigueur, qui mentionne les contacts d'urgence)
  if coalesce(new.contract_version, '') <> 'NXC-CONTRAT-2026-11-C' then
    raise exception 'Vous devez lire et accepter le contrat avant d''envoyer votre demande. Actualisez l''application si le problème persiste.';
  end if;
  new.contract_accepted_at := now();
  -- Un seul prêt à la fois + anti-spam (5 demandes par 24 h)
  if not public.is_admin() then
    if exists (select 1 from public.requests where client_id = new.client_id
               and status in ('pending', 'guarantee_received', 'paid', 'repayment_requested')) then
      raise exception 'Vous avez déjà un prêt en cours. Vous pourrez faire une nouvelle demande une fois celui-ci remboursé.';
    end if;
    if (select count(*) from public.requests where client_id = new.client_id and created_at > now() - interval '24 hours') >= 5 then
      raise exception 'Trop de demandes aujourd''hui. Réessayez demain.';
    end if;
  end if;
  new.total := round(new.montant * case when new.duree = 7 then 1.25 else 1.35 end);
  new.date_remboursement := (current_date + new.duree);
  new.status := 'pending';
  new.created_at := now();
  new.rejection_reason := null; new.admin_note := null;
  new.guarantee_declared_at := null; new.guarantee_received_at := null;
  new.paid_at := null; new.paid_amount := null;
  new.repayment_amount := null; new.repayment_ref := null; new.repayment_requested_at := null; new.repaid_at := null;
  new.pdf_url := null;
  new.receipt_number := null; new.receipt_issued_at := null;
  new.guarantee_returned_at := null; new.guarantee_return_note := null;
  return new;
end $$;

-- Les contacts ne peuvent plus être modifiés après la signature (ils font partie du contrat)
create or replace function public.requests_lock_contacts()
returns trigger language plpgsql as $$
begin
  if (new.contact1_name, new.contact1_phone, new.contact2_name, new.contact2_phone)
     is distinct from (old.contact1_name, old.contact1_phone, old.contact2_name, old.contact2_phone) then
    raise exception 'Les contacts d''urgence font partie du contrat signé et ne peuvent pas être modifiés.';
  end if;
  return new;
end $$;
drop trigger if exists requests_lock_contacts on public.requests;
create trigger requests_lock_contacts before update on public.requests
  for each row execute function public.requests_lock_contacts();


-- =====================================================================
-- 21. PREUVE DE VERSEMENT WAVE (v18)
--     L'admin joint obligatoirement la capture de son reçu Wave pour passer
--     une demande en « Payé ». Le client la voit en grand ; l'échéance
--     (contrat, section 5) démarre au moment où il la voit, et au plus tard
--     24 heures après le versement s'il ne l'a pas ouverte.
-- =====================================================================
alter table public.requests add column if not exists payment_proof_path text;
alter table public.requests add column if not exists payment_proof_at   timestamptz;
alter table public.requests add column if not exists proof_viewed_at    timestamptz;
alter table public.requests add column if not exists due_starts_at      timestamptz;

-- Versement : capture obligatoire (déjà envoyée dans le stockage privé, dossier du client)
create or replace function public.admin_mark_paid(p_request uuid, p_proof_path text)
returns void language plpgsql security definer set search_path = public, storage as $$
declare r public.requests; starts timestamptz := now() + interval '24 hours';
begin
  if not public.is_admin() then raise exception 'Réservé à l''administrateur.'; end if;
  select * into r from public.requests where id = p_request for update;
  if r.id is null then raise exception 'Demande introuvable.'; end if;
  if r.status <> 'guarantee_received' then raise exception 'Seule une demande « Garantie reçue » peut être marquée comme payée.'; end if;
  if r.wave_number is null then raise exception 'Le client n''a pas encore donné son numéro Wave.'; end if;
  if coalesce(p_proof_path, '') = '' or split_part(p_proof_path, '/', 1) <> r.client_id::text then
    raise exception 'Joignez la capture d''écran de votre reçu Wave.';
  end if;
  if not exists (select 1 from storage.objects where bucket_id = 'chat' and name = p_proof_path) then
    raise exception 'La capture du reçu Wave n''a pas été reçue. Réessayez.';
  end if;
  -- Échéance provisoire = départ automatique (24 h après le versement) ; avancée si le client voit la preuve avant.
  update public.requests set payment_proof_path = p_proof_path, payment_proof_at = now(), proof_viewed_at = null,
         due_starts_at = starts, date_remboursement = (starts at time zone 'Africa/Dakar')::date + r.duree
   where id = p_request;
  perform public.admin_set_status(p_request, 'paid', null);
end $$;
revoke all on function public.admin_mark_paid(uuid, text) from public, anon;
grant execute on function public.admin_mark_paid(uuid, text) to authenticated;

-- Le client a vu la preuve : l'échéance démarre maintenant (jamais plus tard que le départ automatique)
drop function if exists public.client_proof_seen(uuid);
create or replace function public.client_proof_seen(p_request uuid)
returns text language plpgsql security definer set search_path = public as $$
declare r public.requests; d text;
begin
  select * into r from public.requests where id = p_request and client_id = auth.uid() for update;
  if r.id is null then raise exception 'Demande introuvable.'; end if;
  if r.payment_proof_path is null then raise exception 'Aucune preuve de versement pour cette demande.'; end if;
  if r.proof_viewed_at is null then
    if r.status = 'paid' and now() < coalesce(r.due_starts_at, now() + interval '1 second') then
      -- Vue avant le départ automatique : le délai démarre maintenant
      update public.requests set proof_viewed_at = now(), due_starts_at = now(),
             date_remboursement = (now() at time zone 'Africa/Dakar')::date + r.duree
       where id = p_request;
    else
      update public.requests set proof_viewed_at = now() where id = p_request;
    end if;
  end if;
  select date_remboursement::text into d from public.requests where id = p_request;
  return d;
end $$;
revoke all on function public.client_proof_seen(uuid) from public, anon;
grant execute on function public.client_proof_seen(uuid) to authenticated;

-- « Garantie reçue » → « Payé » uniquement avec une preuve (admin_mark_paid)
create or replace function public.requests_require_proof()
returns trigger language plpgsql as $$
begin
  if new.status = 'paid' and old.status = 'guarantee_received' and new.payment_proof_path is null then
    raise exception 'Joignez la capture d''écran de votre reçu Wave avant de marquer la demande comme payée.';
  end if;
  return new;
end $$;
drop trigger if exists requests_require_proof on public.requests;
create trigger requests_require_proof before update on public.requests
  for each row execute function public.requests_require_proof();

-- Notification au client : « Votre argent a été envoyé »
create or replace function public.requests_notify()
returns trigger language plpgsql security definer set search_path = public as $$
declare who text := coalesce(new.nom, 'Un client');
        fmt text := replace(to_char(new.montant, 'FM999,999,999'), ',', ' ') || ' FCFA';
begin
  if tg_op = 'INSERT' then
    perform public.notify_admins(new.id, '📝 Nouvelle demande', who || ' demande ' || fmt || '.');
    return new;
  end if;

  if old.guarantee_declared_at is null and new.guarantee_declared_at is not null then
    perform public.notify_admins(new.id, '📦 Garantie en route', who || ' va vous envoyer sa garantie par Yango. Wave : ' || new.wave_number);
  elsif old.guarantee_declared_at is not null and new.wave_number is distinct from old.wave_number then
    perform public.notify_admins(new.id, '⚠️ Numéro Wave modifié', who || ' a changé son numéro Wave : ' || coalesce(old.wave_number, '—') || ' → ' || new.wave_number);
  end if;

  if new.status is distinct from old.status then
    insert into public.notifications (user_id, request_id, title, body)
    select new.client_id, new.id, t.title, t.body from (values
      ('guarantee_received', '📦 Garantie reçue', 'Nous avons bien reçu votre garantie. L''argent va être envoyé sur votre Wave.'),
      ('paid', '💸 Votre argent a été envoyé', fmt || ' envoyés sur votre Wave ' || coalesce(new.wave_number, '')
               || '. Ouvrez l''application pour voir la capture du reçu Wave. Votre délai de ' || new.duree || ' jours démarre à ce moment-là.'),
      ('repayment_requested', '⏳ Remboursement en vérification', 'Nous vérifions la réception de votre remboursement.'),
      ('done', '🎉 Prêt remboursé', 'Merci ! Votre prêt est entièrement remboursé.'),
      ('rejected', '❌ Demande refusée', coalesce(new.rejection_reason, 'Votre demande a été refusée.')),
      ('pending', '↩️ Demande remise en attente', coalesce(new.admin_note, 'Votre demande est de nouveau en attente.'))
    ) as t(st, title, body)
    where t.st = new.status
      and not (new.status = 'paid' and old.status = 'repayment_requested');
    if new.status = 'paid' and old.status = 'repayment_requested' then
      insert into public.notifications (user_id, request_id, title, body)
      values (new.client_id, new.id, '⚠️ Remboursement non trouvé', coalesce(new.admin_note, 'Nous n''avons pas trouvé votre paiement. Vérifiez la référence.'));
    end if;
    if new.status = 'repayment_requested' then
      perform public.notify_admins(new.id, '💰 Remboursement déclaré',
        who || ' dit avoir envoyé ' || replace(to_char(new.repayment_amount, 'FM999,999,999'), ',', ' ') || ' FCFA (réf. ' || coalesce(new.repayment_ref, '?') || ').');
    end if;
  end if;
  return new;
end $$;
