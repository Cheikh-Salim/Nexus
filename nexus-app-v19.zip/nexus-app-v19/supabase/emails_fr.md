# E-mails Supabase en français (à coller une seule fois)

Supabase → **Authentication** → **Emails** (ou **Email Templates**).
Pour chaque modèle ci-dessous : remplacez le **Subject** et le **Body**, puis cliquez sur **Save**.
Ne modifiez pas `{{ .ConfirmationURL }}` : c'est le lien personnel du client.

---

## 1. Confirm signup (confirmation de l'inscription)

**Subject**
```
Confirmez votre compte Nexus Crédit
```

**Body**
```html
<div style="font-family:Arial,Helvetica,sans-serif;max-width:520px;margin:0 auto;padding:24px;color:#0b1b2b">
  <div style="width:48px;height:48px;border-radius:14px;background:#0d9488;color:#fff;font-weight:bold;font-size:24px;line-height:48px;text-align:center">N</div>
  <h2 style="margin:18px 0 8px">Bienvenue chez Nexus Crédit</h2>
  <p style="color:#26394a;line-height:1.6">Merci pour votre inscription. Touchez le bouton ci-dessous pour confirmer votre adresse e-mail et accéder à votre espace.</p>
  <p style="margin:24px 0"><a href="{{ .ConfirmationURL }}" style="background:#0d9488;color:#fff;text-decoration:none;padding:14px 22px;border-radius:12px;font-weight:bold;display:inline-block">Confirmer mon compte</a></p>
  <p style="color:#5d6f7c;font-size:13px;line-height:1.5">Vous n'êtes pas à l'origine de cette inscription ? Ignorez simplement ce message.</p>
  <p style="color:#5d6f7c;font-size:12px;margin-top:24px">Nexus Crédit · Gueule Tapée, Dakar</p>
</div>
```

---

## 2. Reset password (mot de passe oublié)

**Subject**
```
Choisissez un nouveau mot de passe
```

**Body**
```html
<div style="font-family:Arial,Helvetica,sans-serif;max-width:520px;margin:0 auto;padding:24px;color:#0b1b2b">
  <div style="width:48px;height:48px;border-radius:14px;background:#0d9488;color:#fff;font-weight:bold;font-size:24px;line-height:48px;text-align:center">N</div>
  <h2 style="margin:18px 0 8px">Mot de passe oublié ?</h2>
  <p style="color:#26394a;line-height:1.6">Nous avons reçu une demande de réinitialisation pour votre compte Nexus Crédit. Touchez le bouton ci-dessous pour choisir un nouveau mot de passe.</p>
  <p style="margin:24px 0"><a href="{{ .ConfirmationURL }}" style="background:#0d9488;color:#fff;text-decoration:none;padding:14px 22px;border-radius:12px;font-weight:bold;display:inline-block">Choisir un nouveau mot de passe</a></p>
  <p style="color:#5d6f7c;font-size:13px;line-height:1.5">Ce lien est valable pendant une durée limitée. Si vous n'avez rien demandé, ignorez ce message : votre mot de passe actuel reste valable.</p>
  <p style="color:#5d6f7c;font-size:12px;margin-top:24px">Nexus Crédit · Gueule Tapée, Dakar</p>
</div>
```

---

## 3. Change email address (changement d'adresse e-mail)

**Subject**
```
Confirmez votre nouvelle adresse e-mail
```

**Body**
```html
<div style="font-family:Arial,Helvetica,sans-serif;max-width:520px;margin:0 auto;padding:24px;color:#0b1b2b">
  <h2 style="margin:0 0 8px">Nouvelle adresse e-mail</h2>
  <p style="color:#26394a;line-height:1.6">Touchez le bouton ci-dessous pour confirmer votre nouvelle adresse e-mail sur Nexus Crédit.</p>
  <p style="margin:24px 0"><a href="{{ .ConfirmationURL }}" style="background:#0d9488;color:#fff;text-decoration:none;padding:14px 22px;border-radius:12px;font-weight:bold;display:inline-block">Confirmer l'adresse</a></p>
  <p style="color:#5d6f7c;font-size:12px;margin-top:24px">Nexus Crédit · Gueule Tapée, Dakar</p>
</div>
```

---

**Important :** dans **Authentication → URL Configuration**, la **Site URL** doit être `https://nexus-credit.onrender.com/`
et `https://nexus-credit.onrender.com/**` doit figurer dans **Redirect URLs**. Sinon, les liens des e-mails ouvrent une mauvaise adresse.
