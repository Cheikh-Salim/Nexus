'use strict';
/* =====================================================================
   NEXUS CRÉDIT — application (v4)
   Statuts : pending → guarantee_received → paid → repayment_requested → done (+ rejected)
   ===================================================================== */

const SUPABASE_URL = 'https://qhdvrrpiqtfvppnaxelj.supabase.co';
const SUPABASE_KEY = 'sb_publishable_ae66Vd9KKZG3-5bCMcoPgw_9T2rEdiB'; // clé publique (protégée par les règles RLS)
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

// Colonnes utiles aux listes (sans la signature, lourde) → pages plus rapides.
const LIST_COLS = 'id,payment_proof_path,payment_proof_at,proof_viewed_at,due_starts_at,contact1_name,contact1_phone,contact2_name,contact2_phone,guarantee_returned_at,guarantee_return_note,client_id,updated_at,contract_version,contract_accepted_at,nom,telephone,montant,duree,total,status,created_at,date_remboursement,wave_number,guarantee_name,guarantee_phone,guarantee_declared_at,guarantee_received_at,paid_at,paid_amount,repayment_amount,repayment_ref,repayment_requested_at,repaid_at,rejection_reason,admin_note,pdf_url,passeport,garantie,receipt_number,receipt_issued_at';

/* ---------------------------------------------------------------------
   Utilitaires
   --------------------------------------------------------------------- */
const $ = (id) => document.getElementById(id);
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const fcfa = (n) => (Number(n) || 0).toLocaleString('fr-FR') + ' FCFA';
const digits = (p) => String(p ?? '').replace(/\D/g, '').replace(/^221(?=\d{9}$)/, '');
const fmtPhone = (p) => { const d = digits(p); const f = (x) => x.replace(/^(\d{2})(\d{3})(\d{2})(\d{2})$/, '$1 $2 $3 $4');
  return /^221\d{9}$/.test(d) ? '+221 ' + f(d.slice(3)) : f(d); };
const fmtDate = (d) => (d ? new Date(d).toLocaleDateString('fr-FR') : '—');
const fmtDateTime = (d) => (d ? new Date(d).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }) : '—');
const jsArg = (v) => esc(JSON.stringify(String(v ?? ''))); // valeur sûre dans un onclick="..."
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const PHONE_OK = (p) => { const d = digits(p); return d.length >= 9 && d.length <= 15; };

function toast(msg, type = 'success') {
  const el = document.createElement('div');
  el.className = 'toast ' + (type === 'success' ? '' : type);
  const icon = document.createElement('span');
  icon.className = 'toast-ic';
  icon.innerHTML = ic(type === 'error' ? 'alert' : type === 'info' ? 'bell' : 'check', 'ic-sm');
  const text = document.createElement('span');
  text.className = 'toast-msg';
  text.textContent = msg; // texte brut : aucun HTML injecté
  el.append(icon, text);
  el.setAttribute('role', type === 'error' ? 'alert' : 'status');
  const wrap = $('toastWrap');
  // Le même message déjà affiché n'est pas répété (double appui, double gestionnaire)
  if ([...wrap.children].some((t) => !t.classList.contains('out') && t.querySelector('.toast-msg')?.textContent === msg)) return;
  while (wrap.children.length >= 3) wrap.firstChild.remove();
  wrap.appendChild(el);
  const close = () => { el.classList.add('out'); setTimeout(() => el.remove(), 260); };
  el.onclick = close;
  setTimeout(close, type === 'error' ? 5500 : 3800);
}

function copyText(t) {
  const ok = () => toast('Copié : ' + t, 'info');
  const fallback = () => {
    const ta = document.createElement('textarea');
    ta.value = t; ta.setAttribute('readonly', ''); ta.style.position = 'fixed'; ta.style.opacity = '0';
    document.body.appendChild(ta); ta.select();
    try { document.execCommand('copy') ? ok() : prompt('Copiez ce texte :', t); } catch (_) { prompt('Copiez ce texte :', t); }
    ta.remove();
  };
  if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(t).then(ok, fallback);
  else fallback();
}
const copyBtn = (text, label = '') =>
  `<button type="button" class="btn btn-ghost btn-sm copy-btn" onclick="copyText(${jsArg(text)})" aria-label="Copier">${ic('copy')}<span>${label && !/^📋$/.test(label) ? esc(label.replace(/^📋\s*/, '')) : 'Copier'}</span></button>`;
const waveCell = (w) => (w ? `<span class="wave">${esc(fmtPhone(w))}</span> <button class="icon-btn copy-mini" title="Copier le numéro" aria-label="Copier le numéro" onclick="copyText(${jsArg(digits(w))})">${ic('copy')}</button>` : '<span class="muted">—</span>');

/* Traduit les erreurs techniques en messages clairs. */
function friendly(err) {
  const raw = String(err?.message || err || '');
  const m = raw.toLowerCase();
  if (!navigator.onLine || /failed to fetch|networkerror|load failed|network request failed|fetch failed|timeout/.test(m))
    return 'Connexion perdue. Vérifiez votre internet puis réessayez.';
  if (/jwt|token.*expired|refresh token|not authenticated/.test(m)) return 'Votre session a expiré. Reconnectez-vous.';
  if (/row-level security|permission denied/.test(m)) return "Action non autorisée.";
  if (/duplicate key/.test(m)) return 'Déjà enregistré.';
  if (/invalid input syntax for type uuid/.test(m)) return 'Lien invalide.';
  return raw || 'Une erreur est survenue. Réessayez.';
}
class AppError extends Error {}
/* Émojis des boutons remplacés par des icônes vectorielles nettes (rendu identique sur tous les téléphones) */
const EMOJI_ICON = { '✅': 'check', '📲': 'send', '💰': 'wallet', '💸': 'wallet', '✏️': 'pen', '↩️': 'undo', '💾': 'check', '⬇️': 'download', '📋': 'copy',
  '🔄': 'refresh', '↻': 'refresh', '📄': 'doc', '📜': 'doc', '🧾': 'receipt', '➕': 'plus', '🗑️': 'trash', '📤': 'send', '📦': 'box', '❌': 'x',
  '💬': 'chat', '📩': 'chat', '🔍': 'search', '🔒': 'lock', '🚪': 'logout', '🔔': 'bell', '📅': 'calendar', '📈': 'chart', '⚙️': 'settings',
  '⭐': 'star', '📭': 'inbox', '📥': 'inbox', '🧪': 'send', '👤': 'user', '📊': 'chart', '🏠': 'home', '📝': 'pen', '🛡️': 'shield', '⏳': 'clock', '📷': 'camera' };
const EMOJI_RE = new RegExp('^\\s*(' + Object.keys(EMOJI_ICON).map((k) => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')\\uFE0F?\\s*');
const EMOJI_MORE = { '⏳': 'hourglass', '⚠️': 'alert', '⚠': 'alert', '🚨': 'alert', '⏰': 'clock', '⏱': 'clock', '⏱️': 'clock', '📡': 'alert', '🎉': 'star',
  '📍': 'home', '🗓️': 'calendar', '📆': 'calendar', '✔': 'check', '✔️': 'check', '🌙': 'moon', '🌓': 'moon', '🔎': 'search', '📢': 'bell', '🤝': 'shield', '💡': 'star',
  '🔐': 'lock', '📞': 'phone', '📧': 'mail', '✉️': 'mail', '🏁': 'box', '📮': 'mail', '🔁': 'refresh', '🙏': '' };
Object.assign(EMOJI_ICON, EMOJI_MORE);
const DOTS = { '🔴': 'red', '🟠': 'orange', '🟢': 'green', '🟡': 'orange', '🔵': 'blue' };
const ALL_EMOJI_RE = new RegExp('(' + [...Object.keys(EMOJI_ICON), ...Object.keys(DOTS)].sort((x, y) => y.length - x.length)
  .map((k) => k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')️?\\s?', 'g');
const NO_ICONIZE = '.bubble, .contract, .contract-mini, textarea, input, script, style, .stars, .howto-ios, .sig-guide, [data-no-ic]';
function iconize(root) {
  if (!root || root.nodeType !== 1 || root.closest?.(NO_ICONIZE)) return;
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode: (n) => (ALL_EMOJI_RE.test(n.nodeValue) && (ALL_EMOJI_RE.lastIndex = 0, !n.parentElement.closest(NO_ICONIZE)) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT),
  });
  const nodes = []; while (walker.nextNode()) nodes.push(walker.currentNode);
  for (const t of nodes) {
    ALL_EMOJI_RE.lastIndex = 0;
    const frag = document.createDocumentFragment(); let last = 0, m; const v = t.nodeValue;
    while ((m = ALL_EMOJI_RE.exec(v))) {
      if (m.index > last) frag.append(v.slice(last, m.index));
      const e = m[1], name = EMOJI_ICON[e];
      if (DOTS[e]) { const d = document.createElement('i'); d.className = 'dot ' + DOTS[e]; frag.append(d); }
      else if (name) { const w = document.createElement('span'); w.innerHTML = ic(name, 'ic-inline'); frag.append(w.firstChild); }
      last = m.index + m[0].length;
    }
    if (last < v.length) frag.append(v.slice(last));
    t.replaceWith(frag);
  }
}
new MutationObserver((list) => { for (const r of list) r.addedNodes.forEach((n) => { if (n.nodeType === 1) iconize(n); else if (n.nodeType === 3 && n.parentElement) iconize(n.parentElement); }); })
  .observe(document.documentElement, { childList: true, subtree: true });
/* Retour tactile léger (Android) */
const haptic = (ms = 8) => { try { if (navigator.vibrate && matchMedia('(pointer: coarse)').matches) navigator.vibrate(ms); } catch (_) {} };
/* Effet d'onde au toucher sur les boutons */
document.addEventListener('pointerdown', (e) => {
  const b = e.target.closest('.btn, .bn-item, .sb-link, .conv, .tile, .seg button, .cbtn');
  if (!b || b.disabled) return;
  const r = b.getBoundingClientRect(), d = Math.max(r.width, r.height) * 2.2;
  const w = document.createElement('span'); w.className = 'ripple';
  w.style.cssText = `width:${d}px;height:${d}px;left:${e.clientX - r.left - d / 2}px;top:${e.clientY - r.top - d / 2}px`;
  b.appendChild(w); setTimeout(() => w.remove(), 600);
}, { passive: true });
document.addEventListener('DOMContentLoaded', () => iconize(document.body));
/* Icône vectorielle du sprite (#i-…) */
const numVal = (el) => parseInt(String(el.value || '').replace(/\D/g, ''), 10) || 0;
function fmtAmountInput(el) { const v = numVal(el); el.value = v ? v.toLocaleString('fr-FR').replace(/\u202f|\u00a0/g, ' ') : ''; }
const paintRange = (r) => { const min = +r.min || 0, max = +r.max || 100; r.style.setProperty('--fill', (((+r.value - min) / (max - min)) * 100) + '%'); };
document.addEventListener('input', (e) => { if (e.target.type === 'range') paintRange(e.target); }, true);
/* Accord en nombre (0 et 1 au singulier, comme en français) */
const pl = (n, one, many = one + 's') => `${n} ${Math.abs(Number(n)) >= 2 ? many : one}`;
const ic = (name, cls = '') => `<svg class="ic ${cls}" aria-hidden="true"><use href="#i-${name}"/></svg>`;
async function rpc(name, args) {
  let res;
  try { res = await sb.rpc(name, args); } catch (e) { throw new AppError(friendly(e)); }
  if (res.error) throw new AppError(friendly(res.error));
  return res.data;
}
/* Exécute une action une seule fois à la fois (protège du double clic). */
const _locks = new Set();
async function once(key, fn) {
  if (_locks.has(key)) return;
  _locks.add(key);
  document.body.classList.add('is-busy');
  try { return await fn(); } finally { invalidateData(); _locks.delete(key); if (!_locks.size) document.body.classList.remove('is-busy'); }
}
/* Signale un champ invalide : bordure rouge, focus, message. */
/* Fenêtre de confirmation élégante (remplace les fenêtres grises du navigateur).
   askDialog({ title, message, confirmText, danger, input: { label, value, choices } }) → Promise<true | texte | null> */
function askDialog(o) {
  if (window.__autoConfirm) { (window.__dialogs = window.__dialogs || []).push(o.title + ' ' + (o.message || '')); return Promise.resolve(o.input ? (o.input.value || (o.input.choices || [])[0] || 'OK') : true); } // tests automatisés uniquement
  return new Promise((resolve) => {
    const wrap = document.createElement('div'); wrap.className = 'dialog-overlay'; wrap.setAttribute('role', 'dialog'); wrap.setAttribute('aria-modal', 'true');
    wrap.innerHTML = `<div class="dialog">
      <span class="dialog-ic ${o.danger ? 'danger' : ''}">${ic(o.icon || (o.danger ? 'alert' : 'check'))}</span>
      <h3>${esc(o.title)}</h3>${o.message ? `<p>${esc(o.message).replace(/\n/g, '<br>')}</p>` : ''}
      ${o.input ? `${o.input.choices ? `<div class="dialog-chips">${o.input.choices.map((c) => `<button type="button" class="chip" data-v="${esc(c)}">${esc(c)}</button>`).join('')}</div>` : ''}
        <textarea class="dialog-input" rows="2" maxlength="300" aria-label="${esc(o.input.label || '')}" placeholder="${esc(o.input.label || '')}">${esc(o.input.value || '')}</textarea>` : ''}
      <div class="dialog-actions"><button type="button" class="btn btn-secondary" data-act="no">${esc(o.cancelText || 'Annuler')}</button>
        <button type="button" class="btn ${o.danger ? 'btn-danger' : 'btn-primary'}" data-act="yes">${esc(o.confirmText || 'Confirmer')}</button></div></div>`;
    document.body.appendChild(wrap);
    const input = wrap.querySelector('.dialog-input');
    const close = (v) => { wrap.classList.add('out'); setTimeout(() => wrap.remove(), 180); document.removeEventListener('keydown', onKey); resolve(v); };
    const onKey = (e) => { if (e.key === 'Escape') close(null); };
    document.addEventListener('keydown', onKey);
    wrap.addEventListener('click', (e) => {
      if (e.target === wrap) return close(null);
      const chip = e.target.closest('[data-v]'); if (chip) { input.value = chip.dataset.v; input.focus(); return; }
      const a = e.target.closest('[data-act]'); if (!a) return;
      if (a.dataset.act === 'no') return close(null);
      if (input && !input.value.trim()) { markField(input); return; }
      close(input ? input.value.trim() : true);
    });
    requestAnimationFrame(() => (input || wrap.querySelector('[data-act="yes"]')).focus());
  });
}
function markField(el) {
  if (!el) return false;
  el.classList.add('invalid'); el.setAttribute('aria-invalid', 'true'); el.focus({ preventScroll: false });
  el.addEventListener('input', () => { el.classList.remove('invalid'); el.removeAttribute('aria-invalid'); }, { once: true });
  return false;
}
function invalid(el, msg) {
  if (el) {
    el.classList.add('invalid'); el.setAttribute('aria-invalid', 'true');
    el.focus({ preventScroll: false });
    el.addEventListener('input', () => { el.classList.remove('invalid'); el.removeAttribute('aria-invalid'); }, { once: true });
  }
  toast(msg, 'error');
  return false;
}
const isUuid = (v) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(v));
const newUuid = () => (crypto.randomUUID ? crypto.randomUUID()
  : '10000000-1000-4000-8000-100000000000'.replace(/[018]/g, (c) => (c ^ (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (c / 4)))).toString(16)));
/* Requête Supabase avec erreurs lisibles. */
async function q(promise) {
  let res;
  try { res = await promise; } catch (e) { throw new AppError(friendly(e)); }
  if (res.error) throw new AppError(friendly(res.error));
  return res;
}
function busy(btn, on, label) {
  if (!btn) return;
  if (on) {
    btn.dataset.html = btn.innerHTML; btn.dataset.label = btn.dataset.orig = btn.textContent; btn.disabled = true;
    btn.innerHTML = `<span class="spin" aria-hidden="true"></span>${esc(label || 'Patientez…')}`; btn.setAttribute('aria-busy', 'true');
  } else {
    btn.disabled = false; btn.removeAttribute('aria-busy');
    if (btn.dataset.label && btn.dataset.label !== btn.dataset.orig) btn.textContent = btn.dataset.label; // libellé changé pendant l'action
    else if (btn.dataset.html) btn.innerHTML = btn.dataset.html;
  }
}

/* ---------------------------------------------------------------------
   Statuts
   --------------------------------------------------------------------- */
const STATUS = {
  pending:             { label: 'En attente',            step: 0 },
  guarantee_received:  { label: 'Garantie reçue',        step: 1 },
  paid:                { label: 'Payé',                  step: 2 },
  repayment_requested: { label: 'En vérification', step: 3 },
  done:                { label: 'Remboursé',             step: 4 },
  rejected:            { label: 'Refusée',               step: -1 },
};
const STEP_LABELS = ['En attente', 'Garantie reçue', 'Payé', 'En vérification', 'Remboursé'];
const statusBadge = (st) => `<span class="badge badge-${esc(st)}">${esc(STATUS[st]?.label || st)}</span>`;
function steps(st) {
  const cur = STATUS[st]?.step ?? 0;
  if (cur < 0) return '';
  const SHORT = ['En attente', 'Garantie', 'Payé', 'Vérification', 'Remboursé'];
  const pct = st === 'done' ? 100 : (cur / (STEP_LABELS.length - 1)) * 100;
  return `<ol class="steps" style="--p:${pct}%" aria-label="Avancement : ${esc(STATUS[st]?.label || '')}">${STEP_LABELS.map((l, i) => {
    const cls = i < cur || st === 'done' ? 'done' : i === cur ? 'now' : '';
    return `<li class="step ${cls}" ${cls === 'now' ? 'aria-current="step"' : ''}><span class="dot">${cls === 'done' ? ic('check') : i + 1}</span><span class="lbl"><span class="lbl-long">${l}</span><span class="lbl-short">${SHORT[i]}</span></span></li>`;
  }).join('')}</ol>`;
}

/* ---------------------------------------------------------------------
   Thème
   --------------------------------------------------------------------- */
function applyTheme(t) {
  document.documentElement.setAttribute('data-theme', t);
  try { localStorage.setItem('nexusTheme', t); } catch (_) {}
  document.querySelectorAll('[data-theme-toggle]').forEach((b) => { b.innerHTML = ic(t === 'dark' ? 'moon' : 'sun') + (b.dataset.label ? `<span class="tt-label">${b.dataset.label}</span>` : ''); });
  const m = document.querySelector('meta[name="theme-color"]'); if (m) m.content = t === 'dark' ? '#0a0f0d' : '#f5f7f6';
}
let savedTheme = null; try { savedTheme = localStorage.getItem('nexusTheme'); } catch (_) {}
applyTheme(savedTheme || (matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));

/* ---------------------------------------------------------------------
   Session (profil chargé une seule fois, pas à chaque page)
   --------------------------------------------------------------------- */
let currentUser = null;

let _profileError = null;
async function loadProfile(fast = false) {
  _profileError = null;
  try {
    const { data: { session } } = await sb.auth.getSession();
    if (!session) { currentUser = null; return null; }
    let mark = null; try { mark = localStorage.getItem(LOGOUT_MARK); } catch (_) {}
    if (mark && mark === session.access_token) { dropLocalSession(); sb.auth.signOut().catch(() => {}); currentUser = null; return null; }
    // Ouverture instantanée : le profil enregistré sur l'appareil sert tout de suite, puis il est vérifié en arrière-plan.
    if (fast) {
      let saved = null; try { saved = JSON.parse(localStorage.getItem('nexusProfile') || 'null'); } catch (_) {}
      if (saved && saved.id === session.user.id && saved.role) {
        currentUser = saved;
        sb.from('profiles').select('id, email, full_name, phone, role').eq('id', session.user.id).single().then(({ data, error }) => {
          if (error || !data || !currentUser || currentUser.id !== data.id) return;
          const changed = data.role !== currentUser.role || data.full_name !== currentUser.full_name || data.phone !== currentUser.phone;
          currentUser = data; try { localStorage.setItem('nexusProfile', JSON.stringify(data)); } catch (_) {}
          if (changed) route();
        }).catch(() => {});
        return saved;
      }
    }
    let res;
    try { res = await sb.from('profiles').select('id, email, full_name, phone, role').eq('id', session.user.id).single(); }
    catch (e) { res = { error: e }; }
    if (res.error) {
      // Hors connexion : on reprend le dernier profil connu pour ouvrir l'appli en lecture seule.
      let saved = null; try { saved = JSON.parse(localStorage.getItem('nexusProfile') || 'null'); } catch (_) {}
      if (!navigator.onLine && saved && saved.id === session.user.id) { currentUser = saved; return saved; }
      throw res.error;
    }
    currentUser = res.data;
    try { localStorage.setItem('nexusProfile', JSON.stringify(res.data)); } catch (_) {}
    return res.data;
  } catch (e) {
    console.error('[profil]', e);
    _profileError = friendly(e);
    currentUser = null;
    return null;
  }
}

let _recovering = false;
sb.auth.onAuthStateChange((event) => {
  if (event === 'SIGNED_OUT') { const was = !!currentUser; teardownSession(); if (!_recovering && was) navigate('/home'); }
  if (event === 'PASSWORD_RECOVERY') { _recovering = true; setTimeout(() => navigate('/reset'), 0); }
});

function teardownSession() {
  leaveChat(); currentUser = null; _settings = null; _msgUnread = 0; _adminSearch = ''; _adminFilter = 'todo'; _activeLoan = null;
  if (_notifChannel && _notifChannel !== 'starting') sb.removeChannel(_notifChannel);
  _notifChannel = null;
  _notifs = []; renderBell();
}

/* ---------------------------------------------------------------------
   Routeur
   --------------------------------------------------------------------- */
const ROUTES = [
  { re: /^\/home$/, view: 'home', public: true },
  { re: /^\/login$/, view: 'login', public: true },
  { re: /^\/register$/, view: 'register', public: true },
  { re: /^\/reset$/, view: 'reset', public: true },
  { re: /^\/forgot$/, view: 'forgot', public: true },
  { re: /^\/help$/, view: 'doc', public: true, open: true },
  { re: /^\/legal\/(?:cgu|confidentialite|mentions)$/, view: 'doc', public: true, open: true },
  { re: /^\/client\/dashboard$/, role: 'client', render: renderClientDashboard },
  { re: /^\/client\/requests$/, role: 'client', render: renderClientRequests },
  { re: /^\/client\/new$/, role: 'client', render: renderNewRequest },
  { re: /^\/client\/requests\/([\w-]+)$/, role: 'client', render: renderClientRequest },
  { re: /^\/admin\/dashboard$/, role: 'admin', render: renderAdminDashboard },
  { re: /^\/admin\/requests$/, role: 'admin', render: renderAdminRequests },
  { re: /^\/admin\/requests\/([\w-]+)$/, role: 'admin', render: renderAdminRequest },
  { re: /^\/admin\/settings$/, role: 'admin', render: renderAdminSettings },
  { re: /^\/admin\/dues$/, role: 'admin', render: renderAdminDues },
  { re: /^\/admin\/stats$/, role: 'admin', render: renderAdminStats },
  { re: /^\/client\/messages$/, role: 'client', render: renderClientMessages },
  { re: /^\/client\/messages\/chat$/, role: 'client', render: renderClientChat },
  { re: /^\/admin\/messages$/, role: 'admin', render: renderAdminMessages },
  { re: /^\/admin\/messages\/([\w-]+)$/, role: 'admin', render: renderAdminThread },
  { re: /^\/profile$/, role: '*', render: renderProfile },
];
// [chemin, icône, libellé, libellé court (barre du bas sur téléphone)]
const NAV = {
  client: [['/client/dashboard', 'home', 'Accueil', 'Accueil'], ['/client/requests', 'wallet', 'Mes prêts', 'Mes prêts'],
    ['/client/messages', 'chat', 'Messages', 'Messages'], ['/profile', 'user', 'Profil', 'Profil']],
  admin: [['/admin/dashboard', 'grid', 'Tableau de bord', 'Accueil'], ['/admin/requests', 'doc', 'Demandes', 'Demandes'], ['/admin/messages', 'chat', 'Messages', 'Messages'],
    ['/admin/dues', 'calendar', 'Échéancier', 'Échéances'], ['/admin/stats', 'chart', 'Statistiques', 'Stats'], ['/admin/settings', 'settings', 'Paramètres', 'Réglages'], ['/profile', 'user', 'Mon profil', 'Profil']],
};
const homeOf = (u) => (u?.role === 'admin' ? '/admin/dashboard' : '/client/dashboard');

function navigate(path) {
  if (location.hash !== '#' + path) location.hash = '#' + path;
  else route();
}

let _routeSeq = 0;
/* Chaque page vérifie qu'elle est toujours la page demandée avant de s'afficher
   (évite qu'une page lente écrase la suivante). */
const painter = () => { const seq = _routeSeq; return () => seq === _routeSeq; };

function skeletonHtml(path) {
  const line = (w, h = 14) => `<div class="sk" style="width:${w};height:${h}px"></div>`;
  const card = (h) => `<div class="sk-card" style="height:${h}px">${line('40%')}${line('70%', 22)}${line('55%')}</div>`;
  if (/messages\/./.test(path)) return `<div class="sk-wrap">${line('45%', 28)}${[1, 2, 3, 4].map((i) => `<div class="sk-bubble ${i % 2 ? '' : 'me'}"></div>`).join('')}</div>`;
  if (/dashboard/.test(path)) return `<div class="sk-wrap">${line('30%')}${line('45%', 30)}${card(220)}<div class="sk-row">${card(90)}${card(90)}${card(90)}</div></div>`;
  return `<div class="sk-wrap">${line('40%', 30)}${line('60%')}${card(110)}${card(110)}${card(110)}</div>`;
}
async function route() {
  const seq = ++_routeSeq;
  hideUpdateBar();
  leaveChat();
  document.body.classList.remove('focus-flow');
  const path = location.hash.replace(/^#/, '') || '/home';
  if (/access_token=|error_description=/.test(path)) return; // lien reçu par e-mail : traité par Supabase
  let match = null, params = [];
  for (const r of ROUTES) { const m = path.match(r.re); if (m) { match = r; params = m.slice(1); break; } }
  if (!match) return navigate(currentUser ? homeOf(currentUser) : '/home');
  if (params.length && !isUuid(params[0])) { toast('Lien invalide.', 'error'); return navigate(currentUser ? homeOf(currentUser) : '/home'); }

  if (match.public) {
    if (match.view === 'reset') { if (!_recovering) return navigate('/login'); return showView('reset'); }
    if (currentUser && path !== '/home' && !match.open) return navigate(homeOf(currentUser));
    updateHomeNav();
    if (match.view === 'doc') renderDoc(path);
    showView(match.view);
    if (match.view === 'home') setupCalculator();
    renderInstallBanners();
    return;
  }
  if (!currentUser) await loadProfile();
  if (seq !== _routeSeq) return;
  if (!currentUser) {
    if (_profileError) { showView('login'); return showAuthError('loginError', _profileError); }
    toast('Veuillez vous connecter.', 'info'); return navigate('/login');
  }
  if (match.role !== '*' && match.role !== currentUser.role) return navigate(homeOf(currentUser));

  showView('app');
  buildNav(path);
  startNotifications();
  const content = $('content');
  content.dataset.dirty = '';
  content.innerHTML = skeletonHtml(path);
  try { await match.render(...params); renderInstallBanners(); paintUrgent(); }
  catch (e) {
    console.error(e);
    if (seq !== _routeSeq) return;
    content.innerHTML = `<div class="state-card">${emptyArt('error')}<h2>Impossible d'afficher cette page</h2><p>${esc(friendly(e))}</p>
      <button class="btn btn-primary btn-xl" onclick="route()">${ic('refresh')}Réessayer</button></div>`;
  }
}

/* Accueil : si l'utilisateur est connecté, un seul bouton « Mon espace ». */
function updateHomeNav() {
  document.querySelectorAll('[data-guest]').forEach((el) => { el.hidden = !!currentUser; });
  document.querySelectorAll('[data-member]').forEach((el) => { el.hidden = !currentUser; });
}

const PAGE_TITLES = [[/^\/home$/, ''], [/^\/login$/, 'Connexion'], [/^\/register$/, 'Créer un compte'], [/^\/forgot$/, 'Mot de passe oublié'],
  [/^\/client\/dashboard$/, 'Accueil'], [/^\/client\/requests$/, 'Mes prêts'], [/^\/client\/requests\//, 'Mon prêt'], [/^\/client\/new$/, 'Nouvelle demande'],
  [/^\/client\/messages/, 'Messages'], [/^\/profile$/, 'Mon profil'], [/^\/help$/, 'Aide'], [/^\/legal\//, 'Informations légales'],
  [/^\/admin\/dashboard$/, "Vue d'ensemble"], [/^\/admin\/requests/, 'Demandes'], [/^\/admin\/messages/, 'Messages'], [/^\/admin\/dues$/, 'Échéancier'],
  [/^\/admin\/stats$/, 'Statistiques'], [/^\/admin\/settings$/, 'Paramètres']];
function setPageTitle() {
  const path = (location.hash || '#/home').slice(1).split('?')[0];
  const t = (PAGE_TITLES.find(([re]) => re.test(path)) || [null, ''])[1];
  document.title = t ? `${t} · Nexus Crédit` : 'Nexus Crédit — Prêt rapide au Sénégal';
}
window.addEventListener('hashchange', setPageTitle);
function showView(name) {
  setPageTitle();
  document.documentElement.classList.remove('boot-home');
  document.documentElement.classList.add('ready');
  document.querySelectorAll('.view').forEach((v) => v.classList.toggle('active', v.id === 'view-' + name));
  window.scrollTo({ top: 0, behavior: 'instant' });
  closeSidebar();
}

function buildNav(path) {
  setTimeout(applyBlockState, 0);
  setTimeout(paintMsgBadge, 0);
  const role = currentUser.role;
  $('sbRole').textContent = role === 'admin' ? '🛡️ Administrateur' : 'Espace client';
  $('sbRole').style.color = role === 'admin' ? 'var(--gold)' : '';
  const active = (p) => path === p || ((p.endsWith('requests') || p.endsWith('messages')) && path.startsWith(p + '/')) || (p === '/client/requests' && path === '/client/new');
  const badge = (p) => (p.endsWith('/messages') ? '<span class="nav-badge" data-msg-badge hidden></span>' : '');
  $('sbNav').innerHTML = (role === 'client' ? `<button class="btn btn-primary btn-block sb-cta" data-new-request onclick="goNewRequest()">${ic('plus')}Nouvelle demande</button>` : '') + NAV[role].map(([p, icon, label]) =>
    `<a class="sb-link ${active(p) ? 'active' : ''}" href="#${p}" ${p === '/client/new' ? 'data-new-request' : ''}><span class="sb-icon">${ic(icon)}</span>${label}${badge(p)}</a>`).join('');
  const items = role === 'admin' ? NAV.admin.filter(([p]) => !['/profile', '/admin/settings', '/admin/stats'].includes(p)) : NAV.client;
  $('bottomNav').innerHTML = items.map(([p, icon, , short]) =>
    `<a class="bn-item ${active(p) ? 'active' : ''} ${p === '/client/new' ? 'bn-main' : ''}" href="#${p}" aria-label="${short}" ${p === '/client/new' ? 'data-new-request' : ''}><span class="bn-icon">${ic(icon)}${badge(p)}</span><span>${short}</span></a>`).join('')
    + (role === 'admin' ? `<a class="bn-item ${path === '/profile' ? 'active' : ''}" href="#/profile" aria-label="Profil"><span class="bn-icon">${ic('user')}</span><span>Profil</span></a>` : '');
}

function closeSidebar() { $('sidebar').classList.remove('open'); $('sidebarOverlay').classList.remove('show'); }

/* ---------------------------------------------------------------------
   Authentification
   --------------------------------------------------------------------- */
function authErrorMessage(error) {
  const code = error.code || ''; const msg = (error.message || '').toLowerCase();
  if (code === 'email_not_confirmed' || msg.includes('not confirmed')) return 'Adresse e-mail non confirmée. Cliquez sur le lien reçu par e-mail (pensez aux courriers indésirables).';
  if (code === 'invalid_credentials' || msg.includes('invalid login')) return 'E-mail ou mot de passe incorrect.';
  if (error.status === 429 || code.includes('rate_limit')) return 'Trop de tentatives. Patientez quelques minutes puis réessayez.';
  if (code === 'user_already_exists' || msg.includes('already registered')) return 'Un compte existe déjà avec cette adresse e-mail. Connectez-vous.';
  if (code === 'weak_password') return 'Mot de passe trop faible (6 caractères minimum).';
  if (code === 'same_password') return 'Choisissez un mot de passe différent de l\'ancien.';
  if (code === 'over_email_send_rate_limit') return 'Trop d\'emails envoyés. Réessayez dans une heure.';
  return friendly(error);
}
function showAuthError(id, msg) {
  const el = $(id); el.textContent = msg; el.classList.add('show');
  clearTimeout(el._t); el._t = setTimeout(() => el.classList.remove('show'), 6000);
}

$('loginForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = $('loginEmail').value.trim().toLowerCase(), pass = $('loginPass').value, btn = $('loginBtn');
  if (!EMAIL_RE.test(email)) { markField($('loginEmail')); return showAuthError('loginError', 'Indiquez une adresse e-mail valide.'); }
  if (!pass) { markField($('loginPass')); return showAuthError('loginError', 'Indiquez votre mot de passe.'); }
  if (btn.disabled) return;
  busy(btn, true, 'Connexion…');
  try {
    const { error } = await sb.auth.signInWithPassword({ email, password: pass });
    try { localStorage.removeItem(LOGOUT_MARK); } catch (_) {}
    if (error) return showAuthError('loginError', authErrorMessage(error));
    if (!(await loadProfile())) {
      if (_profileError) return showAuthError('loginError', _profileError);
      await sb.auth.signOut(); return showAuthError('loginError', 'Profil introuvable. Contactez le support.');
    }
    $('loginPass').value = '';
    toast(`Bienvenue ${currentUser.full_name || currentUser.email} !`);
    navigate(homeOf(currentUser));
  } catch (err) { showAuthError('loginError', friendly(err)); } finally { busy(btn, false); }
});

$('forgotLink').addEventListener('click', (e) => {
  e.preventDefault();
  $('forgotEmail').value = $('loginEmail').value.trim();
  $('forgotAsk').hidden = false; $('forgotDone').hidden = true; $('forgotForm').classList.remove('is-done');
  navigate('/forgot');
});

$('resetForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const p1 = $('resetPass').value, p2 = $('resetPass2').value, btn = $('resetBtn');
  if (p1.length < 6) return invalid($('resetPass'), 'Mot de passe trop court (6 caractères minimum).');
  if (p1 !== p2) return invalid($('resetPass2'), 'Les deux mots de passe ne correspondent pas.');
  busy(btn, true, 'Enregistrement…');
  try {
    const { error } = await sb.auth.updateUser({ password: p1 });
    if (error) return showAuthError('resetError', authErrorMessage(error));
    _recovering = false; $('resetPass').value = ''; $('resetPass2').value = '';
    await loadProfile();
    toast('Mot de passe modifié.');
    navigate(currentUser ? homeOf(currentUser) : '/login');
  } catch (err) { showAuthError('resetError', friendly(err)); } finally { busy(btn, false); }
});

$('registerForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const name = $('regName').value.trim().replace(/\s+/g, ' '), email = $('regEmail').value.trim().toLowerCase(), phone = $('regPhone').value.trim(), pass = $('regPass').value;
  const bad = (id, msg) => { markField($(id)); showAuthError('registerError', msg); };
  if (name.length < 3 || name.length > 80) return bad('regName', 'Nom complet : 3 à 80 caractères.');
  if (!EMAIL_RE.test(email)) return bad('regEmail', 'Adresse e-mail invalide.');
  if (!PHONE_OK(phone)) return bad('regPhone', 'Téléphone invalide (9 chiffres, ex : 77 123 45 67).');
  if (pass.length < 6 || pass.length > 72) return bad('regPass', 'Mot de passe : 6 à 72 caractères.');
  const btn = $('registerBtn'); if (btn.disabled) return; busy(btn, true, 'Création…');
  try {
    const { data, error } = await sb.auth.signUp({ email, password: pass, options: { data: { full_name: name, phone } } });
    if (error) return showAuthError('registerError', authErrorMessage(error));
    $('regPass').value = '';
    if (data.session) { await loadProfile(); toast('Compte créé !'); navigate(homeOf(currentUser)); }
    else { toast('Compte créé ! Confirmez votre e-mail puis connectez-vous.', 'info'); navigate('/login'); }
  } catch (err) { showAuthError('registerError', friendly(err)); } finally { busy(btn, false); }
});

/* Déconnexion : l'écran change immédiatement ; le nettoyage côté serveur (notifications, jeton)
   se fait ensuite en arrière-plan et ne peut plus bloquer ni retarder la déconnexion. */
const AUTH_KEY_RE = /^sb-.*-auth-token$/;
const sleep = (ms) => new Promise((ok) => setTimeout(ok, ms));
const LOGOUT_MARK = 'nexusLoggedOut';
function dropLocalSession() { try { Object.keys(localStorage).filter((k) => AUTH_KEY_RE.test(k)).forEach((k) => localStorage.removeItem(k)); } catch (_) {} }
let _logoutAsk = false;
async function logout() {
  if (_logoutAsk) return; // un seul dialogue, même en cas de double appui
  _logoutAsk = true;
  let ok;
  try { ok = await askDialog({ title: 'Se déconnecter ?', message: 'Vous pourrez vous reconnecter à tout moment avec votre e-mail.', confirmText: 'Se déconnecter', icon: 'logout' }); }
  finally { _logoutAsk = false; }
  if (!ok || !currentUser) return;
  const { data: { session } } = await sb.auth.getSession(); // lecture locale, instantanée
  const token = session?.access_token || '';
  try { localStorage.setItem(LOGOUT_MARK, token); } catch (_) {}
  teardownSession(); clearUserCache();
  navigate('/home'); toast('Déconnecté.', 'info');
  // Arrière-plan : désinscription des notifications puis fin de session sur le serveur (délais limités).
  (async () => {
    const same = async () => ((await sb.auth.getSession()).data.session?.access_token || '') === token;
    await Promise.race([unsubscribePush(), sleep(3000)]);
    if (token && await same()) {
      const r = await Promise.race([sb.auth.signOut().catch((e) => ({ error: e })), sleep(6000).then(() => ({ error: 'délai' }))]);
      if (r && r.error && await same()) dropLocalSession(); // serveur injoignable : la session locale est effacée quand même
    }
    try { if (localStorage.getItem(LOGOUT_MARK) === token) localStorage.removeItem(LOGOUT_MARK); } catch (_) {}
  })();
}
$('logoutBtn').addEventListener('click', logout);

/* ---------------------------------------------------------------------
   Notifications (cloche + temps réel + notifications du téléphone)
   --------------------------------------------------------------------- */
let _notifs = [], _notifChannel = null;

async function loadNotifications() {
  if (!currentUser) return;
  try {
    const { data } = await q(sb.from('notifications').select('id,request_id,title,body,read_at,created_at,link')
      .eq('user_id', currentUser.id).order('created_at', { ascending: false }).limit(30));
    _notifs = data || [];
    renderBell();
  } catch (_) { /* hors ligne : on réessaiera au retour de la connexion */ }
}
async function startNotifications() {
  if (_notifChannel || !currentUser) return;
  _notifChannel = 'starting'; // évite deux abonnements si deux pages s'ouvrent vite
  await loadNotifications();
  if (!currentUser) { _notifChannel = null; return; }
  subscribePush();
  refreshMsgBadge();
  _notifChannel = sb.channel('notif-' + currentUser.id)
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: `user_id=eq.${currentUser.id}` }, (p) => {
      const n = p.new;
      if (_notifs.some((x) => x.id === n.id)) return;
      _notifs.unshift(n); _notifs = _notifs.slice(0, 30);
      renderBell();
      if (document.hidden) systemNotify(n.title, n.body, n.request_id, n.link);
      if (n.link && n.link.includes('/messages')) { refreshMsgBadge(); if (refreshMessages(n.link)) { beep(); return; } }
      toast(`${n.title} — ${n.body || ''}`, 'info');
      beep();
      refreshIfRelevant(n.request_id);
    })
    .subscribe();
}

/* Met la page à jour, sauf si l'utilisateur est en train de saisir quelque chose :
   dans ce cas une barre « Actualiser » apparaît, sa saisie n'est jamais effacée. */
function isEditing() {
  const c = $('content'); const a = document.activeElement;
  return c.dataset.dirty === '1' || (a && c.contains(a) && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) && a.id !== 'adminSearch');
}
function refreshIfRelevant(requestId) {
  invalidateData();
  const h = location.hash;
  const lists = ['#/admin/dashboard', '#/admin/requests', '#/client/dashboard', '#/client/requests'];
  if (!(lists.includes(h) || (requestId && h.endsWith('/' + requestId)))) return;
  if (isEditing()) showUpdateBar(); else route();
}
function showUpdateBar() { $('updateBar').hidden = false; }
function hideUpdateBar() { const b = $('updateBar'); if (b) b.hidden = true; }

function renderBell() {
  const unread = _notifs.filter((n) => !n.read_at).length;
  document.querySelectorAll('[data-bell-count]').forEach((c) => { c.textContent = unread > 9 ? '9+' : unread; c.classList.toggle('show', unread > 0); });
  const panel = $('notifPanel');
  const perm = 'Notification' in window ? Notification.permission : 'unsupported';
  panel.innerHTML = `
    <div class="notif-head"><strong>🔔 Notifications</strong>
      ${perm === 'default' ? '<button class="btn btn-ghost btn-sm" onclick="enablePush()">Activer sur ce téléphone</button>' : ''}</div>
    ${_notifs.length ? _notifs.map((n) => `
      <div class="notif-item ${n.read_at ? '' : 'unread'}" onclick="openNotif(${jsArg(n.request_id || '')}, ${jsArg(n.link || '')})">
        <div class="t">${esc(n.title)}</div><div class="b">${esc(n.body)}</div><div class="d">${fmtDateTime(n.created_at)}</div>
      </div>`).join('') : `<div class="notif-empty">${emptyArt('bell')}<strong>Tout est à jour</strong><span>Vos notifications apparaîtront ici.</span></div>`}`;
}

async function toggleNotifPanel(force) {
  const panel = $('notifPanel');
  const show = force ?? !panel.classList.contains('show');
  panel.classList.toggle('show', show);
  if (show && _notifs.some((n) => !n.read_at)) {
    try { await rpc('notifications_mark_read', {}); } catch (_) {}
    const now = new Date().toISOString();
    setTimeout(() => { _notifs.forEach((n) => { n.read_at = n.read_at || now; }); renderBell(); }, 1500);
  }
}
function openNotif(requestId, link) {
  toggleNotifPanel(false);
  if (link && /^\/[\w/-]+$/.test(link) && currentUser) return navigate(link);
  if (requestId && currentUser) navigate(`/${currentUser.role === 'admin' ? 'admin' : 'client'}/requests/${requestId}`);
}
async function enablePush() {
  if (!('Notification' in window)) {
    return toast(isIOS && !isStandalone() ? "Sur iPhone, installez d'abord l'application (Partager → « Sur l'écran d'accueil »), puis activez les notifications depuis l'appli." : 'Notifications non prises en charge sur cet appareil.', 'error');
  }
  const p = await Notification.requestPermission();
  if (p === 'granted') {
    const pushed = await subscribePush();
    toast(pushed ? 'Notifications activées, même appli fermée.' : 'Notifications activées.', 'success');
  } else toast('Notifications refusées. Vous pouvez les autoriser dans les réglages du navigateur.', 'error');
  renderBell();
}
function beep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator(), v = ctx.createGain();
    o.frequency.value = 880; o.connect(v); v.connect(ctx.destination);
    v.gain.setValueAtTime(0.15, ctx.currentTime); v.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);
    o.start(); o.stop(ctx.currentTime + 0.5);
  } catch (_) {}
}

/* ---------------------------------------------------------------------
   Paramètres (votre numéro Wave + adresse de réception)
   --------------------------------------------------------------------- */
let _settings = null;
async function getSettings(force) {
  if (_settings && !force) return _settings;
  let res;
  try { res = await sb.from('app_settings').select('*').eq('id', 1).single(); } catch (e) { throw new AppError(friendly(e)); }
  if (res.error) throw new AppError(navigator.onLine ? 'Paramètres introuvables : lancez le script SQL nexus_v9.sql.' : friendly(res.error));
  return (_settings = res.data);
}

/* ---------------------------------------------------------------------
   Échéances : compte à rebours
   --------------------------------------------------------------------- */
const garantieText = (r) => `${String(r.garantie || '').trim() || '—'} + Passeport N° ${String(r.passeport || '').trim() || '—'}`;
function parseDay(d) {
  if (!d) return null;
  const m = String(d).match(/^(\d{4})-(\d{2})-(\d{2})/);
  if (m) return new Date(+m[1], +m[2] - 1, +m[3]);
  const x = new Date(d);
  return isNaN(x) ? null : new Date(x.getFullYear(), x.getMonth(), x.getDate());
}
const fmtDue = (d) => { const x = parseDay(d); return x ? x.toLocaleDateString('fr-FR') : '—'; };
function daysLeft(r) {
  const due = parseDay(r.date_remboursement); if (!due) return null;
  const t = new Date();
  return Math.round((due - new Date(t.getFullYear(), t.getMonth(), t.getDate())) / 86400000);
}
/* Seuls les prêts versés ont une échéance qui court. */
function dueInfo(r) {
  if (!['paid', 'repayment_requested'].includes(r.status)) return null;
  const d = daysLeft(r); if (d === null) return null;
  const s = (n) => (n > 1 ? 's' : '');
  if (r.status === 'repayment_requested') return { d, level: 'ok', short: 'En vérification', label: 'Remboursement en vérification' };
  if (d <= -EXIGIBLE_FROM) return { d, level: 'late', exigible: true, short: `Retard ${-d} j`, label: `🚨 ${-d} jours de retard : totalité exigible immédiatement` };
  if (d < 0) return { d, level: 'late', short: `Retard ${-d} j`, label: `⚠️ En retard de ${-d} jour${s(-d)} (exigible dans ${EXIGIBLE_FROM + d} j)` };
  if (d === 0) return { d, level: 'late', short: "Aujourd'hui", label: "⚠️ À rembourser aujourd'hui" };
  if (d <= 2) return { d, level: 'soon', short: `J-${d}`, label: `⏰ Plus que ${d} jour${s(d)}` };
  return { d, level: 'ok', short: `J-${d}`, label: `${d} jours restants` };
}
/* Contacts d'urgence (2 proches à joindre si le client ne rembourse pas) — carte admin */
function emergencyCardHtml(r) {
  const late = lateDays(r) > 0;
  const people = [[r.contact1_name, r.contact1_phone], [r.contact2_name, r.contact2_phone]].filter(([, t]) => t);
  if (!people.length) return `<section class="card ec-admin" aria-label="Contacts d'urgence"><div class="card-title">${ic('phone', 'ic-sm')}Contacts d'urgence</div>
    <p class="muted">Non renseignés : demande envoyée avant l'ajout des contacts d'urgence.</p></section>`;
  const msg = (n) => `Bonjour ${n}, ${r.nom} vous a désigné(e) comme contact d'urgence auprès de Nexus Crédit. Pouvez-vous l'aider à nous joindre au sujet de son remboursement ? Merci.`;
  return `<section class="card ec-admin ${late ? 'is-late' : ''}" aria-label="Contacts d'urgence">
    <div class="card-title">${ic('phone', 'ic-sm')}Contacts d'urgence ${late ? `<span class="badge badge-rejected">Retard de ${lateDays(r)} j : à contacter</span>` : ''}</div>
    <div class="ec-list">${people.map(([n, t], i) => `<div class="ec-person">
      <span class="ec-avatar">${esc(String(n || '?').trim().split(/\s+/).slice(0, 2).map((w) => w.charAt(0).toUpperCase()).join(''))}</span>
      <div class="ec-who"><small>Contact ${i + 1}</small><strong>${esc(n || '—')}</strong><a class="wave" href="tel:+${intlPhone(t)}">${esc(fmtPhone(t))}</a></div>
      <div class="ec-actions">
        <a class="btn btn-wa btn-sm" target="_blank" rel="noopener" href="${waLink(t, msg(n || ''))}" aria-label="Écrire à ${esc(n || '')} sur WhatsApp">${ic('chat')}<span>WhatsApp</span></a>
        <a class="btn btn-secondary btn-sm" href="tel:+${intlPhone(t)}" aria-label="Appeler ${esc(n || '')}">${ic('phone')}<span>Appeler</span></a>
      </div></div>`).join('')}</div>
  </section>`;
}
/* Contrat, section 6 : 2 500 FCFA par jour de retard ; exigibilité immédiate à partir du 4e jour de retard. */
const PENALTY_PER_DAY = 2500;
const EXIGIBLE_FROM = 4;
const lateDays = (r) => { if (r.status !== 'paid') return 0; const d = daysLeft(r); return d !== null && d < 0 ? -d : 0; };
const penaltyOf = (r) => lateDays(r) * PENALTY_PER_DAY;
const amountDue = (r) => (Number(r.total) || 0) + penaltyOf(r);
/* Temps restant jusqu'à la fin du jour d'échéance (23 h 59), pour le compte à rebours en direct. */
function liveLeft(due) {
  const end = parseDay(due); if (!end) return '';
  end.setHours(23, 59, 59, 999);
  const ms = end - Date.now(); if (ms <= 0) return '';
  const h = Math.floor(ms / 3600000), m = Math.floor((ms % 3600000) / 60000);
  return h >= 24 ? '' : `${h} h ${String(m).padStart(2, '0')} min`;
}
setInterval(() => document.querySelectorAll('[data-live-due]').forEach((el) => {
  const t = liveLeft(el.dataset.liveDue); el.textContent = t ? `⏱ Il reste ${t}` : '';
}), 30000);
const dueChip = (r) => { const i = dueInfo(r); return i ? `<span class="due-chip ${i.level}">${esc(i.short)}</span>` : ''; };

/* Historique d'une demande : chaque étape datée. */
function timelineHtml(r) {
  const ev = [
    [r.created_at, 'pen', 'Demande envoyée', `${fcfa(r.montant)} sur ${r.duree} jours`],
    [r.guarantee_declared_at, 'box', 'Garantie annoncée', r.wave_number ? 'Wave : ' + fmtPhone(r.wave_number) : ''],
    [r.guarantee_received_at, 'check', 'Garantie reçue', ''],
    [r.paid_at, 'wallet', 'Argent envoyé', `${fcfa(r.paid_amount || r.montant)}${r.receipt_number ? ' · reçu ' + r.receipt_number : ''}`],
    [r.repayment_requested_at, 'send', 'Remboursement déclaré', r.repayment_amount ? `${fcfa(r.repayment_amount)} · réf. ${r.repayment_ref || ''}` : ''],
    [r.repaid_at, 'star', 'Prêt remboursé', ''],
    [r.guarantee_returned_at, 'shield', 'Garantie restituée', r.guarantee_return_note || 'Bien et passeport rendus.'],
  ].filter((e) => e[0]);
  if (r.status === 'rejected') ev.push([r.updated_at || r.created_at, 'x', 'Demande refusée', r.rejection_reason || '']);
  ev.sort((a, b) => new Date(a[0]) - new Date(b[0]));
  if (r.paid_at && ['paid', 'repayment_requested'].includes(r.status)) ev.push([null, 'calendar', 'Échéance', `${fcfa(r.total)} à rembourser avant le ${fmtDue(r.date_remboursement)}`]);
  if (r.status === 'done' && !r.guarantee_returned_at) ev.push([null, 'shield', 'Restitution de la garantie', 'Votre bien et votre passeport vous seront rendus. Vous serez notifié.']);
  return `<ol class="timeline">${ev.map(([d, icon, title, sub]) => `<li class="${d ? '' : 'future'}">
    <span class="tl-dot">${ic(icon)}</span>
    <div><div class="tl-title">${esc(title)}</div>${sub ? `<div class="muted">${esc(sub)}</div>` : ''}<div class="tl-date">${d ? fmtDateTime(d) : 'à venir'}</div></div>
  </li>`).join('')}</ol>`;
}

function countdownCard(r) {
  const i = dueInfo(r);
  if (!i) return '';
  const start = parseDay(r.paid_at) || parseDay(r.created_at);
  const due = parseDay(r.date_remboursement);
  const total = Math.max(1, Math.round((due - start) / 86400000));
  const pct = Math.min(100, Math.max(0, Math.round(((total - Math.max(i.d, 0)) / total) * 100)));
  const big = r.status === 'repayment_requested' ? '⏳' : i.d < 0 ? `+${-i.d}` : i.d;
  const unit = r.status === 'repayment_requested' ? 'vérification en cours' : i.d < 0 ? `jour${-i.d > 1 ? 's' : ''} de retard` : i.d === 0 ? "dernier jour" : `jour${i.d > 1 ? 's' : ''} restant${i.d > 1 ? 's' : ''}`;
  return `<div class="countdown ${i.level}" data-cd="${esc(r.id)}">
    <div class="cd-left"><div class="cd-num">${big}</div><div class="cd-unit">${unit}</div></div>
    <div class="cd-body">
      <div class="cd-title">${esc(i.label)}</div>
      ${r.status === 'paid' && i.d >= 0 && i.d <= 1 ? `<div class="cd-live" data-live-due="${esc(r.date_remboursement)}">${liveLeft(r.date_remboursement) ? '⏱ Il reste ' + liveLeft(r.date_remboursement) : ''}</div>` : ''}
      ${penaltyOf(r) ? `<div class="cd-pen">Majoration de retard : ${lateDays(r)} j × ${fcfa(PENALTY_PER_DAY)} = <strong>${fcfa(penaltyOf(r))}</strong><br>Montant dû aujourd'hui : <strong>${fcfa(amountDue(r))}</strong></div>` : ''}
      ${i.exigible ? `<div class="cd-warn">Conformément à votre contrat (section 6), la totalité de la somme due est exigible immédiatement. Remboursez dès que possible.</div>` : ''}
      <div class="muted">Prêt de ${fcfa(r.montant)} · à rembourser <strong>${fcfa(r.total)}</strong> au plus tard le <strong>${fmtDue(r.date_remboursement)}</strong></div>
      <div class="progress" style="margin:10px 0;"><div style="width:${pct}%"></div></div>
      <div class="row-actions">
        ${r.status === 'paid' ? `<a class="btn btn-primary btn-sm" href="#/client/requests/${esc(r.id)}">💰 Rembourser</a>` : `<a class="btn btn-ghost btn-sm" href="#/client/requests/${esc(r.id)}">Voir</a>`}
        ${docButtons(r)}
      </div>
    </div>
  </div>`;
}

/* =====================================================================
   CONTRAT (texte officiel — une seule source pour l'écran et le PDF)
   Toute modification du texte doit changer CONTRACT_VERSION (et le script SQL).
   ===================================================================== */
const CONTRACT_VERSION = 'NXC-CONTRAT-2026-11-C';
const CONTRACT = {
  logo: 'NEXUS CRÉDIT',
  subtitle: 'RAPIDE • SÉCURISÉ • FIABLE',
  title: "CONTRAT DE PRÊT D'ARGENT",
  sections: [
    ['SECTION 1 – LES INTERVENANTS', [
      ['p', 'Bailleur de fonds : NEXUS CRÉDIT (entreprise enregistrée au Sénégal), joignable au 78 664 90 62, siège social à Dakar.'],
      ['p', 'Emprunteur : personne physique dont les coordonnées (nom, téléphone WhatsApp, numéro de passeport) sont fournies dans le formulaire.'],
    ]],
    ["SECTION 2 – BUT DE L'ACCORD", [
      ['p', "Formaliser l'octroi d'une avance de fonds à titre personnel. Le Bailleur verse la somme, l'Emprunteur s'engage à la restituer avec frais et majorations."],
    ]],
    ['SECTION 3 – SOMME AVANCÉE', [
      ['p', 'Montant accordé selon la requête validée, en Francs CFA, transféré en une seule transaction après validation du dossier.'],
    ]],
    ['SECTION 4 – CALENDRIER ET FRAIS', [
      ['li', 'Formule express : 7 jours → +25 %'],
      ['li', 'Formule classique : 14 jours → +35 %'],
      ['p', 'Cas pratique pour 50 000 FCFA :'],
      ['li', 'Express : 12 500 FCFA de frais → total 62 500 FCFA'],
      ['li', 'Classique : 17 500 FCFA de frais → total 67 500 FCFA'],
      ['p', "« Par exemple, si vous demandez un nouveau prêt alors qu'un prêt est déjà en cours, le taux d'intérêt augmente : au lieu de 25 % pour une semaine, il passe à 35 % ; au lieu de 35 % pour deux semaines, il passe à 45 %. »"],
    ]],
    ['SECTION 5 – ÉCHÉANCE DE REMBOURSEMENT', [
      ['p', "Date butoir = date à laquelle l'Emprunteur consulte dans l'application la preuve du versement (capture du reçu Wave) + délai retenu (7 ou 14 jours)."],
      ['p', "Si l'Emprunteur ne consulte pas cette preuve, le délai démarre automatiquement 24 heures après le versement."],
      ['p', 'Passé cette échéance, majorations selon section 6.'],
    ]],
    ['SECTION 6 – MAJORATIONS POUR RETARD', [
      ['li', '2 500 FCFA par jour de retard'],
      ['li', 'À partir du 4ème jour de retard : exigibilité immédiate de la totalité de la somme due'],
      ['li', 'Au-delà de 3 jours de retard : procédures de recouvrement judiciaire'],
    ]],
    ['SECTION 7 – GARANTIES FOURNIES', [
      ['li', 'Passeport original (numéro enregistré)'],
      ['li', 'Un objet de valeur supplémentaire (téléphone, ordinateur, tablette, bijoux…)'],
      ['p', "Ces biens restent détenus par le Bailleur jusqu'à libération complète de la dette."],
    ]],
    ["SECTION 8 – OBLIGATIONS DE L'EMPRUNTEUR", [
      ['li', 'Avoir perçu la somme'],
      ['li', 'Avoir pris connaissance des taux et majorations'],
      ['li', "Restituer l'intégralité avant l'échéance"],
      ['li', 'Être majeur (18 ans) et juridiquement capable'],
      ['li', 'Avoir communiqué des informations exactes et vérifiables'],
      ['li', "Avoir désigné deux contacts d'urgence joignables sur WhatsApp et les avoir prévenus"],
    ]],
    ['SECTION 9 – PROCÉDURE DE RECOUVREMENT', [
      ['p', "En cas de retard de remboursement, l'Emprunteur est informé et accepte que NEXUS CRÉDIT appelle ou contacte par WhatsApp les deux contacts d'urgence qu'il a désignés dans le formulaire."],
      ['li', 'Avis de mise en demeure'],
      ['li', 'Saisie conservatoire des garanties (passeport et bien déposé)'],
      ['li', 'Poursuite judiciaire devant les juridictions sénégalaises'],
      ['li', 'Signalement auprès des organismes de gestion des incidents de crédit'],
    ]],
    ['SECTION 10 – DISCRÉTION', [
      ['p', 'Informations traitées de manière strictement confidentielle.'],
    ]],
    ['SECTION 11 – RÈGLEMENT DES DIFFÉRENDS', [
      ['p', 'Litiges soumis aux tribunaux compétents du Sénégal.'],
    ]],
  ],
  footer: (date) => `Contrat à lire attentivement avant toute demande - Fait à Dakar, le ${date}`,
  legal: 'Conformément aux lois sénégalaises, ce contrat a valeur légale.',
};

/* Échéance affichable : avant le versement, elle n'est pas encore fixée (contrat, section 5) */
const notPaidYet = (r) => !r.paid_at && ['pending', 'guarantee_received', 'rejected'].includes(r.status);
const dueTxt = (r) => (notPaidYet(r) ? `${r.duree} j après le versement` : fmtDue(r.date_remboursement));
const contactText = (n, t) => (n || t ? `${n || '—'} · WhatsApp ${fmtPhone(t) || '—'}` : '—');
/* Données personnelles insérées en tête du contrat (formulaire en cours ou demande signée). */
function contractParticulars(r) {
  const taux = Number(r.duree) === 7 ? 25 : Number(r.duree) === 14 ? 35 : null;
  const total = r.total || (r.montant && taux ? Math.round(r.montant * (1 + taux / 100)) : null);
  // Échéance (section 5) : connue seulement une fois la preuve de versement envoyée
  let due = r.payment_proof_at || (r.paid_at && !['pending', 'guarantee_received'].includes(r.status)) ? fmtDue(r.date_remboursement) : null;
  if (!due && r.duree) due = `${r.duree} jours après la consultation de la preuve de versement (au plus tard 24 h après le versement)`;
  return [
    ['Emprunteur', r.nom || '—'], ['Téléphone WhatsApp', fmtPhone(r.telephone) || r.telephone || '—'],
    ['Passeport N°', r.passeport || '—'],
    ['Montant accordé', r.montant ? fcfa(r.montant) : '—'],
    ['Formule', taux ? `${Number(r.duree) === 7 ? 'Express' : 'Classique'} : ${r.duree} jours → +${taux} %` : '—'],
    ['Total à rembourser', total ? fcfa(total) : '—'],
    ['Date butoir', due || '—'],
    ['Garanties', garantieText(r)],
    ["Contact d'urgence 1", contactText(r.contact1_name, r.contact1_phone)],
    ["Contact d'urgence 2", contactText(r.contact2_name, r.contact2_phone)],
  ];
}

/* Contrat à l'écran (bouton « Voir le contrat ») */
function contractHtmlView(r, dateText) {
  return `<div class="contract">
    <div class="ct-head"><div class="ct-logo">${esc(CONTRACT.logo)}</div><div class="ct-sub">${esc(CONTRACT.subtitle)}</div></div>
    <h2 class="ct-title">${esc(CONTRACT.title)}</h2>
    <div class="ct-box">${contractParticulars(r).map(([k, v]) => `<div class="ct-row"><span>${esc(k)}</span><strong>${esc(v)}</strong></div>`).join('')}</div>
    ${CONTRACT.sections.map(([title, blocks]) => `<section><h3>${esc(title)}</h3>${
      blocks.map(([type, text], i) => type === 'li'
        ? `${i === 0 || blocks[i - 1][0] !== 'li' ? '<ul>' : ''}<li>${esc(text)}</li>${i === blocks.length - 1 || blocks[i + 1][0] !== 'li' ? '</ul>' : ''}`
        : `<p>${esc(text)}</p>`).join('')}</section>`).join('')}
    <div class="ct-sign">
      <div><strong>Le Bailleur</strong><span>NEXUS CRÉDIT</span></div>
      <div><strong>L'Emprunteur</strong>${r.signature_preview ? `<img src="${r.signature_preview}" alt="Votre signature">` : '<em class="muted">Signature à apposer dans le formulaire</em>'}<span>Lu et approuvé${r.nom ? ' — ' + esc(r.nom) : ''}</span></div>
    </div>
    <div class="ct-foot"><p>${esc(CONTRACT.footer(dateText))}</p><p>${esc(CONTRACT.legal)}</p></div>
  </div>`;
}

function openContractViewer(r, onRead) {
  $('contractBody').innerHTML = contractHtmlView(r, new Date().toLocaleDateString('fr-FR'));
  $('contractModal').classList.add('show');
  $('contractBody').scrollTop = 0;
  $('contractRead').onclick = () => { closeContractViewer(); if (onRead) onRead(); };
}
function closeContractViewer() { $('contractModal').classList.remove('show'); }

/* ---------------------------------------------------------------------
   Documents PDF : contrat et reçu de prêt
   Générés à la demande à partir de la base (accès contrôlé par RLS :
   un client ne peut ouvrir que ses propres documents).
   --------------------------------------------------------------------- */
const JSPDF_URL = 'https://cdn.jsdelivr.net/npm/jspdf@2.5.2/dist/jspdf.umd.min.js';
let _jspdf = null, _docUrl = null;
function loadJsPdf() {
  if (window.jspdf) return Promise.resolve(window.jspdf.jsPDF);
  if (!_jspdf) _jspdf = new Promise((resolve, reject) => {
    const s = document.createElement('script');
    s.src = JSPDF_URL; s.crossOrigin = 'anonymous';
    s.onload = () => resolve(window.jspdf.jsPDF);
    s.onerror = () => { _jspdf = null; reject(new Error('Impossible de charger le générateur PDF. Vérifiez votre connexion.')); };
    document.head.appendChild(s);
  });
  return _jspdf;
}
// Les polices PDF standard n'acceptent que l'alphabet latin : on retire émojis et espaces spéciaux.
const pdfTxt = (s) => String(s ?? '').replace(/[\u202f\u00a0]/g, ' ').replace(/[\u2018\u2019]/g, "'")
  .replace(/\u2192/g, '->').replace(/[\u2013\u2014]/g, '-').replace(/\u2022/g, '\u00b7').replace(/\u2026/g, '...')
  .replace(/[^\x09\x0a\x0d\x20-\xff]/g, '').trim();
const pdfMoney = (n) => String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' FCFA';
const tauxOf = (r) => (Number(r.duree) === 7 ? 25 : 35);
const contractRef = (r) => 'NXC-C-' + String(r.id).replace(/-/g, '').slice(0, 8).toUpperCase();

const docButtons = (r, compact = false) => {
  const c = `<button class="btn btn-pdf btn-sm" onclick="openDoc('contract', ${jsArg(r.id)})" title="Contrat PDF">📄${compact ? '' : ' Contrat'}</button>`;
  const rc = r.receipt_number ? `<button class="btn btn-ghost btn-sm" onclick="openDoc('receipt', ${jsArg(r.id)})" title="Reçu PDF">🧾${compact ? '' : ' Reçu'}</button>` : '';
  return c + ' ' + rc;
};

const GREEN = [11, 31, 58], GOLD = [190, 146, 30], GREY = [110, 110, 110];

function pdfHeader(doc, title, subtitle) {
  const W = doc.internal.pageSize.getWidth();
  doc.setFillColor(...GREEN); doc.rect(0, 0, W, 26, 'F'); doc.setFillColor(16, 185, 129); doc.rect(0, 26, W, 1.4, 'F');
  doc.setTextColor(255, 255, 255); doc.setFont('helvetica', 'bold'); doc.setFontSize(18);
  doc.text('NEXUS CRÉDIT', 14, 13);
  doc.setFont('helvetica', 'normal'); doc.setFontSize(8);
  doc.text(pdfTxt(CONTRACT.subtitle + '   |   Dakar, Sénégal   |   78 664 90 62'), 14, 20);
  doc.setTextColor(...GREEN); doc.setFont('helvetica', 'bold'); doc.setFontSize(15);
  doc.text(pdfTxt(title), W / 2, 38, { align: 'center' });
  if (subtitle) { doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(...GREY); doc.text(pdfTxt(subtitle), W / 2, 44, { align: 'center' }); }
  return 52;
}
function pdfSection(doc, y, title) {
  const W = doc.internal.pageSize.getWidth();
  doc.setTextColor(...GREEN); doc.setFont('helvetica', 'bold'); doc.setFontSize(10.5);
  doc.text(pdfTxt(title).toUpperCase(), 14, y);
  doc.setDrawColor(...GREEN); doc.setLineWidth(0.5); doc.line(14, y + 1.5, W - 14, y + 1.5);
  return y + 8;
}
function pdfRows(doc, y, rows, keyW = 58) {
  const W = doc.internal.pageSize.getWidth();
  doc.setFontSize(10);
  for (const [k, v, strong] of rows) {
    const lines = doc.splitTextToSize(pdfTxt(v), W - 14 - 14 - keyW);
    doc.setFont('helvetica', 'normal'); doc.setTextColor(...GREY); doc.text(pdfTxt(k), 14, y);
    doc.setFont('helvetica', 'bold'); doc.setTextColor(strong ? GREEN[0] : 20, strong ? GREEN[1] : 20, strong ? GREEN[2] : 20);
    doc.text(lines, 14 + keyW, y);
    y += 5.2 * lines.length + 1.8;
    doc.setDrawColor(230, 230, 230); doc.setLineWidth(0.2); doc.line(14, y - 3.4, W - 14, y - 3.4);
  }
  return y + 2;
}
function pdfFooter(doc, text) {
  const W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight();
  doc.setFont('helvetica', 'normal'); doc.setFontSize(7.5); doc.setTextColor(150, 150, 150);
  doc.text(pdfTxt(text), W / 2, H - 8, { align: 'center' });
}

function buildContract(doc, r) {
  const W = doc.internal.pageSize.getWidth(), H = doc.internal.pageSize.getHeight();
  const signDate = fmtDate(r.contract_accepted_at || r.created_at);
  const bottom = H - 24;
  let y = 0;
  const ensure = (h) => { if (y + h > bottom) { doc.addPage(); y = 20; } };
  y = pdfHeader(doc, CONTRACT.title, `Réf. ${contractRef(r)}  -  signé le ${signDate}`);
  // Données de la demande
  const parts = contractParticulars(r);
  doc.setFontSize(9.5);
  const boxH = parts.reduce((h, [, v]) => h + 5.2 * doc.splitTextToSize(pdfTxt(v), W - 28 - 62).length + 1.2, 6);
  doc.setFillColor(244, 247, 252); doc.setDrawColor(...GREEN);
  doc.roundedRect(14, y - 4, W - 28, boxH, 2, 2, 'FD');
  for (const [k, v] of parts) {
    const lines = doc.splitTextToSize(pdfTxt(v), W - 28 - 62);
    doc.setFont('helvetica', 'normal'); doc.setTextColor(...GREY); doc.text(pdfTxt(k), 18, y);
    doc.setFont('helvetica', 'bold'); doc.setTextColor(20, 20, 20); doc.text(lines, 74, y);
    y += 5.2 * lines.length + 1.2;
  }
  y += 8;
  // Texte du contrat
  for (const [title, blocks] of CONTRACT.sections) {
    ensure(16);
    doc.setFont('helvetica', 'bold'); doc.setFontSize(10.5); doc.setTextColor(...GREEN);
    doc.text(pdfTxt(title), 14, y);
    doc.setDrawColor(...GREEN); doc.setLineWidth(0.3); doc.line(14, y + 1.5, W - 14, y + 1.5);
    y += 7;
    doc.setFont('helvetica', 'normal'); doc.setFontSize(9.5); doc.setTextColor(35, 35, 35);
    for (const [type, text] of blocks) {
      const indent = type === 'li' ? 20 : 14;
      const lines = doc.splitTextToSize(pdfTxt(text), W - 14 - indent);
      ensure(4.8 * lines.length + 1);
      if (type === 'li') doc.text('-', 16, y);
      doc.text(lines, indent, y);
      y += 4.8 * lines.length + 1.4;
    }
    y += 3;
  }
  // Signatures
  ensure(48);
  y += 4;
  const colW = (W - 28 - 10) / 2;
  doc.setDrawColor(150, 150, 150); doc.line(14, y, 14 + colW, y); doc.line(W - 14 - colW, y, W - 14, y);
  doc.setFont('helvetica', 'bold'); doc.setFontSize(10); doc.setTextColor(20, 20, 20);
  doc.text('Le Bailleur', 14 + colW / 2, y + 6, { align: 'center' });
  doc.text("L'Emprunteur", W - 14 - colW / 2, y + 6, { align: 'center' });
  doc.setFont('helvetica', 'normal'); doc.setFontSize(9);
  doc.text('NEXUS CRÉDIT', 14 + colW / 2, y + 12, { align: 'center' });
  const sig = /^data:image\/png;base64,/.test(r.signature_data_url || '') ? r.signature_data_url : null;
  if (sig) { try { doc.addImage(sig, 'PNG', W - 14 - colW + (colW - 60) / 2, y + 8, 60, 18); } catch (_) {} }
  doc.text(pdfTxt(`Lu et approuvé - signé électroniquement par ${r.nom}`), W - 14 - colW / 2, y + 31, { align: 'center' });
  doc.text(pdfTxt(`le ${signDate}${r.contract_version ? ' (contrat ' + r.contract_version + ')' : ''}`), W - 14 - colW / 2, y + 36, { align: 'center' });
  if (r.signature_sha256) {
    y += 44; ensure(30);
    doc.setDrawColor(200, 200, 200); doc.setFillColor(248, 248, 248); doc.roundedRect(14, y, W - 28, 24, 2, 2, 'FD');
    doc.setFont('helvetica', 'bold'); doc.setFontSize(8.5); doc.setTextColor(40, 40, 40);
    doc.text(pdfTxt('Preuve de signature électronique'), 18, y + 5.5);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(7.6); doc.setTextColor(80, 80, 80);
    const at = new Date(r.signed_at || r.contract_accepted_at);
    doc.text(pdfTxt(`Signé le ${at.toLocaleDateString('fr-FR')} à ${at.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })} (horodatage du serveur)   -   Adresse IP : ${r.signed_ip || 'non disponible'}   -   Appareil : ${deviceOf(r.signed_ua)}`), 18, y + 10.5);
    doc.text(pdfTxt(`Empreinte SHA-256 de la signature : ${r.signature_sha256}`), 18, y + 15.5);
    doc.text(pdfTxt('Toute modification de la signature changerait cette empreinte. La signature et le contrat ne peuvent plus être modifiés après l\'envoi.'), 18, y + 20.5);
  }
  // Pied de page sur chaque page : mention + date du jour + valeur légale + pagination
  const n = doc.getNumberOfPages();
  const today = new Date().toLocaleDateString('fr-FR');
  for (let i = 1; i <= n; i++) {
    doc.setPage(i);
    doc.setFont('helvetica', 'normal'); doc.setFontSize(7.8); doc.setTextColor(120, 120, 120);
    doc.text(pdfTxt(CONTRACT.footer(today)), W / 2, H - 13, { align: 'center' });
    doc.text(pdfTxt(`${CONTRACT.legal}   -   Réf. ${contractRef(r)}   -   page ${i}/${n}`), W / 2, H - 8, { align: 'center' });
  }
}

function buildReceipt(doc, r) {
  const W = doc.internal.pageSize.getWidth();
  let y = pdfHeader(doc, 'Reçu de prêt', `N° ${r.receipt_number}  -  émis le ${fmtDate(r.receipt_issued_at || r.paid_at)}`);
  y = pdfRows(doc, y, [
    ['N° de reçu', r.receipt_number, true],
    ['Date', fmtDate(r.receipt_issued_at || r.paid_at)],
    ['Client', r.nom],
    ['Téléphone', fmtPhone(r.telephone) || r.telephone],
    ['Montant emprunté', pdfMoney(r.paid_amount || r.montant), true],
    ['Durée', `${r.duree} jours`],
    ['Taux', `+${tauxOf(r)} %`],
    ['Total à rembourser', pdfMoney(r.total), true],
    ['Date de remboursement', fmtDue(r.date_remboursement)],
    ['Garantie', garantieText(r)],
    ...(r.wave_number ? [['Versé sur Wave', fmtPhone(r.wave_number)]] : []),
  ], 46);
  doc.setFont('helvetica', 'normal'); doc.setFontSize(8.5); doc.setTextColor(...GREY);
  doc.text(doc.splitTextToSize(pdfTxt(`Retard : 2 500 FCFA par jour. À partir du 4e jour de retard, la totalité de la somme due est exigible immédiatement (contrat, section 6).`), W - 28), 14, y);
  y += 9;
  doc.setFillColor(...GREEN); doc.roundedRect(14, y, W - 28, 11, 2, 2, 'F');
  doc.setTextColor(255, 255, 255); doc.setFont('helvetica', 'bold'); doc.setFontSize(10.5);
  doc.text(pdfTxt(`À rembourser : ${pdfMoney(r.total)} avant le ${fmtDue(r.date_remboursement)}`), W / 2, y + 7.2, { align: 'center' });
  pdfFooter(doc, `Reçu généré automatiquement - Nexus Crédit - contrat ${contractRef(r)}`);
}

const DOC_COLS = LIST_COLS + ',signature_data_url,signed_at,signature_sha256,signed_ip,signed_ua';
async function openDoc(kind, id) { return once('doc-' + kind + id, () => buildDoc(kind, id)); }
async function buildDoc(kind, id) {
  toast(kind === 'receipt' ? 'Préparation du reçu…' : 'Préparation du contrat…', 'info');
  try {
    const [JsPDF, res] = await Promise.all([loadJsPdf(), sb.from('requests').select(DOC_COLS).eq('id', id).maybeSingle()]);
    if (res.error) throw new Error(res.error.message);
    const r = res.data;
    if (!r) throw new Error('Document introuvable.');
    if (kind === 'receipt' && !r.receipt_number) throw new Error("Le reçu sera disponible dès que l'argent aura été envoyé.");
    const doc = new JsPDF({ unit: 'mm', format: kind === 'receipt' ? 'a5' : 'a4' });
    doc.setProperties({ title: kind === 'receipt' ? `Reçu ${r.receipt_number}` : `Contrat ${contractRef(r)}`, author: 'Nexus Crédit' });
    if (kind === 'receipt') buildReceipt(doc, r); else buildContract(doc, r);
    const file = kind === 'receipt' ? `recu-${r.receipt_number}.pdf` : `contrat-${contractRef(r)}.pdf`;
    showPdf(doc.output('blob'), file, kind === 'receipt' ? `🧾 Reçu ${r.receipt_number}` : `📄 Contrat ${contractRef(r)}`);
  } catch (e) { toast(e instanceof AppError ? e.message : friendly(e), 'error'); }
}
function showPdf(blob, filename, title) {
  if (_docUrl) URL.revokeObjectURL(_docUrl);
  _docUrl = URL.createObjectURL(blob);
  $('docTitle').textContent = title;
  $('pdfModalOpen').href = _docUrl;
  $('pdfModalDownload').onclick = () => {
    const a = document.createElement('a'); a.href = _docUrl; a.download = filename;
    document.body.appendChild(a); a.click(); a.remove();
  };
  // Sur téléphone, l'aperçu intégré est rarement possible : on propose Télécharger / Ouvrir.
  const inline = navigator.pdfViewerEnabled !== false && !matchMedia('(max-width: 860px)').matches;
  $('pdfModalFrame').hidden = !inline;
  $('pdfMobileHint').hidden = inline;
  $('pdfModalFrame').src = inline ? _docUrl : 'about:blank';
  $('pdfModal').classList.add('show');
}
function closeDoc() { $('pdfModal').classList.remove('show'); $('pdfModalFrame').src = 'about:blank'; }

/* =====================================================================
   CLIENT
   ===================================================================== */
const nextStepHint = (r) => ({
  pending: r.guarantee_declared_at ? 'Envoyez votre garantie par Yango' : 'Donnez votre numéro Wave',
  guarantee_received: 'Argent bientôt envoyé',
  paid: 'À rembourser avant le ' + fmtDue(r.date_remboursement),
  repayment_requested: 'Remboursement en vérification',
  done: 'Terminé', rejected: 'Refusée',
}[r.status] || '');

/* Illustration originale (porte-monnaie, pièces, téléphone) pour les écrans vides */
function emptyArt(kind = 'loan') {
  return `<svg class="empty-art" viewBox="0 0 220 160" aria-hidden="true">
    <defs><linearGradient id="ea1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="var(--green)"/><stop offset="1" stop-color="var(--green-dark)"/></linearGradient>
      <linearGradient id="ea2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fcd34d"/><stop offset="1" stop-color="#f59e0b"/></linearGradient></defs>
    <ellipse cx="110" cy="146" rx="78" ry="8" fill="var(--surface-3)"/>
    <circle cx="44" cy="40" r="6" fill="var(--green-dim)"/><circle cx="186" cy="30" r="9" fill="var(--gold-dim)"/><circle cx="196" cy="98" r="4" fill="var(--green-dim)"/>
    ${kind === 'loan' ? `
    <rect x="62" y="22" width="70" height="120" rx="14" fill="var(--surface)" stroke="var(--border-2)" stroke-width="2"/>
    <rect x="70" y="36" width="54" height="34" rx="8" fill="var(--green-dim)"/>
    <path d="M80 58l8-8 7 6 12-12" fill="none" stroke="var(--green)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>
    <rect x="70" y="78" width="40" height="6" rx="3" fill="var(--surface-3)"/><rect x="70" y="90" width="28" height="6" rx="3" fill="var(--surface-3)"/>
    <rect x="70" y="112" width="54" height="16" rx="8" fill="url(#ea1)"/>
    <rect x="112" y="70" width="70" height="50" rx="10" fill="url(#ea1)"/><rect x="112" y="80" width="70" height="10" fill="rgba(0,0,0,.12)"/>
    <circle cx="166" cy="104" r="6" fill="#fff" opacity=".9"/>
    <circle cx="150" cy="56" r="14" fill="url(#ea2)"/><text x="150" y="61" text-anchor="middle" font-size="14" font-weight="900" fill="#fff" font-family="Manrope, sans-serif">F</text>
    <circle cx="176" cy="48" r="10" fill="url(#ea2)" opacity=".85"/>` : kind === 'bell' ? `
    <path d="M110 28c-22 0-36 16-36 38v22l-10 16h92l-10-16V66c0-22-14-38-36-38z" fill="var(--surface)" stroke="var(--border-2)" stroke-width="2" stroke-linejoin="round"/>
    <path d="M98 112a12 12 0 0024 0" fill="none" stroke="var(--border-2)" stroke-width="2"/>
    <rect x="90" y="60" width="40" height="7" rx="3.5" fill="var(--green-dim)"/><rect x="96" y="74" width="28" height="7" rx="3.5" fill="var(--surface-3)"/>
    <circle cx="146" cy="40" r="16" fill="url(#ea1)"/><path d="M139 40l5 5 9-10" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>` : kind === 'search' ? `
    <circle cx="100" cy="74" r="38" fill="var(--surface)" stroke="var(--border-2)" stroke-width="2"/>
    <circle cx="100" cy="74" r="26" fill="var(--green-dim)"/>
    <path d="M128 102l26 26" stroke="url(#ea1)" stroke-width="12" stroke-linecap="round"/>
    <rect x="86" y="68" width="28" height="6" rx="3" fill="var(--surface)"/><rect x="86" y="80" width="18" height="6" rx="3" fill="var(--surface)"/>` : kind === 'error' ? `
    <rect x="56" y="30" width="108" height="96" rx="20" fill="var(--surface)" stroke="var(--border-2)" stroke-width="2"/>
    <path d="M80 70a42 42 0 0160 0M90 82a26 26 0 0140 0" fill="none" stroke="var(--surface-3)" stroke-width="7" stroke-linecap="round"/>
    <circle cx="110" cy="96" r="6" fill="var(--surface-3)"/>
    <circle cx="160" cy="40" r="16" fill="url(#ea2)"/><path d="M160 32v10M160 47v1" stroke="#fff" stroke-width="3.5" stroke-linecap="round"/>` : kind === 'inbox' ? `
    <path d="M52 84l20-46h76l20 46v34a10 10 0 01-10 10H62a10 10 0 01-10-10z" fill="var(--surface)" stroke="var(--border-2)" stroke-width="2" stroke-linejoin="round"/>
    <path d="M52 84h36l6 12h32l6-12h36" fill="none" stroke="var(--border-2)" stroke-width="2" stroke-linejoin="round"/>
    <rect x="84" y="50" width="52" height="7" rx="3.5" fill="var(--green-dim)"/><rect x="92" y="64" width="36" height="7" rx="3.5" fill="var(--surface-3)"/>
    <circle cx="162" cy="40" r="16" fill="url(#ea1)"/><path d="M155 40l5 5 9-10" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>` : `
    <rect x="50" y="34" width="120" height="84" rx="18" fill="var(--surface)" stroke="var(--border-2)" stroke-width="2"/>
    <path d="M78 118l-10 18 26-18" fill="var(--surface)" stroke="var(--border-2)" stroke-width="2" stroke-linejoin="round"/>
    <rect x="68" y="56" width="70" height="8" rx="4" fill="var(--green-dim)"/><rect x="68" y="72" width="84" height="8" rx="4" fill="var(--surface-3)"/><rect x="68" y="88" width="52" height="8" rx="4" fill="var(--surface-3)"/>
    <circle cx="168" cy="40" r="16" fill="url(#ea1)"/><path d="M161 40l5 5 9-10" fill="none" stroke="#fff" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>`}
  </svg>`;
}

/* Paramètres (adresse, Wave) préchargés en arrière-plan : les écrans de détail s'ouvrent sans attendre */
const warmSettings = () => { if (!_settings) getSettings().catch(() => {}); };
async function renderClientDashboard() {
  const paint = painter();
  warmSettings();
  const reqs = await listWithCache('client-list', sb.from('requests').select(LIST_COLS).eq('client_id', currentUser.id).order('created_at', { ascending: false }).limit(200));
  if (!paint()) return;
  const active = reqs.filter((r) => ['paid', 'repayment_requested'].includes(r.status)).sort((a, b) => (daysLeft(a) ?? 999) - (daysLeft(b) ?? 999));
  const inProgress = reqs.find((r) => ['pending', 'guarantee_received'].includes(r.status));
  const done = reqs.filter((r) => r.status === 'done');
  const first = (currentUser.full_name || 'client').split(' ')[0];
  const hour = new Date().getHours();
  const hello = hour >= 18 || hour < 4 ? 'Bonsoir' : 'Bonjour';
  let main;
  if (active.length) {
    const fresh = active.filter((r) => r.payment_proof_path && !r.proof_viewed_at && r.status === 'paid');
    main = `${fresh.map((r) => proofCardHtml(r, 'hero')).join('')}
      <section class="dash-section"><div class="section-title">Mon prêt en cours</div>${active.map(countdownCard).join('')}</section>
      ${active.filter((r) => r.payment_proof_path && !fresh.includes(r)).map((r) => proofCardHtml(r)).join('')}`;
  } else if (inProgress) {
    const r = inProgress, step = !r.guarantee_declared_at ? ['Terminez votre demande', 'Indiquez votre numéro Wave pour recevoir l\'argent.', 'Continuer']
      : r.status === 'pending' ? ['Envoyez votre garantie', 'Adresse et numéro du destinataire à copier pour Yango.', 'Voir l\'adresse']
      : ['Garantie reçue', 'Nous préparons votre virement Wave. Vous serez notifié.', 'Suivre'];
    main = `<section class="dash-section"><div class="section-title">Ma demande en cours</div>
      <a class="hero-loan pending" href="#/client/requests/${esc(r.id)}">
        <div class="hl-top"><span class="hl-amount">${fcfa(r.montant)}</span>${statusBadge(r.status)}</div>
        ${steps(r.status)}
        <div class="hl-next"><span class="hl-ic">${ic(r.status === 'guarantee_received' ? 'hourglass' : 'box')}</span><div><strong>${step[0]}</strong><span>${step[1]}</span></div></div>
        <span class="btn btn-primary btn-block">${step[2]} ${ic('arrow')}</span>
      </a></section>`;
  } else {
    main = `<section class="empty-hero">
      ${emptyArt('loan')}
      <h2>${done.length ? 'Besoin d\'un nouveau coup de pouce ?' : 'Votre premier prêt en quelques minutes'}</h2>
      <p>${done.length ? `Vous avez déjà remboursé ${done.length} prêt${done.length > 1 ? 's' : ''} avec nous. Merci pour votre confiance !` : 'Choisissez un montant, signez le contrat sur votre téléphone, et recevez l\'argent sur votre Wave.'}</p>
      ${newRequestBtn('btn-xl btn-block').replace('➕ Nouvelle demande', `${ic('plus')}${done.length ? 'Faire une nouvelle demande' : 'Faire ma première demande'}`)}
      <div class="trust-row"><span>${ic('shield', 'ic-sm')}Contrat clair</span><span>${ic('wallet', 'ic-sm')}Argent sur Wave</span><span>${ic('clock', 'ic-sm')}Réponse rapide</span></div>
    </section>`;
  }
  $('content').innerHTML = `${offlineNote()}
    <header class="dash-hello"><div><span class="muted">${hello},</span><h1 class="page-title">${esc(first)}</h1></div>
      ${active.length || inProgress ? '' : ''}</header>
    <div class="note" id="blockNote" hidden>${ic('lock', 'ic-sm')} ${esc(BLOCK_MSG)}</div>
    ${(() => { const urgent = active.filter((r) => r.status === 'paid' && (daysLeft(r) ?? 99) <= 2); const late = urgent.filter((r) => daysLeft(r) < 0);
      return urgent.length ? `<div class="alert-due ${late.length ? 'late' : 'soon'}">${ic('alert', 'ic-sm')} ${late.length
        ? `<span><strong>${late.length > 1 ? late.length + ' prêts en retard.' : 'Prêt en retard.'}</strong> Remboursez dès que possible pour récupérer votre garantie.</span>`
        : `<span><strong>Échéance proche :</strong> pensez à rembourser avant la date limite.</span>`}</div>` : ''; })()}
    ${main}
    <nav class="tiles" aria-label="Raccourcis">
      <button type="button" class="tile" data-new-request onclick="goNewRequest()"><span class="tile-ic t-green">${ic('plus')}</span>Demander</button>
      <a class="tile" href="#/client/requests"><span class="tile-ic t-blue">${ic('wallet')}</span>Mes prêts</a>
      <a class="tile" href="#/client/messages/chat"><span class="tile-ic t-violet">${ic('chat')}<span class="nav-badge" data-msg-badge hidden></span></span>Messages</a>
    </nav>
    <div data-install-slot="compact"></div>`;
  setActiveLoan(reqs);
  bindProofs(active, { ack: true });
}

const clientRow = (r) => `
  <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 0;border-bottom:1px solid var(--border-2);gap:12px;flex-wrap:wrap;">
    <div><div style="font-weight:800">${fcfa(r.montant)} · ${esc(r.duree)} j ${dueChip(r)}</div><div class="muted">${fmtDate(r.created_at)} · ${nextStepHint(r)}</div></div>
    <div class="row-actions" style="align-items:center;">${statusBadge(r.status)} ${docButtons(r, true)}<a class="btn btn-ghost btn-sm" href="#/client/requests/${esc(r.id)}">Ouvrir →</a></div>
  </div>`;

async function renderClientRequests() {
  warmSettings();
  const paint = painter();
  const reqs = await listWithCache('client-list', sb.from('requests').select(LIST_COLS).eq('client_id', currentUser.id).order('created_at', { ascending: false }).limit(200));
  if (!paint()) return;
  $('content').innerHTML = `${offlineNote()}
    <div class="page-head"><div><h1 class="page-title">Mes prêts</h1><p class="page-subtitle">Historique complet de vos demandes.</p></div>${reqs.length ? newRequestBtn() : ''}</div>
    ${reqs.length ? historySummary(reqs) + `<div class="loan-list">${reqs.map(loanItem).join('')}</div>`
      : `<section class="empty-hero">${emptyArt('loan')}<h2>Aucun prêt pour le moment</h2><p>Votre historique apparaîtra ici dès votre première demande.</p>
         ${newRequestBtn('btn-xl btn-block').replace('➕ Nouvelle demande', `${ic('plus')}Faire ma première demande`)}</section>`}`;
  setActiveLoan(reqs);
}
const STATUS_IC = { pending: 'box', guarantee_received: 'hourglass', paid: 'wallet', repayment_requested: 'clock', done: 'check', rejected: 'x' };
const loanItem = (r) => `<a class="loan-item s-${esc(r.status)}" href="#/client/requests/${esc(r.id)}">
    <span class="li-ic">${ic(STATUS_IC[r.status] || 'doc')}</span>
    <span class="li-main"><span class="li-top"><strong>${fcfa(r.montant)}</strong><span class="li-days">${esc(r.duree)} jours</span>${dueChip(r)}</span>
      <span class="li-sub">${fmtDate(r.created_at)} · ${nextStepHint(r)}</span></span>
    <span class="li-end">${statusBadge(r.status)}${ic('chevron')}</span>
  </a>`;

/* ---------- Détail d'une demande (client) ---------- */
const memoRow = (k, id) => (_memo.get(k)?.data || []).find((x) => x.id === id) || null;
async function renderClientRequest(id) {
  const paint = painter();
  const freshP = Promise.all([
    q(sb.from('requests').select(LIST_COLS).eq('id', id).eq('client_id', currentUser.id).maybeSingle()),
    getSettings().catch(() => null),
  ]);
  const cached = _settings && memoRow('client-list', id);
  let r, settings;
  if (cached) {
    // Affichage immédiat avec les données déjà chargées ; mise à jour seulement si elles ont changé.
    r = cached; settings = _settings;
    freshP.then(([{ data }]) => {
      if (!data || JSON.stringify(data) === JSON.stringify(cached)) return;
      const m = _memo.get('client-list'); if (m) m.data = m.data.map((x) => (x.id === data.id ? data : x));
      if (paint() && !isEditing()) route();
    }).catch(() => {});
  } else {
    [{ data: r }, settings] = await freshP;
  }
  if (!paint()) return;
  if (!r) { toast('Demande introuvable.', 'error'); return navigate('/client/requests'); }

  $('content').innerHTML = `
    <a class="btn btn-ghost btn-sm" href="#/client/requests">← Mes prêts</a>
    <div class="page-head" style="margin-top:16px;">
      <div><h1 class="page-title">Prêt de ${fcfa(r.montant)}</h1><p class="page-subtitle">Demande du ${fmtDate(r.created_at)}</p></div>
      ${statusBadge(r.status)}
    </div>
    ${steps(r.status)}
    ${countdownCard(r)}
    ${proofCardHtml(r)}
    <div class="card next-card" style="margin-bottom:20px;" id="nextStep">${clientNextStep(r, settings)}</div>
    <div class="card help-card" style="margin-bottom:20px;">
      <div><strong>Une question sur ce prêt ?</strong><span class="muted">Écrivez-nous ou envoyez un message vocal : nous répondons dans l'appli.</span></div>
      <div class="contact-actions">
        ${r.status === 'paid' ? `<button class="btn btn-secondary btn-sm" onclick="contactAbout(${jsArg(r.id)}, 'remboursement_anticipe')">${ic('wallet')}Rembourser plus tôt</button>` : ''}
        <button class="btn btn-primary btn-sm" onclick="contactAbout(${jsArg(r.id)}, 'question')">${ic('chat')}Nous écrire</button>
      </div>
    </div>
    ${await ratingCardHtml(r)}
    <div class="card" style="margin-bottom:20px;">
      <div class="card-title">Mes documents</div>
      <div class="row-actions">${docButtons(r)}</div>
      ${r.receipt_number ? '' : '<p class="muted" style="margin-top:8px;">Votre reçu de prêt sera disponible dès que l\'argent aura été envoyé.</p>'}
    </div>
    <div class="card" style="margin-bottom:20px;">
      <div class="card-title">Historique</div>
      ${timelineHtml(r)}
    </div>
    <div class="card" style="margin-bottom:20px;">
      <div class="card-title">Détails</div>
      <div class="detail-row"><div class="detail-key">Montant</div><div class="detail-val">${fcfa(r.montant)}</div></div>
      <div class="detail-row"><div class="detail-key">Durée</div><div class="detail-val">${esc(r.duree)} jours</div></div>
      <div class="detail-row"><div class="detail-key">Total à rembourser</div><div class="detail-val" style="color:var(--green)">${fcfa(r.total)}</div></div>
      <div class="detail-row"><div class="detail-key">Échéance</div><div class="detail-val" style="color:var(--gold)">${notPaidYet(r) ? `${r.duree} jours après réception de la preuve de versement` : fmtDue(r.date_remboursement)} ${dueChip(r)}</div></div>
      <div class="detail-row"><div class="detail-key">Garantie</div><div class="detail-val">${esc(garantieText(r))}</div></div>
      ${r.receipt_number ? `<div class="detail-row"><div class="detail-key">N° de reçu</div><div class="detail-val">${esc(r.receipt_number)}</div></div>` : ''}
      ${r.wave_number ? `<div class="detail-row"><div class="detail-key">Votre numéro Wave</div><div class="detail-val">${waveCell(r.wave_number)}</div></div>` : ''}
      ${r.contact1_phone ? `<div class="detail-row"><div class="detail-key">Contacts d'urgence</div><div class="detail-val">${esc(contactText(r.contact1_name, r.contact1_phone))}<br>${esc(contactText(r.contact2_name, r.contact2_phone))}</div></div>` : ''}
    </div>`;
  bindNextStep(r);
  bindProofs([r], { ack: true });
  bindRating(r);
}

function clientNextStep(r, s) {
  if (r.status === 'pending' && !r.guarantee_declared_at) return guaranteeForm(r);
  if (r.status === 'pending') {
    if (!s) return '<div class="note err">Adresse de livraison indisponible pour le moment. Réessayez plus tard.</div>';
    return `<div class="card-title">Envoyez votre garantie par Yango</div>
      <p class="muted" style="margin-bottom:14px;">Commandez vous-même une <strong>livraison Yango</strong> dans votre appli, avec l'adresse et le numéro ci-dessous comme <strong>destination</strong>. Vous payez la course dans Yango.</p>
      <div class="copy-row"><div><div class="k">Destinataire</div><div class="v">${esc(s.receiver_name)}</div></div>${copyBtn(s.receiver_name)}</div>
      <div class="copy-row"><div><div class="k">Adresse de livraison</div><div class="v">${esc(s.receiver_address)}</div></div>${copyBtn(s.receiver_address)}</div>
      <div class="copy-row"><div><div class="k">Téléphone du destinataire</div><div class="v mono">${esc(fmtPhone(s.receiver_phone))}</div></div>${copyBtn(digits(s.receiver_phone))}</div>
      ${s.receiver_note ? `<div class="note">📝 Note pour le coursier : ${esc(s.receiver_note)} ${copyBtn(s.receiver_note, '📋')}</div>` : ''}
      <ol class="howto">
        <li>Ouvrez l'appli <strong>Yango</strong> et choisissez <strong>Livraison</strong>.</li>
        <li>Départ : votre adresse. Destination : collez l'adresse et le numéro ci-dessus.</li>
        <li>Payez la course dans Yango et remettez votre garantie au coursier.</li>
        <li>Dès réception, nous vous envoyons <strong>${fcfa(r.montant)}</strong> sur votre Wave <span class="wave">${esc(fmtPhone(r.wave_number))}</span>. Vous êtes notifié à chaque étape.</li>
      </ol>
      <div style="margin-top:14px;"><button class="btn btn-ghost btn-sm" id="editGuarantee">✏️ Modifier mes informations</button></div>
      <div id="guaranteeEdit" hidden style="margin-top:14px;">${guaranteeForm(r, true)}</div>`;
  }
  if (r.status === 'guarantee_received') {
    return `<div class="card-title">Garantie reçue</div>
      <p>Nous avons bien reçu votre garantie. <strong>${fcfa(r.montant)}</strong> vont être envoyés sur votre Wave <span class="wave">${esc(fmtPhone(r.wave_number))}</span>.</p>
      <div style="margin-top:12px;"><button class="btn btn-ghost btn-sm" id="editGuarantee">✏️ Corriger mon numéro Wave</button></div>
      <div id="guaranteeEdit" hidden style="margin-top:14px;">${guaranteeForm(r, true)}</div>`;
  }
  if (r.status === 'paid') {
    const nexusWave = s ? s.wave_number : '';
    return `<div class="card-title">Argent envoyé</div>
      <p><strong>${fcfa(r.paid_amount || r.montant)}</strong> envoyés sur votre Wave <span class="wave">${esc(fmtPhone(r.wave_number))}</span> le ${fmtDate(r.paid_at)}.</p>
      ${r.admin_note ? `<div class="note err">${esc(r.admin_note)}</div>` : ''}
      <div class="card-title" style="font-size:1rem;margin-top:20px;">Rembourser mon prêt</div>
      <div class="copy-row"><div><div class="k">Montant à rembourser${penaltyOf(r) ? " aujourd'hui" : ''}</div><div class="v">${fcfa(amountDue(r))}</div>${penaltyOf(r) ? `<div class="muted">${fcfa(r.total)} + ${lateDays(r)} j × ${fcfa(PENALTY_PER_DAY)} de majoration</div>` : ''}</div><div class="muted">échéance ${fmtDue(r.date_remboursement)} ${dueChip(r)}</div></div>
      ${nexusWave ? `<div class="copy-row"><div><div class="k">Numéro Wave de Nexus Crédit</div><div class="v mono">${esc(fmtPhone(nexusWave))}</div></div>${copyBtn(digits(nexusWave))}</div>` : ''}
      <p class="muted">Envoyez la somme depuis <strong>votre numéro Wave ${esc(fmtPhone(r.wave_number))}</strong>, puis indiquez la référence de la transaction (visible dans l'historique Wave).</p>
      <form id="repayForm" class="form-grid" style="margin-top:14px;" novalidate>
        <div class="field"><label for="rpAmount">Montant envoyé (FCFA) <span class="req">*</span></label><input id="rpAmount" type="number" inputmode="numeric" min="100" step="1" value="${esc(amountDue(r))}" required></div>
        <div class="field"><label for="rpRef">Référence de la transaction Wave <span class="req">*</span></label><input id="rpRef" placeholder="Ex : T_ABCD1234EFGH" maxlength="40" autocapitalize="characters" autocomplete="off" spellcheck="false" required></div>
        <div class="full"><button class="btn btn-primary" type="submit">✅ J'ai remboursé</button></div>
      </form>`;
  }
  if (r.status === 'repayment_requested') {
    return `<div class="card-title">Remboursement en vérification</div>
      <p>Vous avez déclaré <strong>${fcfa(r.repayment_amount)}</strong> (réf. ${esc(r.repayment_ref)}) le ${fmtDate(r.repayment_requested_at)}. Nous vérifions la réception sur notre Wave.</p>`;
  }
  if (r.status === 'done') return `<div class="card-title">Prêt remboursé</div><p>Merci ! Votre prêt a été entièrement remboursé le ${fmtDate(r.repaid_at)}. ${r.guarantee_returned_at ? '' : ' Nous vous contactons pour la restitution de votre garantie.'}</p>
    ${r.guarantee_returned_at ? `<div class="note ok">${ic('shield', 'ic-inline')} <strong>Garantie restituée</strong> le ${fmtDate(r.guarantee_returned_at)}${r.guarantee_return_note ? ' · ' + esc(r.guarantee_return_note) : ''}</div>` : ''}`;
  if (r.status === 'rejected') return `<div class="card-title">Demande refusée</div><p>${esc(r.rejection_reason || 'Motif non précisé.')}</p>`;
  return '';
}

function guaranteeForm(r, editing = false) {
  const name = r.guarantee_name || r.nom || currentUser.full_name || '';
  const phone = r.guarantee_phone || r.telephone || currentUser.phone || '';
  const wave = r.wave_number || r.telephone || currentUser.phone || '';
  const known = name && PHONE_OK(phone);
  return `${editing ? '' : `<div class="card-title">Étape suivante : votre numéro Wave</div>
      <p class="muted" style="margin-bottom:14px;">Sur quel numéro Wave voulez-vous recevoir l'argent ? Ensuite, nous vous affichons l'adresse où envoyer votre garantie par Yango.</p>`}
    <form class="guaranteeForm" novalidate>
      <label class="input-ic" aria-label="Numéro Wave">${ic('wallet')}<input name="wave" type="tel" inputmode="tel" value="${esc(fmtPhone(wave))}" placeholder="Numéro Wave (77 123 45 67)" maxlength="20" required aria-label="Numéro Wave pour recevoir l'argent"></label>
      <p class="hint">${ic('refresh', 'ic-sm')} Vous rembourserez aussi depuis ce numéro.</p>
      <div class="id-row" ${known ? '' : 'hidden'}>${ic('user', 'ic-sm')}<span>${esc(name)} · ${esc(fmtPhone(phone))}</span><button type="button" class="link-btn" data-gedit>Modifier</button></div>
      <div class="field-pair g-id" ${known ? 'hidden' : ''}>
        <label class="input-ic">${ic('user')}<input name="name" value="${esc(name)}" autocomplete="name" maxlength="80" required placeholder="Nom complet" aria-label="Nom complet"></label>
        <label class="input-ic">${ic('phone')}<input name="phone" type="tel" inputmode="tel" value="${esc(fmtPhone(phone))}" autocomplete="tel" maxlength="20" required placeholder="Téléphone" aria-label="Téléphone"></label>
      </div>
      <button class="btn btn-primary btn-xl btn-block" type="submit">${editing ? `${ic('check')}Enregistrer` : `Continuer ${ic('arrow')}`}</button>
    </form>`;
}

function bindNextStep(r) {
  const edit = $('editGuarantee');
  if (edit) edit.onclick = () => { $('guaranteeEdit').hidden = !$('guaranteeEdit').hidden; };
  document.querySelectorAll('[data-gedit]').forEach((b) => { b.onclick = () => { const f = b.closest('form'); f.querySelector('.g-id').hidden = false; b.closest('.id-row').hidden = true; f.elements.name.focus(); }; });
  document.querySelectorAll('.guaranteeForm').forEach((f) => f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = f.querySelector('button[type=submit]');
    const el = f.elements, name = el.name.value.trim().replace(/\s+/g, ' '), phone = el.phone.value.trim(), wave = el.wave.value.trim();
    const showId = () => { f.querySelector('.g-id').hidden = false; const row = f.querySelector('.id-row'); if (row) row.hidden = true; };
    if (name.length < 2) { showId(); return invalid(el.name, 'Indiquez votre nom complet.'); }
    if (!PHONE_OK(phone)) { showId(); return invalid(el.phone, 'Téléphone invalide (9 chiffres, ex : 77 123 45 67).'); }
    if (!PHONE_OK(wave)) return invalid(el.wave, 'Numéro Wave invalide (9 chiffres, ex : 77 123 45 67).');
    await once('guarantee-' + r.id, async () => {
      busy(btn, true);
      try {
        await rpc('guarantee_declare', { p_request: r.id, p_name: name, p_phone: phone, p_wave: wave });
        toast('Informations enregistrées.'); $('content').dataset.dirty = ''; route();
      } catch (err) { toast(err.message, 'error'); busy(btn, false); }
    });
  }));
  const rf = $('repayForm');
  if (rf) rf.addEventListener('submit', async (e) => {
    e.preventDefault();
    const amountRaw = $('rpAmount').value.trim(), amount = Number(amountRaw), ref = $('rpRef').value.trim().replace(/\s+/g, '');
    if (!Number.isInteger(amount) || amount < 100) return invalid($('rpAmount'), 'Indiquez le montant envoyé (nombre entier, 100 FCFA minimum).');
    if (amount < amountDue(r) && !(await askDialog({ title: 'Montant inférieur au montant dû', message: `Vous déclarez ${fcfa(amount)}, alors que le montant dû est ${fcfa(amountDue(r))}. Continuer quand même ?`, confirmText: 'Continuer', danger: true }))) return;
    if (!/^[A-Za-z0-9_.-]{4,40}$/.test(ref)) return invalid($('rpRef'), 'Référence Wave invalide : recopiez-la depuis votre historique Wave (4 à 40 caractères, sans espace).');
    const btn = rf.querySelector('button[type=submit]');
    await once('repay-' + r.id, async () => {
      busy(btn, true);
      try {
        await rpc('repayment_request', { p_request: r.id, p_amount: amount, p_ref: ref });
        toast('Merci ! Nous vérifions votre remboursement.'); $('content').dataset.dirty = ''; route();
      } catch (err) { toast(err.message, 'error'); busy(btn, false); }
    });
  });
}

/* ---------- Nouvelle demande ---------- */
const BLOCK_MSG = 'Vous avez déjà un prêt en cours. Vous pourrez faire une nouvelle demande une fois celui-ci remboursé.';
const ACTIVE_STATUSES = ['pending', 'guarantee_received', 'paid', 'repayment_requested'];
let _activeLoan = null; // demande en cours du client (null si aucune)
function setActiveLoan(reqs) {
  _activeLoan = (reqs || []).find((r) => ACTIVE_STATUSES.includes(r.status)) || null;
  applyBlockState();
  return _activeLoan;
}
function applyBlockState() {
  document.querySelectorAll('[data-new-request]').forEach((el) => {
    el.classList.toggle('is-disabled', !!_activeLoan);
    el.setAttribute('aria-disabled', _activeLoan ? 'true' : 'false');
    if (el.tagName === 'BUTTON' && !el.matches('.sb-cta, .tile')) el.disabled = !!_activeLoan;
    el.title = _activeLoan ? BLOCK_MSG : '';
  });
  const note = $('blockNote'); if (note) note.hidden = !_activeLoan;
}
const newRequestBtn = (extra = '') => `<button type="button" class="btn btn-primary ${extra}" data-new-request onclick="goNewRequest()">➕ Nouvelle demande</button>`;
function goNewRequest() { if (_activeLoan) return toast(BLOCK_MSG, 'error'); navigate('/client/new'); }

async function renderNewRequest() {
  const u = currentUser;
  const formId = newUuid();
  const paint = painter();
  const [{ data: open }, prevContacts] = await Promise.all([
    q(sb.from('requests').select('id,status,montant').eq('client_id', u.id).in('status', ACTIVE_STATUSES).limit(1)),
    // Contacts d'urgence de la dernière demande : proposés d'office (le client peut les changer)
    q(sb.from('requests').select('contact1_name,contact1_phone,contact2_name,contact2_phone,created_at').eq('client_id', u.id).order('created_at', { ascending: false }).limit(5))
      .then((x) => (x.data || []).find((r) => r.contact1_phone && r.contact2_phone) || {}).catch(() => ({})),
  ]);
  if (!paint()) return;
  if (setActiveLoan(open)) {
    const a = _activeLoan;
    $('content').innerHTML = `<div class="page-head"><div><h1 class="page-title">Nouvelle demande</h1></div></div>
      <div class="card blocked-card"><span class="state-ic">${ic('lock')}</span>
        <h3>Nouvelle demande impossible pour le moment</h3>
        <p>${esc(BLOCK_MSG)}</p>
        <a class="btn btn-primary btn-block-m" href="#/client/requests/${esc(a.id)}">Voir mon prêt en cours (${fcfa(a.montant)}) →</a></div>`;
    return;
  }
  document.body.classList.add('focus-flow');
  const needId = !(u.full_name && PHONE_OK(u.phone || ''));
  $('content').innerHTML = `
    <form id="newReqForm" class="flow" novalidate>
      <div class="flow-step active" data-step="1">
        <header class="flow-head">
          <a class="icon-btn" href="#/client/dashboard" aria-label="Annuler">${ic('x')}</a>
          <div class="flow-title"><strong>Nouvelle demande</strong><span>Étape 1 sur 3 · votre prêt</span></div>
          <div class="flow-progress"><i style="width:33.3%"></i></div>
        </header>
        <div class="flow-body">
          <div class="amount-card">
            <label for="r-montant">Montant souhaité</label>
            <div class="amount-input"><input type="text" inputmode="numeric" id="r-montant" value="50000" maxlength="7" autocomplete="off"><span>FCFA</span></div>
            <input type="range" id="r-range" min="5000" max="500000" step="5000" value="50000" aria-label="Montant">
            <div class="range-legend"><span>5 000</span><span>500 000</span></div>
          </div>
          <div class="seg seg-lg" role="group" aria-label="Durée du prêt">
            <button type="button" class="active" data-duree="7">7 jours<small>+25 %</small></button>
            <button type="button" data-duree="14">14 jours<small>+35 %</small></button>
          </div>
          <select id="r-duree" class="sr-select" aria-label="Durée" tabindex="-1"><option value="">-- Choisir --</option><option value="7" selected>7 jours (+25%)</option><option value="14">14 jours (+35%)</option></select>
          <div class="sum-card">
            <div><span>À rembourser</span><strong id="sim-t">—</strong></div>
            <div class="sum-meta"><span>Frais <b id="sim-i">—</b></span><span>Délai <b id="sim-d">—</b></span><span class="sr-only" id="sim-m"></span></div>
          </div>
          <div class="field-pair">
            <label class="input-ic" for="r-guar">${ic('box')}<input type="text" id="r-guar" maxlength="120" placeholder="Bien en garantie" aria-label="Bien mis en garantie"></label>
            <label class="input-ic" for="r-pass">${ic('doc')}<input type="text" id="r-pass" maxlength="30" placeholder="N° de passeport" autocapitalize="characters" autocomplete="off" spellcheck="false" aria-label="Numéro de passeport"></label>
          </div>
          <p class="hint">${ic('alert', 'ic-sm')} Retard : +${fcfa(PENALTY_PER_DAY)} par jour ; totalité exigible à partir du 4e jour de retard.</p>
          <p class="hint" id="r-guar-preview" hidden></p>
          <div class="id-row" ${needId ? 'hidden' : ''}>${ic('user', 'ic-sm')}<span>${esc(u.full_name || '')} · ${esc(fmtPhone(u.phone || ''))}</span><button type="button" class="link-btn" id="idEdit">Modifier</button></div>
          <div class="field-pair" id="idFields" ${needId ? '' : 'hidden'}>
            <label class="input-ic" for="r-nom">${ic('user')}<input type="text" id="r-nom" value="${esc(u.full_name || '')}" autocomplete="name" maxlength="80" placeholder="Nom complet" aria-label="Nom complet"></label>
            <label class="input-ic" for="r-tel">${ic('phone')}<input type="tel" inputmode="tel" id="r-tel" value="${esc(u.phone || '')}" autocomplete="tel" maxlength="20" placeholder="Téléphone" aria-label="Téléphone"></label>
          </div>
          <textarea id="r-msg" hidden></textarea>
        </div>
        <footer class="flow-foot"><button type="button" class="btn btn-primary btn-xl btn-block" id="reqNext">Continuer ${ic('arrow')}</button></footer>
      </div>
      <div class="flow-step" data-step="2" hidden>
        <header class="flow-head">
          <button type="button" class="icon-btn" id="reqBack2" aria-label="Retour">${ic('back')}</button>
          <div class="flow-title"><strong>Contacts d'urgence</strong><span>Étape 2 sur 3 · deux proches</span></div>
          <div class="flow-progress"><i style="width:66.6%"></i></div>
        </header>
        <div class="flow-body">
          <div class="ec-intro">${ic('shield')}<p>Indiquez <strong>deux proches</strong> joignables sur WhatsApp. Nous les contacterons <strong>uniquement en cas de retard de remboursement</strong>. Prévenez-les avant d'envoyer votre demande.</p></div>
          ${[1, 2].map((n) => `<fieldset class="ec-card" id="ec${n}">
            <legend><span class="ec-num">${n}</span>Contact d'urgence ${n} <span class="req" aria-hidden="true">*</span></legend>
            <label class="input-ic">${ic('user')}<input type="text" id="r-c${n}-name" maxlength="80" autocomplete="off" placeholder="Nom de la personne" aria-label="Contact d'urgence ${n} : nom" value="${esc(prevContacts[`contact${n}_name`] || '')}" required></label>
            <label class="input-ic">${ic('phone')}<input type="tel" inputmode="tel" id="r-c${n}-tel" maxlength="20" autocomplete="off" placeholder="Numéro WhatsApp" aria-label="Contact d'urgence ${n} : numéro WhatsApp" value="${esc(fmtPhone(prevContacts[`contact${n}_phone`] || ''))}" required></label>
            ${'contacts' in navigator && navigator.contacts && 'select' in navigator.contacts ? `<button type="button" class="link-btn ec-pick" data-pick="${n}">${ic('user', 'ic-sm')}Choisir dans mes contacts</button>` : ''}
          </fieldset>`).join('')}
          ${prevContacts.contact1_phone ? `<p class="hint">${ic('refresh', 'ic-sm')} Repris de votre dernière demande : vérifiez qu'ils sont toujours joignables.</p>` : ''}
        </div>
        <footer class="flow-foot"><button type="button" class="btn btn-primary btn-xl btn-block" id="reqNext2">Continuer ${ic('arrow')}</button></footer>
      </div>
      <div class="flow-step" data-step="3" hidden>
        <header class="flow-head">
          <button type="button" class="icon-btn" id="reqBack" aria-label="Retour">${ic('back')}</button>
          <div class="flow-title"><strong>Contrat et signature</strong><span>Étape 3 sur 3 · <b id="recap2"></b></span></div>
          <div class="flow-progress"><i style="width:100%"></i></div>
        </header>
        <div class="flow-body">
          <div class="contract-box">
            <div class="contract-mini" id="contractMini" tabindex="0" aria-label="Contrat de prêt"></div>
            <button type="button" class="btn btn-ghost btn-sm" id="viewContractBtn">${ic('doc')}Lire en plein écran</button>
          </div>
          <label class="check-row" id="contractAcceptLabel">
            <input type="checkbox" id="contractCheck" disabled>
            <span><strong>J'ai lu et j'accepte les conditions du contrat</strong><span class="muted" id="contractHint">Faites défiler le contrat jusqu'en bas ou ouvrez-le en plein écran.</span></span>
          </label>
          <div class="sig-block">
            <div class="sig-head"><span>Votre signature</span><button type="button" class="link-btn" id="clearSig">${ic('trash', 'ic-sm')}Effacer</button></div>
            <div class="canvas-wrap"><canvas id="sigCanvas" height="160" aria-label="Zone de signature"></canvas><div class="sig-guide" aria-hidden="true"><span>✗</span>Signez ici avec le doigt</div></div>
          </div>
          <label class="check-row">
            <input type="checkbox" id="sigCheck">
            <span>Je certifie que cette signature est la mienne.</span>
          </label>
          <p class="hint">${ic('shield', 'ic-sm')} Date, heure et empreinte numérique de votre signature sont enregistrées.</p>
        </div>
        <footer class="flow-foot"><button type="submit" class="btn btn-primary btn-xl btn-block" id="newReqBtn">Envoyer ma demande ${ic('send')}</button></footer>
      </div>
    </form>`;

  const sig = setupSignature($('sigCanvas'));
  // Le contrat doit être lu (défilé jusqu'en bas ou ouvert en plein écran) avant de pouvoir être accepté.
  let contractOpened = false;
  const formData = () => ({ nom: $('r-nom').value.trim(), telephone: $('r-tel').value.trim(), passeport: $('r-pass').value.toUpperCase().replace(/[^A-Z0-9]/g, ''),
    garantie: $('r-guar').value.trim(), montant: numVal($('r-montant')) || null, duree: parseInt($('r-duree').value, 10) || null,
    contact1_name: cName(1), contact1_phone: digits($('r-c1-tel').value), contact2_name: cName(2), contact2_phone: digits($('r-c2-tel').value) });
  const cName = (n) => $(`r-c${n}-name`).value.trim().replace(/\s+/g, ' ');
  const contractRead = () => {
    if (contractOpened) return;
    contractOpened = true;
    $('contractCheck').disabled = false;
    $('contractHint').textContent = 'Contrat lu. Cochez la case pour l\'accepter.';
    $('contractAcceptLabel').classList.add('ready');
  };
  $('viewContractBtn').onclick = () => openContractViewer({ ...formData(), signature_preview: sig.problem() ? null : sig.toDataURL() }, contractRead);
  const mini = $('contractMini');
  mini.addEventListener('scroll', () => { if (mini.scrollTop + mini.clientHeight >= mini.scrollHeight - 24) contractRead(); }, { passive: true });
  const guarPreview = () => { const g = $('r-guar').value.trim(), pp = $('r-pass').value.trim(), el = $('r-guar-preview'); el.hidden = !g && !pp; el.textContent = 'Garantie : ' + garantieText({ garantie: g, passeport: pp }); };
  $('r-guar').oninput = guarPreview; $('r-pass').oninput = guarPreview; guarPreview();
  $('clearSig').onclick = () => sig.clear();
  $('idEdit').onclick = () => { $('idFields').hidden = false; document.querySelector('.id-row').hidden = true; $('r-nom').focus(); };

  const rangeM = $('r-range'), inputM = $('r-montant'), dureeEl = $('r-duree');
  const sim = () => {
    const m = numVal(inputM), d = parseInt(dureeEl.value, 10);
    document.querySelectorAll('[data-duree]').forEach((x) => x.classList.toggle('active', Number(x.dataset.duree) === d));
    if (m > 0 && d) {
      const ints = Math.round(m * (d === 7 ? 0.25 : 0.35));
      $('sim-m').textContent = fcfa(m); $('sim-i').textContent = fcfa(ints);
      $('sim-d').textContent = `${d} jours après réception`; $('sim-t').textContent = fcfa(m + ints);
    } else ['sim-m', 'sim-i', 'sim-d', 'sim-t'].forEach((x) => { $(x).textContent = '—'; });
  };
  rangeM.oninput = () => { inputM.value = rangeM.value; fmtAmountInput(inputM); paintRange(rangeM); sim(); };
  inputM.oninput = () => { const v = numVal(inputM); fmtAmountInput(inputM); if (v >= 5000 && v <= 500000) { rangeM.value = v; paintRange(rangeM); } sim(); };
  fmtAmountInput(inputM); paintRange(rangeM);
  dureeEl.onchange = sim;
  document.querySelectorAll('[data-duree]').forEach((x) => { x.onclick = () => { dureeEl.value = x.dataset.duree; sim(); }; });
  sim();

  // Étape 1 → 2 (vérifie d'abord le prêt et la garantie)
  const showStep = (n) => {
    document.querySelectorAll('.flow-step').forEach((st) => { const on = st.dataset.step === String(n); st.hidden = !on; st.classList.toggle('active', on); });
    window.scrollTo({ top: 0, behavior: 'instant' });
    if (n === 3) {
      const d = formData(); mini.dataset.ready = '';
      $('recap2').textContent = `${fcfa(d.montant)} sur ${d.duree} jours`;
      if (!mini.dataset.ready) { mini.innerHTML = contractHtmlView(d, new Date().toLocaleDateString('fr-FR')); mini.dataset.ready = '1'; }
      if (mini.scrollHeight <= mini.clientHeight + 24) contractRead();
    }
  };
  const step1Problem = () => {
    const nom = $('r-nom').value.trim(), tel = $('r-tel').value.trim(), pass = $('r-pass').value.toUpperCase().replace(/[^A-Z0-9]/g, ''), m = numVal(inputM);
    const idErr = (el, msg) => { $('idFields').hidden = false; document.querySelector('.id-row').hidden = true; return [el, msg]; };
    if (nom.length < 2) return idErr($('r-nom'), 'Indiquez votre nom complet.');
    if (!PHONE_OK(tel)) return idErr($('r-tel'), 'Téléphone invalide (9 chiffres, ex : 77 123 45 67).');
    if (!Number.isInteger(m) || m < 5000 || m > 500000) return [inputM, 'Montant entre 5 000 et 500 000 FCFA (nombre entier).'];
    if (![7, 14].includes(parseInt(dureeEl.value, 10))) return [dureeEl, 'Choisissez une durée de remboursement.'];
    if ($('r-guar').value.trim().length < 2) return [$('r-guar'), 'Indiquez le bien mis en garantie (ex : téléphone, ordinateur…).'];
    if (pass.length < 5 || pass.length > 20) return [$('r-pass'), 'Numéro de passeport invalide (5 à 20 lettres ou chiffres) : il est obligatoire en garantie.'];
    return null;
  };
  // Étape 2 : contacts d'urgence (obligatoires, deux personnes différentes, autres que le client)
  const last9 = (x) => digits(x).slice(-9);
  const step2Problem = () => {
    for (const n of [1, 2]) {
      if (cName(n).length < 2) return [$(`r-c${n}-name`), `Contact d'urgence ${n} : indiquez le nom de la personne.`];
      if (!PHONE_OK($(`r-c${n}-tel`).value) || digits($(`r-c${n}-tel`).value).length < 9) return [$(`r-c${n}-tel`), `Contact d'urgence ${n} : numéro WhatsApp invalide (9 chiffres, ex : 77 123 45 67).`];
    }
    if (last9($('r-c1-tel').value) === last9($('r-c2-tel').value)) return [$('r-c2-tel'), 'Les deux contacts d\'urgence doivent avoir des numéros différents.'];
    const me = last9($('r-tel').value);
    for (const n of [1, 2]) if (last9($(`r-c${n}-tel`).value) === me) return [$(`r-c${n}-tel`), 'Un contact d\'urgence doit être une autre personne que vous.'];
    return null;
  };
  ['r-c1-tel', 'r-c2-tel'].forEach((id) => $(id).addEventListener('blur', (e) => { if (digits(e.target.value).length >= 9) e.target.value = fmtPhone(e.target.value); }));
  document.querySelectorAll('[data-pick]').forEach((b) => { b.onclick = async () => {
    try {
      const [c] = await navigator.contacts.select(['name', 'tel'], { multiple: false });
      if (!c) return;
      const n = b.dataset.pick;
      if (c.name?.[0]) $(`r-c${n}-name`).value = c.name[0];
      if (c.tel?.[0]) $(`r-c${n}-tel`).value = fmtPhone(digits(c.tel[0]).replace(/^(00)?221(?=\d{9}$)/, ''));
    } catch (_) {}
  }; });
  $('reqNext').onclick = () => { const pb = step1Problem(); if (pb) return invalid(pb[0], pb[1]); haptic(); showStep(2); };
  $('reqNext2').onclick = () => { const pb = step2Problem(); if (pb) return invalid(pb[0], pb[1]); haptic(); showStep(3); };
  $('reqBack2').onclick = () => showStep(1);
  $('reqBack').onclick = () => showStep(2);

  $('newReqForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const montant = numVal(inputM);
    const row = {
      id: formId, // identifiant fixé à l'ouverture : un nouvel envoi après une coupure ne crée pas de doublon
      client_id: currentUser.id,
      nom: $('r-nom').value.trim().replace(/\s+/g, ' '), telephone: $('r-tel').value.trim(),
      passeport: $('r-pass').value.toUpperCase().replace(/[^A-Z0-9]/g, ''), garantie: $('r-guar').value.trim().replace(/\s+/g, ' '),
      montant, duree: parseInt(dureeEl.value, 10) || 0,
      message: $('r-msg').value.trim() || null,
    };
    const pb1 = step1Problem();
    if (pb1) { showStep(1); return invalid(pb1[0], pb1[1]); }
    const pb2 = step2Problem();
    if (pb2) { showStep(2); return invalid(pb2[0], pb2[1]); }
    Object.assign(row, { contact1_name: cName(1), contact1_phone: digits($('r-c1-tel').value), contact2_name: cName(2), contact2_phone: digits($('r-c2-tel').value) });
    if (row.nom.length < 2) return invalid($('r-nom'), 'Indiquez votre nom complet.');
    if (!PHONE_OK(row.telephone)) return invalid($('r-tel'), 'Téléphone invalide (9 chiffres, ex : 77 123 45 67).');
    if (row.garantie.length < 2) return invalid($('r-guar'), 'Indiquez le bien mis en garantie (ex : téléphone, ordinateur…).');
    if (row.passeport.length < 5 || row.passeport.length > 20) return invalid($('r-pass'), 'Numéro de passeport invalide (5 à 20 lettres ou chiffres) : il est obligatoire en garantie.');
    if (!Number.isInteger(montant) || montant < 5000 || montant > 500000) return invalid(inputM, 'Montant entre 5 000 et 500 000 FCFA (nombre entier).');
    if (![7, 14].includes(row.duree)) return invalid(dureeEl, 'Choisissez une durée de remboursement.');
    if (sig.problem()) { $('sigCanvas').scrollIntoView({ block: 'center' }); return invalid(null, sig.problem()); }
    if (!$('sigCheck').checked) return invalid($('sigCheck'), 'Cochez la case pour certifier votre signature.');
    if (!contractOpened) { $('viewContractBtn').scrollIntoView({ block: 'center' }); return invalid($('viewContractBtn'), 'Lisez le contrat avant d\'envoyer votre demande (faites-le défiler ou ouvrez-le en plein écran).'); }
    if (!$('contractCheck').checked) return invalid($('contractCheck'), 'Cochez « J\'ai lu et j\'accepte les conditions du contrat » pour envoyer votre demande.');
    row.contract_version = CONTRACT_VERSION;
    row.signature_data_url = sig.toDataURL();
    row.signed_ua = navigator.userAgent.slice(0, 300); // preuve : appareil utilisé (la date, l'IP et l'empreinte sont ajoutées par le serveur)

    const btn = $('newReqBtn');
    await once('new-request', async () => {
      busy(btn, true, 'Envoi en cours…');
      try {
        // Le total, l'échéance et le statut sont calculés par la base de données.
        const { error } = await sb.from('requests').insert(row);
        if (error && error.code !== '23505') throw new AppError(friendly(error)); // 23505 : déjà reçue lors d'un premier essai
        _activeLoan = { id: formId, status: 'pending', montant };
        $('content').dataset.dirty = '';
        toast('Demande envoyée ! Votre contrat est disponible.');
        navigate('/client/requests/' + formId);
      } catch (err) { toast(err instanceof AppError ? err.message : friendly(err), 'error'); busy(btn, false); }
    });
  });
}

/* Signature : garde le dessin quand l'écran change de taille (clavier mobile…) */
function setupSignature(canvas) {
  const ctx = canvas.getContext('2d');
  let drawing = false, lastW = 0, pts = [], ink = 0, box = null, strokes = 0, samples = 0;
  const paintBg = () => { ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height); };
  const style = () => { ctx.strokeStyle = '#0b1f3a'; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; };
  const fit = () => {
    const w = Math.max(200, Math.min(600, canvas.parentElement.clientWidth - 4));
    if (w === lastW) return;
    const snapshot = ink ? canvas.toDataURL() : null;
    canvas.width = w; canvas.height = 180; lastW = w;
    paintBg(); style();
    if (snapshot) { const img = new Image(); img.onload = () => ctx.drawImage(img, 0, 0); img.src = snapshot; }
  };
  fit();
  const ro = new ResizeObserver(fit); ro.observe(canvas.parentElement);
  const pos = (e) => {
    const r = canvas.getBoundingClientRect();
    return { x: (e.clientX - r.left) * (canvas.width / r.width), y: (e.clientY - r.top) * (canvas.height / r.height), t: e.timeStamp,
      p: e.pointerType === 'pen' && e.pressure ? e.pressure : 0.5 };
  };
  const grow = (p) => { box = box ? { x0: Math.min(box.x0, p.x), y0: Math.min(box.y0, p.y), x1: Math.max(box.x1, p.x), y1: Math.max(box.y1, p.y) } : { x0: p.x, y0: p.y, x1: p.x, y1: p.y }; };
  const start = (e) => {
    if (e.button > 0) return;
    e.preventDefault(); canvas.setPointerCapture?.(e.pointerId);
    drawing = true; strokes++; const p = pos(e); pts = [p]; grow(p);
    ctx.beginPath(); ctx.arc(p.x, p.y, 1.1, 0, Math.PI * 2); ctx.fillStyle = '#0b1f3a'; ctx.fill();
    canvas.parentElement.classList.add('signed');
  };
  const move = (e) => {
    if (!drawing) return; e.preventDefault();
    const list = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
    for (const ev of list.length ? list : [e]) {
      const p = pos(ev), a = pts[pts.length - 1];
      const d = Math.hypot(p.x - a.x, p.y - a.y); if (d < 0.8) continue;
      ink += d; samples++; grow(p);
      // Trait plus fin quand on va vite, comme un vrai stylo ; lissage par courbes
      const speed = d / Math.max(1, p.t - a.t);
      const w = Math.max(1.2, Math.min(3.2, 3.4 - speed * 1.1)) * (0.6 + p.p * 0.8);
      ctx.lineWidth = w;
      const mid = { x: (a.x + p.x) / 2, y: (a.y + p.y) / 2 };
      const prevMid = pts.length > 1 ? { x: (pts[pts.length - 2].x + a.x) / 2, y: (pts[pts.length - 2].y + a.y) / 2 } : a;
      ctx.beginPath(); ctx.moveTo(prevMid.x, prevMid.y); ctx.quadraticCurveTo(a.x, a.y, mid.x, mid.y); ctx.stroke();
      pts.push(p); if (pts.length > 3) pts.shift();
    }
  };
  const end = () => { drawing = false; pts = []; };
  canvas.addEventListener('pointerdown', start);
  canvas.addEventListener('pointermove', move);
  ['pointerup', 'pointercancel', 'pointerleave'].forEach((t) => canvas.addEventListener(t, end));
  return {
    clear() { paintBg(); style(); ink = 0; box = null; strokes = 0; samples = 0; canvas.parentElement.classList.remove('signed'); },
    /* Une vraie signature : un tracé assez long et assez large (pas un point ni un petit trait). */
    problem() {
      if (!ink) return 'Signez dans le cadre blanc avec votre doigt (ou la souris).';
      if (ink < 80 || samples < 8 || !box || box.x1 - box.x0 < canvas.width * 0.15 || box.y1 - box.y0 < 12) return 'Signature trop courte : signez comme sur un document papier.';
      return '';
    },
    isEmpty() { return !!this.problem(); },
    toDataURL: () => canvas.toDataURL('image/png'),
  };
}

/* =====================================================================
   ADMIN
   ===================================================================== */
const NEEDS_ACTION = (r) => r.status === 'guarantee_received' || r.status === 'repayment_requested' || (r.status === 'pending' && r.guarantee_declared_at);

function reminderLink(r, label = '📲 Relancer') {
  const tel = digits(r.guarantee_phone || r.telephone); if (tel.length < 9) return '';
  const i = dueInfo(r); if (!i || r.status !== 'paid') return '';
  const msg = i.exigible
    ? `Bonjour ${r.nom}, votre remboursement de ${fcfa(r.total)} était dû le ${fmtDue(r.date_remboursement)}. Avec ${lateDays(r)} jours de retard, la totalité est exigible immédiatement (contrat, section 6) : ${fcfa(amountDue(r))} majorations comprises. Merci de rembourser au plus vite sur notre Wave.`
    : i.d < 0 ? `Bonjour ${r.nom}, votre remboursement de ${fcfa(r.total)} était dû le ${fmtDue(r.date_remboursement)}. Majoration : ${fcfa(PENALTY_PER_DAY)} par jour de retard, soit ${fcfa(amountDue(r))} aujourd'hui. À partir du ${EXIGIBLE_FROM}e jour de retard, la totalité devient exigible immédiatement.`
    : `Bonjour ${r.nom}, petit rappel : votre remboursement de ${fcfa(r.total)} est à effectuer avant le ${fmtDue(r.date_remboursement)}. Merci !`;
  return `<a class="btn btn-secondary btn-sm" target="_blank" rel="noopener" href="https://wa.me/221${tel}?text=${encodeURIComponent(msg)}">${label}</a>`;
}

function adminActionButtons(r, compact = false) {
  const sm = compact ? 'btn-sm' : '';
  const b = [];
  if (r.status === 'pending') b.push(`<button class="btn btn-primary ${sm}" onclick="adminSet(${jsArg(r.id)}, 'guarantee_received')">📦 Garantie reçue</button>`);
  if (r.status === 'guarantee_received') {
    b.push(r.wave_number
      ? `<button class="btn btn-success ${sm}" onclick="markPaid(${jsArg(r.id)})">${ic('wallet')}Marquer comme payé</button>`
      : `<span class="muted">En attente du numéro Wave du client</span>`);
  }
  if (r.status === 'repayment_requested') {
    b.push(`<button class="btn btn-success ${sm}" onclick="adminSet(${jsArg(r.id)}, 'done')">✅ Remboursement reçu</button>`);
    b.push(`<button class="btn btn-danger btn-sm" onclick="adminSet(${jsArg(r.id)}, 'paid', true)">❌ Pas reçu</button>`);
  }
  if (r.status === 'paid' && (daysLeft(r) ?? 99) <= 2) b.push(reminderLink(r));
  if (r.status === 'paid' && !compact) b.push(`<button class="btn btn-ghost btn-sm" onclick="adminSet(${jsArg(r.id)}, 'repayment_requested')">Marquer « En vérification »</button>`);
  if (!compact && ['pending', 'guarantee_received'].includes(r.status)) b.push(`<button class="btn btn-danger btn-sm" onclick="adminSet(${jsArg(r.id)}, 'rejected', true)">Refuser</button>`);
  if (!compact && r.status === 'guarantee_received') b.push(`<button class="btn btn-ghost btn-sm" onclick="adminSet(${jsArg(r.id)}, 'pending')">↩️ Annuler « reçue »</button>`);
  if (!compact && r.status === 'rejected') b.push(`<button class="btn btn-ghost btn-sm" onclick="adminSet(${jsArg(r.id)}, 'pending')">↩️ Remettre en attente</button>`);
  if (['done', 'rejected'].includes(r.status) && r.guarantee_received_at && !r.guarantee_returned_at)
    b.push(`<button class="btn btn-primary ${sm}" onclick="guaranteeReturned(${jsArg(r.id)})">${ic('shield')}Garantie restituée</button>`);
  return b.join(' ');
}

async function guaranteeReturned(id) {
  const note = await askDialog({ title: 'Garantie restituée', message: 'Le client sera notifié que son bien et son passeport lui ont été rendus.', confirmText: 'Confirmer', icon: 'shield',
    input: { label: 'Précision (facultatif)', value: 'Remis en main propre.', choices: ['Remis en main propre.', 'Renvoyé par Yango.'] } });
  if (note === null) return;
  await once('return-' + id, async () => {
    try { await rpc('admin_guarantee_returned', { p_request: id, p_note: note }); toast('Garantie restituée : client notifié.'); }
    catch (e) { toast(e.message, 'error'); }
    route();
  });
}
async function adminSet(id, status, askNote = false) {
  let note = null;
  if (askNote) {
    note = await askDialog(status === 'rejected'
      ? { title: 'Refuser la demande', message: 'Le motif est envoyé au client.', confirmText: 'Refuser', danger: true,
          input: { label: 'Motif du refus', value: '', choices: ['Garantie non conforme', 'Informations incomplètes', 'Passeport non valide', 'Montant trop élevé pour un premier prêt'] } }
      : status === 'paid'
        ? { title: 'Paiement non trouvé', message: 'Le client sera prévenu et la demande repassera en « Payé ».', confirmText: 'Envoyer', danger: true,
            input: { label: 'Message pour le client', value: 'Paiement introuvable sur notre Wave. Vérifiez la référence.' } }
        : { title: 'Message pour le client', confirmText: 'Envoyer', input: { label: 'Message', value: '' } });
    if (note === null) return;
  }
  await once('admin-' + id, async () => {
    try { await rpc('admin_set_status', { p_request: id, p_status: status, p_note: note }); toast(`Statut : ${STATUS[status].label}. Client notifié.`); }
    catch (e) { toast(e.message, 'error'); }
    route();
  });
}


/* =====================================================================
   PREUVE DE VERSEMENT WAVE
   L'admin joint la capture de son reçu Wave en marquant « Payé ».
   Le client la voit en grand ; l'échéance démarre à ce moment-là
   (au plus tard 24 h après le versement — contrat, section 5).
   ===================================================================== */
const PROOF_TYPES = /^image\/(png|jpeg|webp)$/;
function proofCardHtml(r, mode = 'client') {
  if (!r.payment_proof_path) return '';
  const big = mode === 'hero';
  const when = r.payment_proof_at ? `${fmtDate(r.payment_proof_at)} à ${hm(r.payment_proof_at)}` : '';
  const seen = r.proof_viewed_at
    ? `${ic('checks', 'ic-sm')}Vue par le client le ${fmtDate(r.proof_viewed_at)} à ${hm(r.proof_viewed_at)}`
    : `${ic('clock', 'ic-sm')}Pas encore vue · l'échéance démarrera au plus tard le ${r.due_starts_at ? `${fmtDate(r.due_starts_at)} à ${hm(r.due_starts_at)}` : '—'}`;
  return `<section class="card proof-card ${big ? 'big' : ''} ${mode === 'admin' ? 'admin' : ''}" data-proof-card="${esc(r.id)}" aria-label="Preuve de versement Wave">
    <div class="proof-head"><span class="proof-ic">${ic(mode === 'admin' ? 'receipt' : 'check')}</span>
      <div><strong>${mode === 'admin' ? 'Preuve de versement' : 'Votre argent a été envoyé'}</strong>
      <span>${fcfa(r.paid_amount || r.montant)} → Wave ${esc(fmtPhone(r.wave_number))} · ${esc(r.nom)}</span></div></div>
    <button type="button" class="proof-img" data-proof-open="${esc(r.payment_proof_path)}" aria-label="Agrandir la capture du reçu Wave">
      <span class="proof-skel"></span><img alt="Capture du reçu de transfert Wave" decoding="async" data-proof-src="${esc(r.payment_proof_path)}" hidden>
      <span class="proof-zoom">${ic('search', 'ic-sm')}Agrandir</span></button>
    <div class="proof-meta"><span>${ic('send', 'ic-sm')}Envoyée le ${when}</span>${mode === 'admin' ? `<span class="${r.proof_viewed_at ? 'ok' : 'wait'}">${seen}</span>` : ''}</div>
    ${mode !== 'admin' ? `<p class="proof-due" data-proof-due>${r.proof_viewed_at || r.status !== 'paid'
      ? `${ic('calendar', 'ic-sm')}À rembourser : <strong>${fcfa(r.total)}</strong> avant le <strong>${fmtDue(r.date_remboursement)}</strong>`
      : `${ic('calendar', 'ic-sm')}Votre délai de ${r.duree} jours démarre dès l'affichage de ce reçu.`}</p>` : ''}
    <div class="proof-actions"><button type="button" class="btn btn-secondary btn-sm" data-proof-dl="${esc(r.payment_proof_path)}" data-proof-name="recu-wave-${esc(r.receipt_number || r.id.slice(0, 8))}">${ic('download')}Télécharger le reçu</button></div>
  </section>`;
}
/* Charge les captures affichées ; côté client, signale qu'elles ont été vues (départ de l'échéance) */
async function bindProofs(list, { ack = false } = {}) {
  const cards = [...document.querySelectorAll('[data-proof-card]')]; if (!cards.length) return;
  await signUrls(cards.map((c) => c.querySelector('[data-proof-src]')?.dataset.proofSrc));
  cards.forEach((card) => {
    const img = card.querySelector('[data-proof-src]'), r = list.find((x) => x.id === card.dataset.proofCard);
    const url = signedUrl(img.dataset.proofSrc); if (!url) { card.querySelector('.proof-skel').classList.add('err'); return; }
    img.onload = async () => {
      img.hidden = false; card.querySelector('.proof-skel').remove();
      if (!ack || !r || r.proof_viewed_at || r.status !== 'paid' || !card.isConnected) return;
      try {
        const due = await rpc('client_proof_seen', { p_request: r.id });
        r.proof_viewed_at = new Date().toISOString(); if (due) r.date_remboursement = due;
        invalidateData();
        const el = card.querySelector('[data-proof-due]');
        if (el) el.innerHTML = `${ic('calendar', 'ic-sm')}Délai démarré aujourd'hui : <strong>${fcfa(r.total)}</strong> à rembourser avant le <strong>${fmtDue(r.date_remboursement)}</strong>`;
        document.querySelectorAll(`[data-cd="${CSS.escape(r.id)}"]`).forEach((cd) => { cd.outerHTML = countdownCard(r); });
      } catch (_) {}
    };
    img.onerror = () => card.querySelector('.proof-skel')?.classList.add('err');
    img.src = url;
  });
}
async function downloadProof(path, name) {
  await once('dl-' + path, async () => {
    try {
      await signUrls([path]);
      const res = await fetch(signedUrl(path)); if (!res.ok) throw new Error();
      const blob = await res.blob(), ext = (path.split('.').pop() || 'jpg').toLowerCase();
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = `${name}.${ext}`;
      document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 30000);
      toast('Reçu Wave téléchargé.');
    } catch (_) { toast('Téléchargement impossible. Vérifiez votre connexion et réessayez.', 'error'); }
  });
}
document.addEventListener('click', (e) => {
  const o = e.target.closest('[data-proof-open]'); if (o) { e.preventDefault(); openLightbox(o.dataset.proofOpen); return; }
  const d = e.target.closest('[data-proof-dl]'); if (d) { e.preventDefault(); downloadProof(d.dataset.proofDl, d.dataset.proofName || 'recu-wave'); }
});

/* Fenêtre « Confirmer le versement » : capture du reçu Wave obligatoire */
function proofDialog(r, onConfirm) {
  if (window.__autoConfirm) { // tests automatisés : reçu factice généré
    (window.__dialogs = window.__dialogs || []).push(`Confirmer le versement ${fcfa(r.montant)} Wave ${fmtPhone(r.wave_number)} ${r.nom}`);
    const c = document.createElement('canvas'); c.width = 360; c.height = 640; const g = c.getContext('2d');
    g.fillStyle = '#1dc8ff'; g.fillRect(0, 0, 360, 640); g.fillStyle = '#fff'; g.font = 'bold 28px sans-serif'; g.fillText(fcfa(r.montant), 40, 300); g.fillText(r.nom || '', 40, 350);
    return new Promise((ok) => c.toBlob(async (b) => { try { await onConfirm({ blob: b, mime: 'image/png' }); ok(true); } catch (e) { toast(e.message, 'error'); ok(false); } }, 'image/png'));
  }
  return new Promise((resolve) => {
    const wrap = document.createElement('div'); wrap.className = 'dialog-overlay'; wrap.setAttribute('role', 'dialog'); wrap.setAttribute('aria-modal', 'true'); wrap.setAttribute('aria-label', 'Confirmer le versement');
    wrap.innerHTML = `<div class="dialog proof-dialog">
      <span class="dialog-ic">${ic('wallet')}</span>
      <h3>Confirmer le versement</h3>
      <p>Envoyez <strong>${fcfa(r.montant)}</strong> sur le Wave <strong>${esc(fmtPhone(r.wave_number))}</strong> (${esc(r.nom)}), puis joignez la <strong>capture d'écran de votre reçu Wave</strong>. Le client la verra en grand.</p>
      <label class="proof-drop" tabindex="0">
        <input type="file" accept="image/png,image/jpeg,image/webp" id="proofFile" class="sr-only">
        <span class="pd-empty">${ic('image')}<strong>Choisir la capture du reçu</strong><small>${matchMedia('(pointer: coarse)').matches ? 'Depuis vos photos (PNG ou JPG)' : 'PNG ou JPG · glissez-la ici ou collez-la (Ctrl+V)'}</small></span>
        <img class="pd-preview" alt="Aperçu du reçu Wave" hidden>
      </label>
      <button type="button" class="link-btn pd-change" hidden>${ic('refresh', 'ic-sm')}Changer de capture</button>
      <p class="pd-error" role="alert" hidden></p>
      <div class="dialog-actions"><button type="button" class="btn btn-secondary" data-act="no">Annuler</button>
        <button type="button" class="btn btn-primary" data-act="yes" disabled>Confirmer le versement</button></div></div>`;
    document.body.appendChild(wrap);
    const input = wrap.querySelector('#proofFile'), prev = wrap.querySelector('.pd-preview'), empty = wrap.querySelector('.pd-empty'),
      yes = wrap.querySelector('[data-act="yes"]'), err = wrap.querySelector('.pd-error'), change = wrap.querySelector('.pd-change'), drop = wrap.querySelector('.proof-drop');
    let file = null;
    const showErr = (m) => { err.textContent = m; err.hidden = !m; };
    const take = (f) => {
      if (!f) return;
      if (!PROOF_TYPES.test(f.type)) return showErr(/heic|heif/i.test(f.type + f.name) ? "Format HEIC non pris en charge : envoyez une capture d'écran (PNG) ou une photo JPG." : 'Choisissez une image (capture d\'écran PNG ou JPG).');
      if (f.size > MAX_FILE) return showErr('Image trop lourde (10 Mo maximum).');
      showErr(''); file = f;
      if (prev.src) URL.revokeObjectURL(prev.src);
      prev.src = URL.createObjectURL(f); prev.hidden = false; empty.hidden = true; change.hidden = false; yes.disabled = false; drop.classList.add('has-file');
    };
    input.onchange = () => take(input.files[0]);
    change.onclick = () => input.click();
    drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
    drop.addEventListener('dragleave', () => drop.classList.remove('over'));
    drop.addEventListener('drop', (e) => { e.preventDefault(); drop.classList.remove('over'); take(e.dataTransfer.files[0]); });
    drop.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); input.click(); } });
    const onPaste = (e) => { const it = [...(e.clipboardData?.items || [])].find((x) => x.type.startsWith('image/')); if (it) take(it.getAsFile()); };
    const onKey = (e) => { if (e.key === 'Escape' && !yes.classList.contains('is-busy')) close(false); };
    document.addEventListener('paste', onPaste); document.addEventListener('keydown', onKey);
    const close = (v) => { document.removeEventListener('paste', onPaste); document.removeEventListener('keydown', onKey); wrap.classList.add('out'); setTimeout(() => wrap.remove(), 180); resolve(v); };
    wrap.addEventListener('click', async (e) => {
      if (e.target === wrap && !yes.classList.contains('is-busy')) return close(false);
      const a = e.target.closest('[data-act]'); if (!a) return;
      if (a.dataset.act === 'no') return close(false);
      if (!file) return showErr("Joignez la capture d'écran de votre reçu Wave.");
      yes.classList.add('is-busy'); busy(yes, true, 'Envoi de la preuve…'); showErr('');
      try { await onConfirm(await compressImage(file)); close(true); }
      catch (ex) { busy(yes, false); yes.classList.remove('is-busy'); showErr(ex.message || 'Envoi impossible. Réessayez.'); }
    });
    requestAnimationFrame(() => drop.focus());
  });
}

/* Relit le numéro Wave juste avant de confirmer : si le client vient de le changer, on affiche le bon. */
async function markPaid(id) {
  await once('paid-' + id, async () => {
    let r;
    try { ({ data: r } = await q(sb.from('requests').select('id,client_id,montant,wave_number,status,nom').eq('id', id).single())); }
    catch (e) { return toast(e.message, 'error'); }
    if (r.status !== 'guarantee_received') { toast('Statut déjà modifié : la page est actualisée.', 'info'); return route(); }
    if (!r.wave_number) return toast("Le client n'a pas encore donné son numéro Wave.", 'error');
    const ok = await proofDialog(r, async ({ blob, mime }) => {
      const ext = mime === 'image/png' ? 'png' : mime === 'image/webp' ? 'webp' : 'jpg';
      const path = `${r.client_id}/preuve-${r.id}-${Date.now().toString(36)}.${ext}`;
      const { error } = await sb.storage.from('chat').upload(path, blob, { contentType: mime, cacheControl: '3600', upsert: false });
      if (error) throw new AppError('Envoi de la capture impossible : ' + friendly(error));
      await rpc('admin_mark_paid', { p_request: r.id, p_proof_path: path });
    });
    if (!ok) return;
    invalidateData();
    toast('Versement confirmé : la preuve est envoyée au client, son reçu est créé.');
    route();
  });
}

let _remindersRun = false;
async function renderAdminDashboard() {
  const paint = painter();
  if (!_remindersRun) { _remindersRun = true; rpc('admin_run_reminders', {}).catch(() => { _remindersRun = false; }); }
  const [reqs] = await Promise.all([listWithCache('admin-list', sb.from('requests').select(LIST_COLS).order('created_at', { ascending: false }).limit(1000)), loadScores()]);
  if (!paint()) return;
  const by = (st) => reqs.filter((r) => r.status === st);
  const lent = reqs.filter((r) => ['paid', 'repayment_requested', 'done'].includes(r.status)).reduce((s, r) => s + (r.paid_amount || r.montant || 0), 0);
  const expected = [...by('paid'), ...by('repayment_requested')].reduce((s, r) => s + (r.total || 0), 0);
  const todo = reqs.filter(NEEDS_ACTION);
  const dueSoon = by('paid').filter((r) => (daysLeft(r) ?? 99) <= 2).sort((a, b) => daysLeft(a) - daysLeft(b));
  const lateN = dueSoon.filter((r) => daysLeft(r) < 0).length;
  $('content').innerHTML = `${offlineNote()}
    <div class="page-head"><div><h1 class="page-title">Vue d'ensemble</h1><p class="page-subtitle">${pl(reqs.length, 'demande')} au total.</p></div>
      <a class="btn btn-primary btn-sm" href="#/admin/requests">Toutes les demandes →</a></div>
    ${_msgUnread ? `<a class="alert-due info msg-alert" href="#/admin/messages">${ic('chat', 'ic-inline')}${pl(_msgUnread, 'message client non lu', 'messages clients non lus')} · Répondre</a>` : ''}
    <div class="kpis kpis-admin">
      <a class="kpi k-gold" href="#/admin/requests"><span class="kpi-ic">${ic('hourglass')}</span><div class="kpi-label">À traiter</div><div class="kpi-value">${todo.length}</div><div class="kpi-sub">${todo.length > 1 ? 'demandes' : 'demande'} en attente d'action</div></a>
      <a class="kpi ${lateN ? 'k-red' : 'k-green'}" href="#/admin/dues"><span class="kpi-ic">${ic('alert')}</span><div class="kpi-label">En retard</div><div class="kpi-value">${lateN}</div><div class="kpi-sub">${pl(dueSoon.length - lateN, 'échéance')} sous 2 jours</div></a>
      <a class="kpi k-blue" href="#/admin/stats"><span class="kpi-ic">${ic('wallet')}</span><div class="kpi-label">Capital prêté</div><div class="kpi-value">${lent.toLocaleString('fr-FR')}</div><div class="kpi-sub">FCFA</div></a>
      <a class="kpi k-green" href="#/admin/dues"><span class="kpi-ic">${ic('chart')}</span><div class="kpi-label">À encaisser</div><div class="kpi-value">${expected.toLocaleString('fr-FR')}</div><div class="kpi-sub">FCFA</div></a>
    </div>
    <div class="card" style="margin-bottom:20px;"><div class="card-title">À traiter maintenant</div>
      ${todo.length ? adminTable(todo, true) : `<div class="state-card compact">${emptyArt('inbox')}<h2>Tout est à jour</h2><p>Aucune demande n'attend d'action de votre part.</p></div>`}
    </div>
    ${dueSoon.length ? `<div class="card"><div class="card-title">Échéances en retard ou proches <a class="btn btn-ghost btn-sm" href="#/admin/dues" style="margin-left:8px;">Tout l'échéancier →</a></div>${adminTable(dueSoon, true)}</div>` : ''}`;
}

let _adminFilter = 'todo', _adminSearch = '';
const PAGE_SIZE = 50;
let _adminPage = 1;
async function renderAdminRequests() {
  const paint = painter();
  const [reqs] = await Promise.all([listWithCache('admin-list', sb.from('requests').select(LIST_COLS).order('created_at', { ascending: false }).limit(1000)), loadScores()]);
  if (!paint()) return;
  const tabs = [['todo', 'À traiter', NEEDS_ACTION], ['all', 'Toutes', () => true],
    ...Object.keys(STATUS).map((k) => [k, STATUS[k].label, (r) => r.status === k])];
  const draw = () => {
    const f = tabs.find((t) => t[0] === _adminFilter) || tabs[1];
    const term = _adminSearch.trim().toLowerCase(), td = digits(_adminSearch);
    const rows = reqs.filter(f[2]).filter((r) => !term
      || [r.nom, r.guarantee_name, r.passeport, r.receipt_number].some((v) => String(v || '').toLowerCase().includes(term))
      || (td.length >= 3 && [r.telephone, r.guarantee_phone, r.wave_number].some((v) => digits(v).includes(td))));
    const shown = rows.slice(0, _adminPage * PAGE_SIZE);
    $('adminList').innerHTML = rows.length ? adminTable(shown) + (rows.length > shown.length
      ? `<button class="btn btn-secondary btn-block" id="moreRows" style="margin-top:12px;">Afficher plus (${rows.length - shown.length} restante${rows.length - shown.length > 1 ? 's' : ''})</button>` : '')
      : `<div class="state-card">${emptyArt(term ? 'search' : 'inbox')}<h2>${term ? 'Aucun résultat' : 'Rien à traiter ici'}</h2><p>${term ? 'Vérifiez l\'orthographe ou cherchez par numéro de téléphone.' : 'Aucune demande dans cette catégorie pour le moment.'}</p></div>`;
    if ($('moreRows')) $('moreRows').onclick = () => { _adminPage++; draw(); };
    document.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.f === _adminFilter));
  };
  $('content').innerHTML = `${offlineNote()}
    <div class="page-head"><div><h1 class="page-title">Demandes</h1><p class="page-subtitle">Numéros Wave, statuts et actions.</p></div>
      <input class="search" id="adminSearch" type="search" placeholder="Rechercher (nom, numéro…)" value="${esc(_adminSearch)}" aria-label="Rechercher une demande"></div>
    <div class="tabs">${tabs.map(([k, l, fn]) => `<button class="tab" data-f="${k}">${l}<span class="n">${reqs.filter(fn).length}</span></button>`).join('')}</div>
    <div id="adminList"></div>`;
  document.querySelectorAll('.tab').forEach((t) => { t.onclick = () => { _adminFilter = t.dataset.f; _adminPage = 1; draw(); }; });
  let t; $('adminSearch').oninput = (e) => { _adminSearch = e.target.value; _adminPage = 1; clearTimeout(t); t = setTimeout(draw, 120); };
  draw();
}

/* Badge de fiabilité : un seul appel pour tous les clients, gardé 60 s. */
let _scores = new Map(), _scoresAt = 0;
async function loadScores() {
  if (Date.now() - _scoresAt < 60000) return _scores;
  try { const rows = await rpc('admin_client_scores', {}); _scores = new Map((rows || []).map((x) => [x.client_id, x])); _scoresAt = Date.now(); }
  catch (_) { /* hors ligne : on garde les derniers scores */ }
  return _scores;
}
function trustLevel(sc) {
  if (!sc) return null;
  if (sc.late_now > 0) return ['red', 'Risqué', 'En retard de paiement en ce moment'];
  if (sc.very_late > 0 || sc.late_repaid >= 2) return ['red', 'Risqué', `${pl(sc.late_repaid, 'remboursement')} en retard${sc.very_late ? ', dont ' + sc.very_late + ' de plus de 3 jours' : ''}`];
  if (!sc.done) return ['orange', 'Nouveau', 'Aucun prêt encore remboursé'];
  if (sc.late_repaid === 1) return ['orange', 'À surveiller', `1 retard sur ${pl(sc.done, 'prêt remboursé', 'prêts remboursés')}`];
  return ['green', 'Fiable', `${pl(sc.done, 'prêt remboursé', 'prêts remboursés')} à l'heure`];
}
function trustBadge(clientId) {
  const t = trustLevel(_scores.get(clientId)); if (!t) return '';
  return `<span class="trust ${t[0]}" title="${esc(t[2])}"><i class="dot ${t[0]}"></i>${t[1]}</span>`;
}

function adminTable(rows, compact = false) {
  return `<div class="table-wrap"><table class="rtable">
    <thead><tr><th>Date</th><th>Client</th><th>Prêt</th><th>Wave du client</th><th>Statut</th><th>Action</th><th>Documents</th><th></th></tr></thead>
    <tbody>${rows.map((r) => `<tr>
      <td data-label="Date"><div class="cell">${fmtDate(r.created_at)}</div></td>
      <td data-label="Client"><div class="cell"><strong>${esc(r.guarantee_name || r.nom)}</strong>${trustBadge(r.client_id)}<span class="muted">${esc(fmtPhone(r.guarantee_phone || r.telephone))}</span></div></td>
      <td data-label="Prêt" class="mono"><div class="cell">${fcfa(r.montant)}<span class="muted">à rendre : ${fcfa(r.total)}</span>${penaltyOf(r) ? `<span class="muted" style="color:var(--red)">+ ${fcfa(penaltyOf(r))} de retard</span>` : ''}<span class="muted">échéance ${dueTxt(r)}</span></div></td>
      <td data-label="Wave"><div class="cell">${waveCell(r.wave_number)}</div></td>
      <td data-label="Statut"><div class="cell">${statusBadge(r.status)} ${dueChip(r)}${r.status === 'pending' && r.guarantee_declared_at ? `<span class="muted">${ic('box', 'ic-inline')} garantie annoncée</span>` : ''}${r.status === 'repayment_requested' ? `<span class="muted">${fcfa(r.repayment_amount)} · réf. ${esc(r.repayment_ref)}</span>` : ''}</div></td>
      <td data-label="Action"><div class="cell"><div class="row-actions">${adminActionButtons(r, true) || '<span class="muted">—</span>'}</div></div></td>
      <td data-label="Documents"><div class="cell"><div class="row-actions">${docButtons(r, true)}</div></div></td>
      <td class="rt-more"><a class="btn btn-ghost btn-sm" href="#/admin/requests/${esc(r.id)}">Détails</a></td>
    </tr>`).join('')}</tbody></table></div>`;
}

const ADMIN_DETAIL_COLS = LIST_COLS + ',message,signed_at,signature_sha256,signed_ip,signed_ua';
const _prefetch = new Map();
function prefetchAdminRequest(id) {
  const p = _prefetch.get(id); if (p && Date.now() - p.at < 8000) return p.promise;
  const promise = q(sb.from('requests').select(ADMIN_DETAIL_COLS).eq('id', id).maybeSingle());
  promise.catch(() => _prefetch.delete(id));
  _prefetch.set(id, { at: Date.now(), promise }); return promise;
}
['pointerdown', 'mouseover'].forEach((ev) => document.addEventListener(ev, (e) => {
  if (currentUser?.role !== 'admin') return;
  const a = e.target.closest && e.target.closest('a[href^="#/admin/requests/"]');
  const m = a && a.getAttribute('href').match(/^#\/admin\/requests\/([0-9a-f-]{36})$/);
  if (m) prefetchAdminRequest(m[1]);
}, { passive: true, capture: true }));
async function renderAdminRequest(id) {
  const paint = painter();
  const { data: r } = await prefetchAdminRequest(id);
  _prefetch.delete(id);
  if (!paint()) return;
  if (!r) { toast('Demande introuvable.', 'error'); return navigate('/admin/requests'); }
  const [reliability, , smsRows] = await Promise.all([reliabilityHtml(r), loadScores(),
    q(sb.from('sms_log').select('id,kind,phone,status,error,created_at,sent_at').eq('request_id', r.id).order('created_at', { ascending: false }).limit(20)).then((x) => x.data || []).catch(() => [])]);
  if (!paint()) return;
  const waMsg = {
    pending: `Bonjour ${r.nom}, votre demande de ${fcfa(r.montant)} est bien reçue. Envoyez votre garantie par Yango à l'adresse indiquée sur le site.`,
    guarantee_received: `Bonjour ${r.nom}, nous avons bien reçu votre garantie. L'argent arrive sur votre Wave.`,
    paid: `Bonjour ${r.nom}, ${fcfa(r.paid_amount || r.montant)} ont été envoyés sur votre Wave ${fmtPhone(r.wave_number)}. À rembourser : ${fcfa(r.total)} avant le ${fmtDue(r.date_remboursement)}. Reçu N° ${r.receipt_number || ''}.`,
    repayment_requested: `Bonjour ${r.nom}, nous vérifions votre remboursement.`,
    done: `Bonjour ${r.nom}, votre prêt est entièrement remboursé. Merci !`,
    rejected: `Bonjour ${r.nom}, votre demande a été refusée : ${r.rejection_reason || ''}`,
  }[r.status] || '';
  const waPhone = digits(r.guarantee_phone || r.telephone);
  $('content').innerHTML = `
    <a class="btn btn-ghost btn-sm" href="#/admin/requests">← Demandes</a>
    <div class="page-head" style="margin-top:16px;">
      <div><h1 class="page-title">${esc(r.nom)} ${trustBadge(r.client_id)}</h1><p class="page-subtitle">Prêt de ${fcfa(r.montant)} · demande du ${fmtDate(r.created_at)}</p></div>
      ${statusBadge(r.status)}
    </div>
    ${steps(r.status)}
    ${(() => { const i = dueInfo(r); return i ? `<div class="alert-due ${i.level === 'ok' ? 'info' : i.level}">${esc(i.label)} · échéance le ${fmtDue(r.date_remboursement)}</div>` : ''; })()}
    ${lateDays(r) > 0 ? emergencyCardHtml(r) : ''}
    <div class="card next-card" style="margin-bottom:20px;">
      <div class="card-title">Actions</div>
      ${r.status === 'guarantee_received' && r.wave_number ? `<div class="copy-row"><div><div class="k">Envoyez depuis votre appli Wave</div><div class="v">${fcfa(r.montant)} → <span class="wave">${esc(fmtPhone(r.wave_number))}</span></div></div>${copyBtn(digits(r.wave_number), '📋 Copier le numéro')}</div>` : ''}
      ${r.status === 'repayment_requested' ? `<div class="note">Le client dit avoir envoyé <strong>${fcfa(r.repayment_amount)}</strong> (réf. <strong>${esc(r.repayment_ref)}</strong>) depuis <span class="wave">${esc(fmtPhone(r.wave_number))}</span>. Vérifiez dans votre appli Wave.</div>` : ''}
      <div class="row-actions" style="margin-top:12px;">${adminActionButtons(r) || '<span class="muted">Aucune action disponible.</span>'}</div>
      <div class="row-actions" style="margin-top:12px;">${waPhone.length >= 9 && waMsg ? `<a class="btn btn-secondary btn-sm" target="_blank" rel="noopener" href="https://wa.me/221${waPhone}?text=${encodeURIComponent(waMsg)}">📲 Écrire au client sur WhatsApp</a>` : ''}<a class="btn btn-ghost btn-sm" href="#/admin/messages/${esc(r.client_id)}">💬 Messages du client</a></div>
    </div>
    ${proofCardHtml(r, 'admin')}
    ${lateDays(r) > 0 ? '' : emergencyCardHtml(r)}
    ${reliability}
    <div class="card" style="margin-bottom:20px;">
      <div class="card-title">Client et garantie</div>
      <div class="detail-row"><div class="detail-key">Nom (garantie)</div><div class="detail-val">${esc(r.guarantee_name || '—')}</div></div>
      <div class="detail-row"><div class="detail-key">Téléphone</div><div class="detail-val">${esc(fmtPhone(r.guarantee_phone || r.telephone))}</div></div>
      <div class="detail-row"><div class="detail-key">Numéro Wave</div><div class="detail-val">${waveCell(r.wave_number)}</div></div>
      <div class="detail-row"><div class="detail-key">Garantie</div><div class="detail-val">${esc(garantieText(r))}</div></div>
      ${r.message ? `<div class="detail-row"><div class="detail-key">Message</div><div class="detail-val">${esc(r.message)}</div></div>` : ''}
    </div>
    <div class="card">
      <div class="card-title">Historique</div>
      ${timelineHtml(r)}
      <div class="detail-row"><div class="detail-key">Total dû · échéance</div><div class="detail-val">${fcfa(r.total)} · ${dueTxt(r)}${penaltyOf(r) ? ` · <span style="color:var(--red)">+ ${fcfa(penaltyOf(r))} de majorations</span>` : ''}</div></div>
      <div class="detail-row"><div class="detail-key">Documents</div><div class="detail-val"><div class="row-actions">${docButtons(r)}</div>${r.receipt_number ? `<span class="muted">Reçu N° ${esc(r.receipt_number)}</span>` : ''}</div></div>
    </div>
    ${signatureCardHtml(r)}
    ${smsCardHtml(smsRows)}`;
  bindSignatureCard(r);
  bindProofs([r]);
}

/* ---------- Preuve de signature (admin) ---------- */
function deviceOf(ua) {
  if (!ua) return '—';
  const os = /iphone|ipad/i.test(ua) ? 'iPhone/iPad' : /android/i.test(ua) ? 'Android' : /windows/i.test(ua) ? 'Windows' : /mac os/i.test(ua) ? 'Mac' : /linux/i.test(ua) ? 'Linux' : 'Autre';
  const br = /edg\//i.test(ua) ? 'Edge' : /crios|chrome/i.test(ua) ? 'Chrome' : /fxios|firefox/i.test(ua) ? 'Firefox' : /safari/i.test(ua) ? 'Safari' : 'Navigateur';
  return `${os} · ${br}`;
}
async function sha256Hex(text) {
  if (!crypto.subtle) throw new AppError('Vérification impossible : ouvrez le site en https.');
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text));
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
}
function signatureCardHtml(r) {
  const at = r.signed_at || r.contract_accepted_at;
  return `<div class="card" style="margin-top:20px;" id="sigCard">
    <div class="card-title">Signature électronique</div>
    <div class="detail-row"><div class="detail-key">Signé le</div><div class="detail-val">${at ? esc(fmtDateTime(at)) + ' <span class="muted">(heure du serveur)</span>' : '—'}</div></div>
    <div class="detail-row"><div class="detail-key">Contrat accepté</div><div class="detail-val">${esc(r.contract_version || '—')}</div></div>
    <div class="detail-row"><div class="detail-key">Adresse IP</div><div class="detail-val mono">${esc(r.signed_ip || '—')}</div></div>
    <div class="detail-row"><div class="detail-key">Appareil</div><div class="detail-val" title="${esc(r.signed_ua || '')}">${esc(deviceOf(r.signed_ua))}</div></div>
    <div class="detail-row"><div class="detail-key">Empreinte SHA-256</div><div class="detail-val mono hash">${esc(r.signature_sha256 || 'non disponible (demande antérieure à la v10)')}</div></div>
    <div id="sigVerify" style="margin-top:12px;"><button class="btn btn-secondary btn-sm" id="sigVerifyBtn">🔍 Afficher et vérifier la signature</button></div>
  </div>`;
}
function bindSignatureCard(r) {
  const b = $('sigVerifyBtn'); if (!b) return;
  b.onclick = () => once('sig-' + r.id, async () => {
    busy(b, true, 'Vérification…');
    try {
      const { data } = await q(sb.from('requests').select('signature_data_url').eq('id', r.id).single());
      const img = /^data:image\/png;base64,/.test(data?.signature_data_url || '') ? data.signature_data_url : null;
      if (!img) { $('sigVerify').innerHTML = '<div class="note">Aucune signature enregistrée.</div>'; return; }
      let verdict = '<span class="muted">Empreinte non enregistrée (ancienne demande).</span>';
      if (r.signature_sha256) {
        const h = await sha256Hex(img);
        verdict = h === r.signature_sha256 ? '<span class="trust green">✅ Signature intacte : empreinte conforme</span>'
          : '<span class="trust red">❌ Empreinte différente : signature modifiée</span>';
      }
      $('sigVerify').innerHTML = `<div class="sig-proof"><img src="${img}" alt="Signature du client"></div><div style="margin-top:8px;">${verdict}</div>`;
    } catch (e) { toast(e.message, 'error'); busy(b, false); }
  });
}

/* ---------- SMS (admin) ---------- */
async function loadSmsLog() {
  const el = $('smsLog'); if (!el) return;
  try {
    const { data } = await q(sb.from('sms_log').select('id,kind,phone,status,error,created_at,sent_at').order('created_at', { ascending: false }).limit(20));
    if ($('smsLog')) $('smsLog').innerHTML = data.length ? smsRowsHtml(data, true) : '<p class="muted">Aucun SMS pour le moment.</p>';
  } catch (e) { if ($('smsLog')) $('smsLog').innerHTML = `<p class="muted">${esc(e.message)}</p>`; }
}
const SMS_KIND = { paid: 'Argent envoyé', j2: 'Rappel J-2', j0: 'Rappel jour J', late1: 'Retard', late4: 'Retard +3 jours', test: 'Test' };
const SMS_STATUS = { queued: ['soon', '⏳ En cours'], sent: ['ok', '✅ Envoyé'], failed: ['late', '❌ Échec'] };
function smsRowsHtml(rows, withPhone = false) {
  return rows.map((x) => `<div class="due-row">
    <span><strong>${esc(SMS_KIND[x.kind] || x.kind)}</strong> <span class="muted">· ${esc(fmtDateTime(x.created_at))}${withPhone ? ' · ' + esc(fmtPhone(String(x.phone).replace(/^221/, ''))) : ''}</span>
      ${x.error ? `<div class="muted" style="color:var(--red)">${esc(x.error)}</div>` : ''}</span>
    <span><span class="due-chip ${SMS_STATUS[x.status]?.[0] || 'ok'}">${SMS_STATUS[x.status]?.[1] || esc(x.status)}</span>
      ${x.status === 'failed' && x.phone !== '?' ? `<button class="btn btn-ghost btn-sm" onclick="resendSms(${Number(x.id)})">↻ Renvoyer</button>` : ''}</span>
  </div>`).join('');
}
function smsCardHtml(rows) {
  if (!rows.length) return '';
  return `<div class="card" style="margin-top:20px;"><div class="card-title">SMS envoyés au client</div>${smsRowsHtml(rows)}</div>`;
}
async function resendSms(id) {
  await once('sms-' + id, async () => {
    try { await rpc('admin_resend_sms', { p_id: id }); toast('SMS renvoyé.'); route(); } catch (e) { toast(e.message, 'error'); }
  });
}

async function renderAdminSettings() {
  const paint = painter();
  const s = await getSettings(true);
  if (!paint()) return;
  $('content').innerHTML = `
    <div class="page-head"><div><h1 class="page-title">Paramètres</h1><p class="page-subtitle">Ce que voient les clients pour envoyer la garantie et rembourser.</p></div></div>
    <form class="card" style="max-width:800px;" id="settingsForm" novalidate>
      <div class="card-title" style="font-size:1rem;">Votre Wave (remboursements)</div>
      <div class="form-grid">
        <div class="field"><label for="st-wave">Numéro Wave</label><input id="st-wave" type="tel" inputmode="tel" maxlength="20" value="${esc(fmtPhone(s.wave_number || ''))}"></div>
        <div class="field"><label for="st-wname">Nom affiché dans Wave</label><input id="st-wname" maxlength="60" value="${esc(s.wave_name)}"></div>
      </div>
      <div class="card-title" style="font-size:1rem;margin-top:10px;">Bouton « Urgence »</div>
      <div class="field"><label for="st-cwa">Numéro WhatsApp d'urgence</label><input id="st-cwa" type="tel" inputmode="tel" maxlength="20" value="${esc(fmtPhone(s.contact_whatsapp || '786649062'))}">
        <span class="muted">Jamais affiché dans l'appli : le bouton « Urgence » ouvre directement WhatsApp vers ce numéro.</span></div>
      <div class="card-title" style="font-size:1rem;margin-top:10px;">Livraison des garanties (Yango)</div>
      <div class="form-grid">
        <div class="field"><label for="st-rname">Destinataire</label><input id="st-rname" maxlength="80" value="${esc(s.receiver_name)}"></div>
        <div class="field"><label for="st-rphone">Téléphone</label><input id="st-rphone" type="tel" inputmode="tel" maxlength="20" value="${esc(fmtPhone(s.receiver_phone || ''))}"></div>
        <div class="field full"><label for="st-raddr">Adresse</label><input id="st-raddr" maxlength="200" value="${esc(s.receiver_address)}"></div>
        <div class="field full"><label for="st-rnote">Note pour le coursier</label><input id="st-rnote" maxlength="200" value="${esc(s.receiver_note)}"></div>
      </div>
      <div class="card-title" style="font-size:1rem;margin-top:10px;">Notifications push (appli fermée)</div>
      <div class="field"><label for="st-vapid">Clé publique VAPID</label><input id="st-vapid" value="${esc(s.vapid_public_key || '')}" maxlength="120" spellcheck="false" placeholder="Collez la « Public Key »"></div>
      <p class="muted" style="margin-bottom:14px;">Laissez vide pour désactiver. La clé privée ne doit jamais être mise ici : elle reste dans les secrets Supabase.</p>
      <div class="card-title" style="font-size:1rem;margin-top:10px;">Rappels SMS automatiques</div>
      <label class="switch-row"><input type="checkbox" id="st-sms" ${s.sms_enabled ? 'checked' : ''}>
        <span><strong>Envoyer les SMS automatiquement</strong><span class="muted">Argent envoyé, rappel J-2, jour J, retard, retard de plus de 3 jours. Un seul SMS par étape et par prêt, chaque matin à 8 h.</span></span></label>
      <div class="field" style="margin-top:10px;"><label for="st-smsname">Nom d'expéditeur (facultatif)</label><input id="st-smsname" maxlength="11" value="${esc(s.sms_sender_name || '')}" placeholder="ex. NEXUSCREDIT" spellcheck="false">
        <span class="muted">11 caractères max, lettres et chiffres sans accent. Il doit d'abord être validé par Orange ; sinon laissez vide.</span></div>
      <button class="btn btn-primary" type="submit">💾 Enregistrer</button>
    </form>
    <div class="card" style="max-width:800px;margin-top:20px;">
      <div class="card-title">Tester l'envoi de SMS</div>
      <p class="muted" style="margin-bottom:10px;">Fonctionne même si les SMS automatiques sont désactivés. Voir le guide pour brancher Orange SMS API.</p>
      <div class="inline-form"><input id="smsTestPhone" type="tel" inputmode="tel" maxlength="20" placeholder="Votre numéro, ex. 78 632 52 75" aria-label="Numéro pour le test" value="${esc(fmtPhone(s.wave_number) || '')}">
        <button class="btn btn-secondary" id="smsTestBtn">📩 Envoyer un SMS de test</button></div>
      <div id="smsTestResult" style="margin-top:10px;"></div>
    </div>
    <div class="card" style="max-width:800px;margin-top:20px;"><div class="card-title">Derniers SMS</div><div id="smsLog"><p class="muted">Chargement…</p></div></div>`;
  loadSmsLog();
  $('smsTestBtn').onclick = () => once('sms-test', async () => {
    const btn = $('smsTestBtn'); busy(btn, true, 'Envoi…');
    try {
      const id = await rpc('admin_test_sms', { p_phone: $('smsTestPhone').value });
      $('smsTestResult').innerHTML = '<span class="due-chip soon">⏳ SMS en cours d\'envoi…</span>';
      for (let i = 0; i < 10; i++) {
        await new Promise((ok) => setTimeout(ok, 1500));
        const { data } = await q(sb.from('sms_log').select('status,error').eq('id', id).maybeSingle());
        if (data && data.status !== 'queued') {
          $('smsTestResult').innerHTML = data.status === 'sent' ? '<span class="trust green">✅ SMS envoyé : vérifiez votre téléphone.</span>'
            : `<span class="trust red">❌ Échec : ${esc(data.error || 'erreur inconnue')}</span>`;
          loadSmsLog(); return;
        }
      }
      $('smsTestResult').innerHTML = '<div class="note">Le SMS est toujours en attente : la fonction <strong>send-sms</strong> n\'est pas encore branchée (voir le guide, étape « Rappels SMS »).</div>';
      loadSmsLog();
    } catch (e) { invalid($('smsTestPhone'), e.message); }
    finally { busy(btn, false); }
  });
  $('settingsForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = (id) => $(id).value.trim();
    const patch = { wave_number: digits(v('st-wave')), wave_name: v('st-wname'), receiver_name: v('st-rname'), receiver_phone: digits(v('st-rphone')),
      receiver_address: v('st-raddr'), receiver_note: v('st-rnote'), vapid_public_key: v('st-vapid'),
      sms_enabled: $('st-sms').checked, sms_sender_name: v('st-smsname'),
      contact_whatsapp: digits(v('st-cwa')), updated_at: new Date().toISOString() };
    if (!PHONE_OK(patch.contact_whatsapp)) return invalid($('st-cwa'), 'Numéro WhatsApp invalide.');
    if (patch.sms_sender_name && !/^[A-Za-z0-9 ]{2,11}$/.test(patch.sms_sender_name)) return invalid($('st-smsname'), "Nom d'expéditeur : 2 à 11 lettres ou chiffres, sans accent ni symbole.");
    if (patch.vapid_public_key && !/^[A-Za-z0-9_-]{80,100}$/.test(patch.vapid_public_key)) return invalid($('st-vapid'), 'Clé publique VAPID invalide (environ 87 caractères, sans espace).');
    if (!PHONE_OK(patch.wave_number)) return invalid($('st-wave'), 'Numéro Wave invalide.');
    if (patch.wave_name.length < 2) return invalid($('st-wname'), 'Indiquez le nom affiché dans Wave.');
    if (patch.receiver_name.length < 2) return invalid($('st-rname'), 'Indiquez le destinataire.');
    if (!PHONE_OK(patch.receiver_phone)) return invalid($('st-rphone'), 'Téléphone invalide.');
    if (patch.receiver_address.length < 10) return invalid($('st-raddr'), 'Adresse trop courte : indiquez quartier, rue et numéro.');
    const btn = e.target.querySelector('button[type=submit]');
    await once('settings', async () => {
      busy(btn, true, 'Enregistrement…');
      try { await q(sb.from('app_settings').update(patch).eq('id', 1)); _settings = null; $('content').dataset.dirty = ''; toast('Paramètres enregistrés.'); loadContact(); }
      catch (err) { toast(err.message, 'error'); }
      finally { busy(btn, false); }
    });
  });
}


/* =====================================================================
   PROFIL (client et admin)
   ===================================================================== */
async function renderProfile() {
  const paint = painter();
  const u = currentUser;
  const perm = 'Notification' in window ? Notification.permission : 'unsupported';
  if (!paint()) return;
  $('content').innerHTML = `
    <section class="profile-hero">
      <div class="ph-avatar">${esc(String(u.full_name || u.email || '?').trim().split(/\s+/).slice(0, 2).map((w) => w.charAt(0).toUpperCase()).join(''))}</div>
      <div class="ph-text"><h1 class="page-title">${esc(u.full_name || 'Mon profil')}</h1>
        <p>${esc(u.email)}${u.phone ? ' · ' + esc(fmtPhone(u.phone)) : ''}</p>
        ${u.role === 'admin' ? `<span class="badge badge-approved">Administrateur</span>` : ''}</div>
    </section>
    <div class="profile-grid">
    <form class="card" id="profileForm" novalidate>
      <div class="card-title">${ic('user', 'ic-sm')}Mes informations</div>
      <div class="field"><label for="pf-name">Nom complet</label><input id="pf-name" value="${esc(u.full_name || '')}" autocomplete="name" maxlength="80"></div>
      <div class="field"><label for="pf-phone">Téléphone</label><input id="pf-phone" type="tel" inputmode="tel" value="${esc(fmtPhone(u.phone || ''))}" autocomplete="tel" maxlength="20"></div>
      <button class="btn btn-primary btn-block" type="submit">${ic('check')}Enregistrer</button>
    </form>
    <form class="card" id="pwdForm" novalidate>
      <div class="card-title">${ic('lock', 'ic-sm')}Mot de passe</div>
      <div class="field"><label for="pf-pass">Nouveau mot de passe</label><input id="pf-pass" type="password" autocomplete="new-password" placeholder="6 caractères minimum"></div>
      <div class="field"><label for="pf-pass2">Confirmation</label><input id="pf-pass2" type="password" autocomplete="new-password" placeholder="Retapez le mot de passe"></div>
      <button class="btn btn-secondary btn-block" type="submit">Changer le mot de passe</button>
    </form>
    <div class="card settings-list">
      <div class="card-title">${ic('settings', 'ic-sm')}Préférences</div>
      <div class="pref-row"><span class="pr-ic">${ic('bell')}</span><span class="pr-text"><strong>Notifications</strong><small>${perm === 'granted' ? 'Activées sur ce téléphone' : perm === 'default' ? 'Soyez prévenu à chaque étape' : perm === 'denied' ? 'Bloquées : autorisez-les dans les réglages du navigateur' : 'Non disponibles sur ce navigateur'}</small></span>
        ${perm === 'granted' ? `<span class="badge badge-done">Activées</span>` : perm === 'default' ? '<button class="btn btn-primary btn-sm" onclick="enablePush().then(route)">Activer</button>' : ''}</div>
      <div class="pref-row"><span class="pr-ic">${ic('moon')}</span><span class="pr-text"><strong>Apparence</strong><small>Thème clair ou sombre</small></span><button class="icon-btn" data-theme-toggle aria-label="Changer de thème">🌙</button></div>
      <div class="pref-row"><span class="pr-ic">${ic('phone')}</span><span class="pr-text"><strong>Application</strong><small>Sur l'écran d'accueil, en plein écran</small></span><button class="btn btn-ghost btn-sm" id="installBtn">Installer</button></div>
      ${u.role === 'admin' ? `<a class="pref-row" href="#/admin/settings"><span class="pr-ic">${ic('settings')}</span><span class="pr-text"><strong>Paramètres</strong><small>Wave, adresse, SMS, notifications</small></span>${ic('chevron')}</a>` : ''}
      <a class="pref-row" href="#/help"><span class="pr-ic">${ic('shield')}</span><span class="pr-text"><strong>Aide</strong><small>Questions fréquentes</small></span>${ic('chevron')}</a>
      <a class="pref-row" href="#/legal/confidentialite"><span class="pr-ic">${ic('doc')}</span><span class="pr-text"><strong>Confidentialité et conditions</strong><small>Vos données et vos droits</small></span>${ic('chevron')}</a>
      ${u.role === 'client' ? `<button type="button" class="pref-row" id="deleteAccount"><span class="pr-ic danger">${ic('trash')}</span><span class="pr-text"><strong>Supprimer mon compte</strong><small>Demande traitée par Nexus Crédit</small></span>${ic('chevron')}</button>` : ''}
    </div>
    </div>
    <button class="btn btn-secondary btn-block logout-btn" id="profileLogout">${ic('logout')}Se déconnecter</button>
    <p class="app-version">Nexus Crédit · version 2026.11</p>`;
  if ($('deleteAccount')) $('deleteAccount').onclick = () => once('delete-account', async () => {
    if (!(await askDialog({ title: 'Supprimer mon compte ?', message: 'Votre demande sera traitée par Nexus Crédit. Un compte avec un prêt en cours ne peut être supprimé qu\'après le remboursement.', confirmText: 'Envoyer la demande', danger: true, icon: 'trash' }))) return;
    try { await rpc('send_message', { p_body: 'Je souhaite supprimer mon compte et mes données personnelles.', p_category: 'autre' }); toast('Demande envoyée. Nous vous répondons dans Messages.'); }
    catch (err) { toast(err.message, 'error'); }
  });
  applyTheme(document.documentElement.getAttribute('data-theme'));
  $('profileLogout').onclick = logout;
  $('installBtn').onclick = installApp;
  renderInstallBanners();
  $('profileForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = $('pf-name').value.trim().replace(/\s+/g, ' '), phone = $('pf-phone').value.trim();
    if (name.length < 2 || name.length > 80) return invalid($('pf-name'), 'Nom complet : 2 à 80 caractères.');
    if (!PHONE_OK(phone)) return invalid($('pf-phone'), 'Téléphone invalide (9 chiffres, ex : 77 123 45 67).');
    const btn = e.target.querySelector('button[type=submit]');
    await once('profile', async () => {
      busy(btn, true, 'Enregistrement…');
      try { await rpc('profile_update', { p_name: name, p_phone: phone }); currentUser.full_name = name; currentUser.phone = phone; $('content').dataset.dirty = ''; toast('Profil enregistré.'); }
      catch (err) { toast(err.message, 'error'); } finally { busy(btn, false); }
    });
  });
  $('pwdForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const p1 = $('pf-pass').value, p2 = $('pf-pass2').value;
    if (p1.length < 6 || p1.length > 72) return invalid($('pf-pass'), 'Mot de passe : 6 à 72 caractères.');
    if (p1 !== p2) return invalid($('pf-pass2'), 'Les deux mots de passe ne correspondent pas.');
    const btn = e.target.querySelector('button[type=submit]');
    await once('password', async () => {
      busy(btn, true, 'Enregistrement…');
      try {
        const { error } = await sb.auth.updateUser({ password: p1 });
        if (error) throw new AppError(authErrorMessage(error));
        $('pf-pass').value = ''; $('pf-pass2').value = ''; $('content').dataset.dirty = '';
        toast('Mot de passe modifié.');
      } catch (err) { toast(err instanceof AppError ? err.message : friendly(err), 'error'); } finally { busy(btn, false); }
    });
  });
}

/* =====================================================================
   ADMIN : échéancier
   ===================================================================== */
async function renderAdminDues() {
  const paint = painter();
  const [reqs] = await Promise.all([listWithCache('admin-dues', sb.from('requests').select(LIST_COLS).in('status', ['paid', 'repayment_requested']).limit(1000)), loadScores()]);
  if (!paint()) return;
  const withD = reqs.map((r) => ({ r, d: daysLeft(r) ?? 0 })).sort((a, b) => a.d - b.d);
  const groups = [
    ['🚨 Exigibles (plus de 3 jours de retard)', (x) => x.r.status === 'paid' && x.d <= -EXIGIBLE_FROM, 'late'],
    ['⚠️ En retard', (x) => x.r.status === 'paid' && x.d < 0 && x.d > -EXIGIBLE_FROM, 'late'],
    ["📍 Aujourd'hui", (x) => x.r.status === 'paid' && x.d === 0, 'late'],
    ['⏰ Dans 1 à 2 jours', (x) => x.r.status === 'paid' && x.d >= 1 && x.d <= 2, 'soon'],
    ['🗓️ Dans 3 à 7 jours', (x) => x.r.status === 'paid' && x.d >= 3 && x.d <= 7, 'ok'],
    ['📆 Plus tard', (x) => x.r.status === 'paid' && x.d > 7, 'ok'],
    ['⏳ Remboursements à vérifier', (x) => x.r.status === 'repayment_requested', 'soon'],
  ];
  const sum = (arr) => arr.reduce((t, x) => t + amountDue(x.r), 0);
  const late = withD.filter((x) => x.r.status === 'paid' && x.d < 0);
  const week = withD.filter((x) => x.r.status === 'paid' && x.d >= 0 && x.d <= 7);
  $('content').innerHTML = `${offlineNote()}
    <div class="page-head"><div><h1 class="page-title">Échéancier</h1><p class="page-subtitle">Tous les prêts versés, du plus urgent au plus lointain.</p></div></div>
    <div class="kpis">
      <div class="kpi"><div class="kpi-label">En retard</div><div class="kpi-value" style="color:${late.length ? 'var(--red)' : 'var(--green)'}">${late.length}</div><div class="kpi-sub">${fcfa(sum(late))}</div></div>
      <div class="kpi"><div class="kpi-label">À encaisser sous&nbsp;7&nbsp;j</div><div class="kpi-value">${week.length}</div><div class="kpi-sub">${fcfa(sum(week))}</div></div>
    </div>
    ${withD.length ? groups.map(([title, fn, lvl]) => {
      const rows = withD.filter(fn); if (!rows.length) return '';
      return `<div class="card due-group ${lvl}" style="margin-bottom:16px;"><div class="card-title">${title} <span class="muted">· ${rows.length} · ${fcfa(sum(rows))}</span></div>
        ${rows.map(({ r }) => `<div class="due-row">
          <div class="due-main"><strong>${esc(r.guarantee_name || r.nom)}</strong> ${trustBadge(r.client_id)} ${dueChip(r)}
            <div class="muted">${fcfa(r.total)}${penaltyOf(r) ? ` + ${fcfa(penaltyOf(r))} de majorations = <strong>${fcfa(amountDue(r))}</strong>` : ''} · échéance ${fmtDue(r.date_remboursement)} · Wave ${esc(fmtPhone(r.wave_number))}</div>
            ${lateDays(r) > 0 && r.contact1_phone ? `<div class="due-contacts"><span>${ic('phone', 'ic-sm')}Contacts d'urgence :</span>${[[r.contact1_name, r.contact1_phone], [r.contact2_name, r.contact2_phone]].filter(([, t]) => t).map(([n, t]) => `<a class="chip-wa" target="_blank" rel="noopener" href="${waLink(t, `Bonjour ${n}, ${r.nom} vous a désigné(e) comme contact d'urgence auprès de Nexus Crédit. Pouvez-vous l'aider à nous joindre au sujet de son remboursement ? Merci.`)}">${ic('chat', 'ic-sm')}${esc(n)} · ${esc(fmtPhone(t))}</a>`).join('')}</div>` : ''}</div>
          <div class="row-actions">${reminderLink(r)}${r.status === 'repayment_requested' ? `<button class="btn btn-success btn-sm" onclick="adminSet(${jsArg(r.id)}, 'done')">✅ Reçu</button>` : ''}<a class="btn btn-ghost btn-sm" href="#/admin/requests/${esc(r.id)}">Détails</a></div>
        </div>`).join('')}</div>`;
    }).join('') : `<div class="state-card compact">${emptyArt('inbox')}<h2>Aucun prêt en cours</h2><p>Les prêts versés et non remboursés s'afficheront ici.</p></div>`}`;
}

/* =====================================================================
   APPLICATION INSTALLABLE (PWA) : service worker, installation, push
   ===================================================================== */
const isStandalone = () => matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
const UA = navigator.userAgent;
const isIOS = /iphone|ipad|ipod/i.test(UA) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const isAndroid = /android/i.test(UA);
const isIOSSafari = isIOS && /safari/i.test(UA) && !/crios|fxios|edgios|opios/i.test(UA);
let _swReg = null;

async function registerSW() {
  if (!('serviceWorker' in navigator) || !/^https?:/.test(location.protocol)) return;
  try {
    _swReg = await navigator.serviceWorker.register('sw.js');
    // Nouvelle version disponible : proposer de recharger
    _swReg.addEventListener('updatefound', () => {
      const w = _swReg.installing;
      w && w.addEventListener('statechange', () => {
        if (w.state === 'installed' && navigator.serviceWorker.controller) showAppUpdate(w);
      });
    });
    setInterval(() => _swReg.update().catch(() => {}), 60 * 60 * 1000);
  } catch (e) { console.warn('[sw]', e); }
}
function showAppUpdate(worker) {
  const bar = $('appUpdate'); if (!bar) return;
  bar.hidden = false;
  $('appUpdateBtn').onclick = () => {
    navigator.serviceWorker.addEventListener('controllerchange', () => location.reload(), { once: true });
    worker.postMessage('skipWaiting');
  };
}

/* Notification système : passe par le service worker (obligatoire sur Android/iPhone en appli installée). */
async function systemNotify(title, body, requestId, link) {
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  const url = link ? '#' + link : requestId && currentUser ? `#/${currentUser.role === 'admin' ? 'admin' : 'client'}/requests/${requestId}` : '';
  try {
    const reg = _swReg || (navigator.serviceWorker && await navigator.serviceWorker.getRegistration());
    if (reg) return reg.showNotification('Nexus Crédit — ' + title, { body: body || '', icon: 'icon-192.png', badge: 'icon-192.png', tag: requestId || undefined, data: { url: 'index.html' + url } });
    const n = new Notification('Nexus Crédit — ' + title, { body: body || '', icon: 'icon-192.png' });
    n.onclick = () => { window.focus(); openNotif(requestId, link); };
  } catch (_) {}
}

/* Abonnement push : notifications même appli fermée (clé publique VAPID dans Paramètres). */
const b64ToBytes = (b64) => { const p = '='.repeat((4 - (b64.length % 4)) % 4); const s = atob((b64 + p).replace(/-/g, '+').replace(/_/g, '/')); return Uint8Array.from(s, (c) => c.charCodeAt(0)); };
async function subscribePush() {
  if (!currentUser || !('PushManager' in window) || Notification.permission !== 'granted') return false;
  try {
    const s = await getSettings().catch(() => null);
    const key = s && s.vapid_public_key;
    if (!key) return false;
    const reg = _swReg || await navigator.serviceWorker.ready;
    let sub = await reg.pushManager.getSubscription();
    if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToBytes(key) });
    const j = sub.toJSON();
    await rpc('push_subscribe', { p_endpoint: j.endpoint, p_p256dh: j.keys.p256dh, p_auth: j.keys.auth, p_ua: UA.slice(0, 300) });
    return true;
  } catch (e) { console.warn('[push]', e); return false; }
}
async function unsubscribePush() {
  try {
    const reg = _swReg || (navigator.serviceWorker && await navigator.serviceWorker.getRegistration());
    const sub = reg && await reg.pushManager.getSubscription();
    if (sub) { await rpc('push_unsubscribe', { p_endpoint: sub.endpoint }).catch(() => {}); await sub.unsubscribe(); }
  } catch (_) {}
}

/* Bannière « Installer l'application » adaptée au téléphone */
let _installPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => { e.preventDefault(); if (isIOS) return; // iPhone : installation uniquement via Safari → Partager
  _installPrompt = e; renderInstallBanners(); });
window.addEventListener('appinstalled', () => { _installPrompt = null; try { localStorage.setItem('nexusInstalled', '1'); } catch (_) {} renderInstallBanners(); toast('Application installée !'); });
const installDismissed = () => { try { return Number(localStorage.getItem('nexusInstallHide') || 0) > Date.now(); } catch (_) { return false; } };
function installHelpHtml() {
  if (isIOS && !isIOSSafari) return `<ol class="howto"><li>Ouvrez ce site dans <strong>Safari</strong> (obligatoire sur iPhone).</li><li>Touchez <strong>Partager</strong> <span class="ios-share">⬆︎</span> en bas de l'écran.</li><li>Choisissez <strong>« Sur l'écran d'accueil »</strong> puis <strong>Ajouter</strong>.</li></ol>`;
  if (isIOS) return `<ol class="howto"><li>Touchez <strong>Partager</strong> <span class="ios-share">⬆︎</span> en bas de Safari.</li><li>Faites défiler et choisissez <strong>« Sur l'écran d'accueil »</strong>.</li><li>Touchez <strong>Ajouter</strong> : l'icône NEXUS CRÉDIT apparaît sur votre écran.</li></ol>`;
  if (isAndroid) return `<ol class="howto"><li>Touchez <strong>Installer</strong> ci-dessous.</li><li>Sinon : menu <strong>⋮</strong> de Chrome → <strong>« Installer l'application »</strong> ou « Ajouter à l'écran d'accueil ».</li></ol>`;
  return `<ol class="howto"><li>Cliquez sur <strong>Installer</strong> ci-dessous,</li><li>ou sur l'icône d'installation <strong>⊕</strong> dans la barre d'adresse de Chrome / Edge.</li></ol>`;
}
function installBannerHtml(compact = false, mini = false) {
  if (isStandalone() || installDismissed()) return '';
  const canPrompt = !!_installPrompt;
  if (mini) return `<div class="install-banner mini">
    <img src="icon-192.png" alt="" width="32" height="32">
    <div class="ib-text"><strong>Installer l'appli</strong><span class="muted">${isIOS ? 'iPhone : iOS 16.4 ou plus récent' : 'Plein écran, en un geste'}</span></div>
    ${canPrompt ? '<button class="btn btn-primary btn-sm" onclick="installApp()">Installer</button>' : '<button class="btn btn-primary btn-sm" onclick="showInstallHelp()">Comment installer ?</button>'}
    <button class="icon-btn" title="Plus tard" aria-label="Masquer" onclick="hideInstallBanner()">${ic('x')}</button>
  </div>`;
  return `<div class="install-banner ${compact ? 'compact' : ''}">
    <img src="icon-192.png" alt="" width="52" height="52">
    <div class="ib-text"><strong>Installez l'application Nexus Crédit</strong>
      <span class="muted">Accès en un geste, plein écran, notifications ${isIOS ? '(iPhone : iOS 16.4 ou plus récent)' : ''}.</span></div>
    <div class="ib-actions">
      ${canPrompt ? '<button class="btn btn-primary btn-sm" onclick="installApp()">📲 Installer</button>' : `<button class="btn btn-primary btn-sm" onclick="showInstallHelp()">📲 Comment installer ?</button>`}
      <button class="icon-btn" title="Plus tard" aria-label="Masquer" onclick="hideInstallBanner()">${ic('x')}</button>
    </div>
  </div>`;
}
function renderInstallBanners() {
  document.querySelectorAll('[data-install-slot]').forEach((el) => { el.innerHTML = installBannerHtml(el.dataset.installSlot === 'compact', el.dataset.installSlot === 'mini'); });
  const b = $('installBtn'); if (b) b.textContent = isStandalone() ? 'Installée ✔' : 'Installer';
}
function hideInstallBanner() { try { localStorage.setItem('nexusInstallHide', String(Date.now() + 7 * 86400000)); } catch (_) {} renderInstallBanners(); }
function showInstallHelp() {
  $('installHelpBody').innerHTML = `<div class="install-help">
    <img src="icon-512.png" alt="Icône NEXUS CRÉDIT" width="96" height="96">
    <p>${isIOS ? 'Sur <strong>iPhone</strong>' : isAndroid ? 'Sur <strong>Android</strong>' : 'Sur <strong>ordinateur</strong>'} :</p>
    ${installHelpHtml()}
    ${_installPrompt ? '<button class="btn btn-primary btn-block" onclick="installApp()">📲 Installer maintenant</button>' : ''}
    <p class="muted" style="margin-top:12px;">Une fois installée, ouvrez l'appli depuis l'icône : elle s'affiche en plein écran, comme une vraie application, et fonctionne même avec une connexion faible.</p>
  </div>`;
  $('installModal').classList.add('show');
}
async function installApp() {
  if (isStandalone()) return toast("L'application est déjà installée.", 'info');
  if (_installPrompt) {
    const p = _installPrompt; _installPrompt = null;
    p.prompt();
    const choice = await p.userChoice.catch(() => null);
    if (choice && choice.outcome === 'accepted') toast('Installation en cours…');
    renderInstallBanners();
    $('installModal').classList.remove('show');
    return;
  }
  showInstallHelp();
}

/* =====================================================================
   HORS CONNEXION : dernières données consultées (lecture seule)
   ===================================================================== */
const OFFLINE_KEY = (k) => `nexusCache:${currentUser ? currentUser.id : 'x'}:${k}`;
function cacheData(k, data) { try { localStorage.setItem(OFFLINE_KEY(k), JSON.stringify({ at: Date.now(), data })); } catch (_) {} }
function cachedData(k) { try { return JSON.parse(localStorage.getItem(OFFLINE_KEY(k)) || 'null'); } catch (_) { return null; } }
function clearUserCache() { try { Object.keys(localStorage).filter((k) => k.startsWith('nexusCache:') || k === 'nexusProfile').forEach((k) => localStorage.removeItem(k)); } catch (_) {} }
/* Requête de liste avec repli sur le cache si la connexion est perdue. */
let _servedFromCache = null;
/* Cache mémoire : une page déjà vue s'affiche instantanément, puis se met à jour
   en arrière-plan si les données ont changé (aucune donnée périmée ne reste affichée). */
const _memo = new Map();
const MEMO_FRESH = 4000;
const sigOf = (rows) => (rows || []).map((r) => `${r.id}:${r.updated_at || ''}:${r.status || ''}`).join('|');
function invalidateData() { _memo.clear(); _scoresAt = 0; if (typeof _prefetch !== "undefined") _prefetch.clear(); }
const _seeded = new Set();
async function listWithCache(k, query) {
  // Premier affichage après l'ouverture : dernières données connues tout de suite, puis mise à jour (une seule fois par clé).
  if (!_memo.has(k) && !_seeded.has(k) && navigator.onLine) {
    _seeded.add(k);
    const c = cachedData(k);
    if (c && Date.now() - c.at < 24 * 3600e3) _memo.set(k, { at: 0, data: c.data });
  }
  const m = _memo.get(k);
  if (m && navigator.onLine) {
    if (m.checking && Date.now() - m.at < MEMO_FRESH) { _servedFromCache = null; return m.data; }
    m.checking = true;
    const shownOn = location.hash;
    q(query).then(({ data }) => {
      cacheData(k, data);
      const changed = sigOf(data) !== sigOf(m.data);
      _memo.set(k, { at: Date.now(), data });
      if (changed && location.hash === shownOn) { if (isEditing()) showUpdateBar(); else route(); }
    }).catch(() => {});
    _servedFromCache = null;
    return m.data;
  }
  try {
    const { data } = await q(query);
    cacheData(k, data); _servedFromCache = null;
    _memo.set(k, { at: Date.now(), data });
    return data;
  } catch (e) {
    const c = cachedData(k);
    if (c && !navigator.onLine) { _servedFromCache = c.at; return c.data; }
    throw e;
  }
}
const offlineNote = () => (_servedFromCache ? `<div class="note" style="margin-bottom:16px;">📡 Hors connexion — données du ${fmtDateTime(_servedFromCache)}. Les actions reprendront au retour d'internet.</div>` : '');

/* =====================================================================
   CALCULATRICE DE PRÊT (page d'accueil, sans compte)
   ===================================================================== */
function setupCalculator() {
  const m = $('calcAmount'), r = $('calcRange'), out = $('calcOut');
  if (!m || m.dataset.ready) return;
  m.dataset.ready = '1';
  let duree = 7;
  const draw = () => {
    const v = Math.min(500000, Math.max(0, numVal(m)));
    const taux = duree === 7 ? 0.25 : 0.35, frais = Math.round(v * taux), total = v + frais;
    const valid = v >= 5000 && v <= 500000;
    if ($('calcRate')) $('calcRate').textContent = `${duree} jours · ${duree === 7 ? '+25 %' : '+35 %'}`;
    out.innerHTML = valid ? `
      <div class="calc-total"><span>À rembourser</span><strong>${fcfa(total)}</strong></div>
      <div class="calc-meta">Frais ${fcfa(frais)} · ${duree} jours pour rembourser<br>Retard : +${fcfa(PENALTY_PER_DAY)} par jour</div>`
      : '<div class="calc-meta">Montant entre 5 000 et 500 000 FCFA.</div>';
  };
  m.oninput = () => { const v = numVal(m); fmtAmountInput(m); if (v >= 5000 && v <= 500000) { r.value = v; paintRange(r); } draw(); };
  r.oninput = () => { m.value = r.value; fmtAmountInput(m); paintRange(r); draw(); };
  fmtAmountInput(m); paintRange(r);
  document.querySelectorAll('[data-calc-duree]').forEach((b) => {
    b.onclick = () => { duree = Number(b.dataset.calcDuree); document.querySelectorAll('[data-calc-duree]').forEach((x) => x.classList.toggle('active', x === b)); draw(); };
  });
  draw();
}

/* =====================================================================
   CLIENT : historique résumé + note de satisfaction
   ===================================================================== */
function historySummary(reqs) {
  const done = reqs.filter((r) => r.status === 'done');
  if (!reqs.length) return '';
  const onTime = done.filter((r) => r.repaid_at && parseDay(r.repaid_at) <= parseDay(r.date_remboursement)).length;
  const borrowed = reqs.filter((r) => ['paid', 'repayment_requested', 'done'].includes(r.status)).reduce((t, r) => t + (r.paid_amount || r.montant || 0), 0);
  return `<div class="kpis kpis-3">
    <div class="kpi"><div class="kpi-label">Total emprunté</div><div class="kpi-value">${borrowed.toLocaleString('fr-FR')}</div><div class="kpi-sub">FCFA</div></div>
    <div class="kpi"><div class="kpi-label">Prêts remboursés</div><div class="kpi-value">${done.length}</div><div class="kpi-sub">sur ${pl(reqs.length, 'demande')}</div></div>
    <div class="kpi"><div class="kpi-label">À l'heure</div><div class="kpi-value">${done.length ? Math.round(onTime * 100 / done.length) + ' %' : '—'}</div><div class="kpi-sub">${onTime}/${done.length} remboursés avant l'échéance</div></div>
  </div>`;
}

async function ratingCardHtml(r) {
  if (r.status !== 'done') return '';
  let existing = null;
  try { ({ data: existing } = await q(sb.from('loan_ratings').select('rating,comment').eq('request_id', r.id).maybeSingle())); } catch (_) {}
  const cur = existing ? existing.rating : 0;
  return `<div class="card" style="margin-bottom:20px;" id="ratingCard">
    <div class="card-title">${existing ? 'Votre note' : 'Notez votre expérience'}</div>
    <div class="stars" role="radiogroup" aria-label="Note de 1 à 5">${[1, 2, 3, 4, 5].map((n) =>
      `<button type="button" class="star ${n <= cur ? 'on' : ''}" data-star="${n}" role="radio" aria-checked="${n === cur}" aria-label="${n} étoile${n > 1 ? 's' : ''}">★</button>`).join('')}</div>
    <div class="field" style="margin-top:12px;"><label for="rateComment">Un commentaire ? (facultatif)</label>
      <textarea id="rateComment" rows="2" maxlength="500" placeholder="Rapidité, accueil, clarté…">${esc(existing ? existing.comment || '' : '')}</textarea></div>
    <button class="btn btn-primary btn-block-m" id="rateBtn">${existing ? 'Mettre à jour ma note' : 'Envoyer ma note'}</button>
  </div>`;
}
function bindRating(r) {
  const card = $('ratingCard'); if (!card) return;
  let val = card.querySelectorAll('.star.on').length;
  card.querySelectorAll('.star').forEach((s) => s.onclick = () => {
    val = Number(s.dataset.star);
    card.querySelectorAll('.star').forEach((x) => { const on = Number(x.dataset.star) <= val; x.classList.toggle('on', on); x.setAttribute('aria-checked', String(Number(x.dataset.star) === val)); });
  });
  $('rateBtn').onclick = () => once('rate-' + r.id, async () => {
    if (!val) return toast('Choisissez une note de 1 à 5 étoiles.', 'error');
    const btn = $('rateBtn'); busy(btn, true, 'Envoi…');
    try {
      await rpc('rate_loan', { p_request: r.id, p_rating: val, p_comment: $('rateComment').value.trim() });
      $('content').dataset.dirty = ''; toast('Merci pour votre avis !');
      card.querySelector('.card-title').textContent = '⭐ Votre note'; btn.dataset.label = 'Mettre à jour ma note';
    }
    catch (e) { toast(e.message, 'error'); } finally { busy(btn, false); }
  });
}

/* =====================================================================
   ADMIN : fiche de fiabilité du client
   ===================================================================== */
async function reliabilityHtml(r) {
  let all = [];
  try { ({ data: all } = await q(sb.from('requests').select('id,status,montant,total,date_remboursement,paid_at,repaid_at,created_at').eq('client_id', r.client_id).order('created_at', { ascending: false }).limit(100))); } catch (_) { return ''; }
  const others = all.filter((x) => x.id !== r.id);
  const done = all.filter((x) => x.status === 'done');
  const late = done.filter((x) => x.repaid_at && parseDay(x.repaid_at) > parseDay(x.date_remboursement));
  const lateNow = all.filter((x) => x.status === 'paid' && (daysLeft(x) ?? 0) < 0);
  const rejected = all.filter((x) => x.status === 'rejected').length;
  let score = 'Nouveau client', cls = 'ok';
  if (done.length) {
    const pct = Math.round((done.length - late.length) * 100 / done.length);
    score = `${pct} % à l'heure`; cls = pct >= 90 ? 'ok' : pct >= 60 ? 'soon' : 'late';
  }
  if (lateNow.length) { score = `En retard actuellement`; cls = 'late'; }
  return `<div class="card" style="margin-bottom:20px;">
    <div class="card-title">Fiabilité du client ${trustBadge(r.client_id)} <span class="due-chip ${cls}" style="margin-left:6px;">${esc(score)}</span></div>
    <div class="kpis kpis-4">
      <div class="kpi"><div class="kpi-label">Demandes</div><div class="kpi-value">${all.length}</div></div>
      <div class="kpi"><div class="kpi-label">Remboursés</div><div class="kpi-value">${done.length}</div></div>
      <div class="kpi"><div class="kpi-label">Avec retard</div><div class="kpi-value" style="color:${late.length ? 'var(--red)' : 'var(--green)'}">${late.length}</div></div>
      <div class="kpi"><div class="kpi-label">Refusées</div><div class="kpi-value">${rejected}</div></div>
    </div>
    ${others.length ? `<div class="muted" style="margin-bottom:6px;">Autres demandes :</div>${others.slice(0, 6).map((x) =>
      `<div class="due-row"><span>${fmtDate(x.created_at)} · ${fcfa(x.montant)}</span><span>${statusBadge(x.status)} <a class="btn btn-ghost btn-sm" href="#/admin/requests/${esc(x.id)}">Voir</a></span></div>`).join('')}` : '<p class="muted">Première demande de ce client.</p>'}
  </div>`;
}

/* =====================================================================
   ADMIN : statistiques
   ===================================================================== */
async function renderAdminStats() {
  const paint = painter();
  const [reqs, , ratingsRes] = await Promise.all([
    listWithCache('admin-stats', sb.from('requests').select(LIST_COLS).order('created_at', { ascending: false }).limit(5000)),
    loadScores(),
    q(sb.from('loan_ratings').select('rating')).catch(() => ({ data: [] })),
  ]);
  if (!paint()) return;
  const ratings = ratingsRes.data || [];
  const disbursed = reqs.filter((r) => ['paid', 'repayment_requested', 'done'].includes(r.status));
  const done = reqs.filter((r) => r.status === 'done');
  const lent = disbursed.reduce((t, r) => t + (r.paid_amount || r.montant || 0), 0);
  const collected = done.reduce((t, r) => t + (r.repayment_amount || r.total || 0), 0);
  const interest = done.reduce((t, r) => t + Math.max(0, (r.repayment_amount || r.total || 0) - (r.paid_amount || r.montant || 0)), 0);
  const outstanding = reqs.filter((r) => ['paid', 'repayment_requested'].includes(r.status));
  const late = outstanding.filter((r) => r.status === 'paid' && (daysLeft(r) ?? 0) < 0);
  const onTime = done.filter((r) => r.repaid_at && parseDay(r.repaid_at) <= parseDay(r.date_remboursement)).length;
  const closedDue = done.length + late.length;
  const repayRate = closedDue ? Math.round(done.length * 100 / closedDue) : null;
  const avg = disbursed.length ? Math.round(lent / disbursed.length) : 0;
  const avgRating = ratings.length ? (ratings.reduce((t, x) => t + x.rating, 0) / ratings.length).toFixed(1) : '—';
  const decided = reqs.filter((r) => r.status !== 'pending' && r.status !== 'guarantee_received');
  const acceptRate = decided.length ? Math.round(decided.filter((r) => r.status !== 'rejected').length * 100 / decided.length) : null;
  // 6 derniers mois
  const months = [];
  for (let i = 5; i >= 0; i--) { const d = new Date(); d.setDate(1); d.setMonth(d.getMonth() - i); months.push([d.getFullYear(), d.getMonth()]); }
  const per = months.map(([y, m]) => {
    const inM = (dt) => { if (!dt) return false; const x = new Date(dt); return x.getFullYear() === y && x.getMonth() === m; };
    return { label: new Date(y, m, 1).toLocaleDateString('fr-FR', { month: 'short' }), lent: disbursed.filter((r) => inM(r.paid_at)).reduce((t, r) => t + (r.paid_amount || r.montant || 0), 0),
      back: done.filter((r) => inM(r.repaid_at)).reduce((t, r) => t + (r.repayment_amount || r.total || 0), 0) };
  });
  const max = Math.max(1, ...per.map((p) => Math.max(p.lent, p.back)));
  $('content').innerHTML = `
    ${offlineNote()}
    <div class="page-head"><div><h1 class="page-title">Statistiques</h1><p class="page-subtitle">${pl(reqs.length, 'demande')} au total.</p></div>
      <button class="btn btn-secondary" onclick="exportCsv()">⬇️ Exporter (Excel / CSV)</button></div>
    <div class="kpis">
      <div class="kpi"><div class="kpi-label">Montant total prêté</div><div class="kpi-value">${lent.toLocaleString('fr-FR')}</div><div class="kpi-sub">FCFA · ${pl(disbursed.length, 'prêt')} · moyenne ${fcfa(avg)}</div></div>
      <div class="kpi"><div class="kpi-label">Encaissé</div><div class="kpi-value">${collected.toLocaleString('fr-FR')}</div><div class="kpi-sub">FCFA · dont ${fcfa(interest)} de frais et majorations</div></div>
      <div class="kpi"><div class="kpi-label">Encours</div><div class="kpi-value">${outstanding.reduce((t, r) => t + amountDue(r), 0).toLocaleString('fr-FR')}</div><div class="kpi-sub">FCFA · ${pl(outstanding.length, 'prêt')} à rembourser</div></div>
      <div class="kpi"><div class="kpi-label">Taux de remboursement</div><div class="kpi-value" style="color:${repayRate === null || repayRate >= 90 ? 'var(--green)' : repayRate >= 70 ? 'var(--gold)' : 'var(--red)'}">${repayRate === null ? '—' : repayRate + ' %'}</div><div class="kpi-sub">${pl(onTime, 'remboursé', 'remboursés')} à l'heure sur ${done.length}</div></div>
      <div class="kpi"><div class="kpi-label">Clients en retard</div><div class="kpi-value" style="color:${late.length ? 'var(--red)' : 'var(--green)'}">${late.length}</div><div class="kpi-sub">${fcfa(late.reduce((t, r) => t + amountDue(r), 0))} majorations comprises</div></div>
      <div class="kpi"><div class="kpi-label">Satisfaction</div><div class="kpi-value">${avgRating}${ratings.length ? '<small>/5</small>' : ''}</div><div class="kpi-sub">${ratings.length} avis · acceptation ${acceptRate === null ? '—' : acceptRate + '\u00a0%'}</div></div>
    </div>
    <div class="card" style="margin-bottom:20px;"><div class="card-title">6 derniers mois</div>
      <div class="chart">${per.map((p) => `<div class="chart-col" title="${esc(p.label)} : prêté ${fcfa(p.lent)}, remboursé ${fcfa(p.back)}">
        <div class="chart-bars"><div class="bar lent" style="height:${Math.round(p.lent * 100 / max)}%"></div><div class="bar back" style="height:${Math.round(p.back * 100 / max)}%"></div></div>
        <div class="chart-label">${esc(p.label)}</div></div>`).join('')}</div>
      <div class="chart-legend"><span><i class="lent"></i>Prêté</span><span><i class="back"></i>Remboursé</span></div>
    </div>
    ${late.length ? `<div class="card"><div class="card-title">Clients en retard</div>${adminTable(late.sort((a, b) => daysLeft(a) - daysLeft(b)), true)}</div>` : ''}`;
}

/* Export CSV (ouvre dans Excel, séparateur « ; », accents conservés) */
async function exportCsv() {
  await once('csv', async () => {
    let rows;
    try { ({ data: rows } = await q(sb.from('requests').select(LIST_COLS).order('created_at', { ascending: false }).limit(5000))); }
    catch (e) { return toast(e.message, 'error'); }
    const cols = [['Date', (r) => fmtDate(r.created_at)], ['Client', (r) => r.guarantee_name || r.nom], ['Téléphone', (r) => r.telephone], ['Wave', (r) => r.wave_number],
      ['Passeport', (r) => r.passeport], ['Garantie', (r) => r.garantie], ['Montant', (r) => r.montant], ['Durée (j)', (r) => r.duree], ['Total', (r) => r.total],
      ['Majorations', (r) => penaltyOf(r)], ['Échéance', (r) => dueTxt(r)], ['Statut', (r) => STATUS[r.status]?.label || r.status],
      ['Payé le', (r) => fmtDate(r.paid_at)], ['N° reçu', (r) => r.receipt_number], ['Remboursé le', (r) => fmtDate(r.repaid_at)], ['Montant remboursé', (r) => r.repayment_amount],
      ["Contact d'urgence 1", (r) => r.contact1_name], ['WhatsApp contact 1', (r) => fmtPhone(r.contact1_phone)], ["Contact d'urgence 2", (r) => r.contact2_name], ['WhatsApp contact 2', (r) => fmtPhone(r.contact2_phone)]];
    const cell = (v) => { let s = String(v ?? '').replace(/"/g, '""'); if (/^[=+\-@]/.test(s)) s = "'" + s; return `"${s}"`; }; // protège Excel des formules
    const csv = '﻿' + [cols.map((c) => cell(c[0])).join(';'), ...rows.map((r) => cols.map((c) => cell(c[1](r) === '—' ? '' : c[1](r))).join(';'))].join('\r\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const a = document.createElement('a'); a.href = url; a.download = `nexus-credit-demandes-${new Date().toISOString().slice(0, 10)}.csv`;
    document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 5000);
    toast(`${pl(rows.length, 'demande exportée', 'demandes exportées')}.`);
  });
}

/* =====================================================================
   BOUTON URGENCE (WhatsApp) — le numéro n'est jamais affiché
   ===================================================================== */
const URGENT_DEFAULT = '786649062';
let _urgent = (() => { try { return localStorage.getItem('nexusUrgent') || URGENT_DEFAULT; } catch (_) { return URGENT_DEFAULT; } })();
const intlPhone = (p) => { let d = digits(p); if (d.startsWith('00')) d = d.slice(2); return d.length === 9 ? '221' + d : d; };
const waLink = (num, text) => `https://wa.me/${intlPhone(num)}?text=${encodeURIComponent(text || '')}`;
const urgentHref = () => waLink(_urgent, 'URGENCE — Bonjour Nexus Crédit, ');
function urgentBtn(extra = '') {
  return `<a class="btn-urgent ${extra}" href="${esc(urgentHref())}" target="_blank" rel="noopener" aria-label="Urgence : écrire sur WhatsApp">${ic('alert')}Urgence</a>`;
}
function paintUrgent() {
  document.querySelectorAll('[data-urgent]').forEach((a) => { a.href = urgentHref(); a.hidden = currentUser?.role !== 'client'; });
}
async function loadContact() {
  try {
    const rows = await rpc('public_contact', {});
    const w = rows && rows[0] && rows[0].whatsapp;
    if (w && digits(w).length >= 9) { _urgent = w; try { localStorage.setItem('nexusUrgent', w); } catch (_) {} }
  } catch (_) { /* hors ligne : dernier numéro connu */ }
  paintUrgent();
}

/* =====================================================================
   MESSAGERIE : texte, messages vocaux, photos et documents
   ===================================================================== */
const MSG_COLS = 'id,client_id,sender,category,request_id,body,kind,attachment_path,attachment_name,attachment_mime,attachment_size,duration_ms,created_at,read_at';
const MSG_CATS = { question: 'Question', probleme: 'Problème', remboursement_anticipe: 'Remboursement anticipé', autre: 'Autre' };
let _msgUnread = 0;
let _msgPrefill = null;
let _threadRefresh = null;
let _chatChannel = null;
function contactAbout(requestId, category) { _msgPrefill = { request: requestId, category }; navigate('/client/messages/chat'); }

async function refreshMsgBadge() {
  if (!currentUser) return;
  try {
    const { count } = await q(sb.from('messages').select('id', { count: 'exact', head: true })
      .eq('sender', currentUser.role === 'admin' ? 'client' : 'admin').is('read_at', null));
    _msgUnread = count || 0;
  } catch (_) {}
  paintMsgBadge();
}
function paintMsgBadge() {
  document.querySelectorAll('[data-msg-badge]').forEach((b) => { b.hidden = !_msgUnread; b.textContent = _msgUnread > 9 ? '9+' : _msgUnread; });
}

/* Liens temporaires vers les fichiers privés (1 h) */
const _signed = new Map();
async function signUrls(paths) {
  const need = [...new Set(paths.filter((p) => p && !(_signed.get(p)?.exp > Date.now())))];
  if (!need.length) return;
  try {
    const { data } = await sb.storage.from('chat').createSignedUrls(need, 3600);
    (data || []).forEach((d) => { if (d.signedUrl) _signed.set(d.path, { url: d.signedUrl, exp: Date.now() + 3300e3 }); });
  } catch (_) {}
}
const signedUrl = (p) => _signed.get(p)?.url || '';

const hm = (d) => new Date(d).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
function dayLabel(d) {
  const x = new Date(d), t = new Date(); t.setHours(0, 0, 0, 0);
  const x0 = new Date(x); x0.setHours(0, 0, 0, 0);
  const diff = Math.round((t - x0) / 864e5);
  if (diff === 0) return "Aujourd'hui";
  if (diff === 1) return 'Hier';
  if (diff < 7) return x.toLocaleDateString('fr-FR', { weekday: 'long' });
  return x.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: x.getFullYear() === t.getFullYear() ? undefined : 'numeric' });
}
function convTime(d) {
  const l = dayLabel(d);
  return l === "Aujourd'hui" ? hm(d) : l === 'Hier' ? 'Hier' : new Date(d).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' });
}
const fmtDur = (ms) => { const s = Math.max(0, Math.round((ms || 0) / 1000)); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; };
const fmtSize = (b) => (!b ? '' : b < 1024 * 1024 ? `${Math.max(1, Math.round(b / 1024))} Ko` : `${(b / 1048576).toFixed(1).replace('.', ',')} Mo`);
const fileExt = (n) => (String(n || '').split('.').pop() || '').slice(0, 4).toUpperCase();
function previewOf(m) {
  if (m.kind === 'voice') return `${ic('mic', 'ic-sm')} Message vocal${m.duration_ms ? ' (' + fmtDur(m.duration_ms) + ')' : ''}`;
  if (m.kind === 'image') return `${ic('image', 'ic-sm')} Photo${m.body ? ' · ' + esc(m.body) : ''}`;
  if (m.kind === 'file') return `${ic('file', 'ic-sm')} ${esc(m.attachment_name || 'Document')}`;
  return esc(m.body || '');
}
const linkify = (html) => html.replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener nofollow">$1</a>');
function waveBars(seed) {
  let x = 0; for (const c of String(seed)) x = (x * 31 + c.charCodeAt(0)) >>> 0;
  return Array.from({ length: 30 }, (_, i) => { x = (x * 1103515245 + 12345) >>> 0; const h = 28 + (x % 72) * (0.55 + 0.45 * Math.sin(i / 3)); return `<i style="height:${Math.max(18, Math.min(100, h)).toFixed(0)}%"></i>`; }).join('');
}

function bubbleHtml(m, me, reqLabel) {
  const mine = m.sender === me;
  const state = m._failed ? 'failed' : m._pending ? 'pending' : m.read_at ? 'read' : 'sent';
  const ticks = mine ? `<span class="tick ${state}" title="${{ pending: 'Envoi en cours', sent: 'Envoyé', read: 'Lu', failed: "Échec de l'envoi" }[state]}">${
    ic({ pending: 'clock', sent: 'check', read: 'checks', failed: 'alert' }[state], 'ic-sm')}</span>` : '';
  const meta = `<span class="b-meta">${hm(m.created_at)}${ticks}</span>`;
  const labels = (m.sender === 'client' && m.category && m.category !== 'question' ? `<div class="b-label">${esc(MSG_CATS[m.category] || '')}</div>` : '')
    + (m.request_id && reqLabel && reqLabel(m.request_id) ? `<div class="b-label">${ic('doc', 'ic-sm')} ${esc(reqLabel(m.request_id))}</div>` : '');
  let content;
  if (m.kind === 'voice') {
    content = `<div class="voice" data-voice="${esc(m.attachment_path || '')}" data-dur="${Number(m.duration_ms) || 0}">
      <button type="button" class="vplay" aria-label="Écouter le message vocal">${ic('play', 'fill')}</button>
      <div class="vwave">${waveBars(m.id)}</div><span class="vdur">${fmtDur(m.duration_ms)}</span></div>`;
  } else if (m.kind === 'image') {
    const u = signedUrl(m.attachment_path);
    content = `<button type="button" class="b-img" data-img="${esc(m.attachment_path || '')}" aria-label="Agrandir la photo">${u ? `<img src="${esc(u)}" alt="Photo" loading="lazy" decoding="async">` : `<span class="b-img-ph">${ic('image', 'ic-lg')}</span>`}</button>`
      + (m.body ? `<div class="b-text">${linkify(esc(m.body))}</div>` : '');
  } else if (m.kind === 'file') {
    const u = signedUrl(m.attachment_path);
    content = `<a class="b-file" ${u ? `href="${esc(u)}" download="${esc(m.attachment_name || 'document')}" target="_blank" rel="noopener"` : ''}>
      <span class="bf-icon">${esc(fileExt(m.attachment_name) || 'DOC')}</span>
      <span class="bf-info"><span class="bf-name">${esc(m.attachment_name || 'Document')}</span><span class="bf-meta">${esc(fmtSize(m.attachment_size))}</span></span>${ic('download')}</a>`
      + (m.body ? `<div class="b-text">${linkify(esc(m.body))}</div>` : '');
  } else content = `<div class="b-text">${linkify(esc(m.body || ''))}</div>`;
  return `<div class="msg-row ${mine ? 'mine' : 'theirs'}" data-mid="${esc(String(m.id))}"><div class="bubble k-${esc(m.kind || 'text')}">${labels}${content}${meta}</div></div>`;
}
function threadHtml(msgs, me, reqLabel, emptyText) {
  if (!msgs.length) return `<div class="chat-empty">${ic('chat', 'ic-lg')}<p>${emptyText}</p></div>`;
  let last = '';
  return msgs.map((m) => {
    const d = dayLabel(m.created_at); const sep = d !== last ? `<div class="day-sep"><span>${esc(d)}</span></div>` : ''; last = d;
    return sep + bubbleHtml(m, me, reqLabel);
  }).join('');
}

/* Lecteur des messages vocaux (un seul à la fois).
   Le fichier est d'abord téléchargé puis lu depuis la mémoire du téléphone avec le bon type :
   Safari (iPhone) refuse un son dont le type annoncé par le serveur n'est pas exact.
   Sur iPhone, le lecteur est « débloqué » pendant le toucher, pour qu'il puisse démarrer après le téléchargement. */
const _player = new Audio(); _player.preload = 'auto'; _player.setAttribute('playsinline', '');
let _playing = null, _playToken = 0;
const _voiceBlobs = new Map();      // chemin → URL locale (blob:)
const AUDIO_TYPES = { mp3: 'audio/mpeg', m4a: 'audio/mp4', mp4: 'audio/mp4', aac: 'audio/aac', webm: 'audio/webm', ogg: 'audio/ogg', oga: 'audio/ogg', wav: 'audio/wav' };
const audioTypeOf = (path) => AUDIO_TYPES[String(path || '').split('?')[0].split('.').pop().toLowerCase()] || 'audio/mpeg';
const SILENCE = (() => { // 0,05 s de silence, pour débloquer le son sur iPhone
  const n = 1102, b = new ArrayBuffer(44 + n * 2), v = new DataView(b), w = (o, t) => [...t].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
  w(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); w(8, 'WAVE'); w(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, 22050, true); v.setUint32(28, 44100, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * 2, true);
  try { return URL.createObjectURL(new Blob([b], { type: 'audio/wav' })); } catch (_) { return ''; }
})();
async function voiceBlobUrl(path) {
  if (_voiceBlobs.has(path)) return _voiceBlobs.get(path);
  const signed = signedUrl(path);
  if (/^blob:/.test(signed)) { _voiceBlobs.set(path, signed); return signed; }
  if (!signed) { await signUrls([path]); }
  const url = signedUrl(path); if (!url) throw new AppError('Message vocal indisponible, réessayez.');
  const res = await fetch(url); if (!res.ok) throw new AppError('Message vocal introuvable.');
  const buf = await res.arrayBuffer();
  const u = URL.createObjectURL(new Blob([buf], { type: audioTypeOf(path) }));
  _voiceBlobs.set(path, u); return u;
}
/* Précharge les vocaux affichés (fichiers légers) pour une lecture instantanée */
function prefetchVoices(paths) {
  paths.filter((p) => p && !p.startsWith('local:') && !_voiceBlobs.has(p)).slice(-12).forEach((p) => { voiceBlobUrl(p).catch(() => {}); });
}
function voiceUi(el, playing, loading = false) {
  if (!el) return;
  el.classList.toggle('playing', playing); el.classList.toggle('loading', loading);
  el.querySelector('.vplay').innerHTML = loading ? '<span class="vspin"></span>' : ic(playing ? 'pause' : 'play', 'fill');
}
const voiceEl = (path) => path && document.querySelector(`.voice[data-voice="${CSS.escape(path)}"]`);
function paintVoiceProgress() {
  if (!_playing) return;
  const el = voiceEl(_playing); if (!el) return;
  const d = _player.duration && isFinite(_player.duration) ? _player.duration : Number(el.dataset.dur) / 1000 || 1;
  const pct = Math.min(1, _player.currentTime / d);
  const bars = el.querySelectorAll('.vwave i'); const n = Math.round(pct * bars.length);
  bars.forEach((b, i) => b.classList.toggle('on', i < n));
  el.querySelector('.vdur').textContent = fmtDur((_player.currentTime || 0) * 1000);
}
function resetVoice(path) {
  const el = voiceEl(path); if (!el) return;
  voiceUi(el, false); el.querySelectorAll('.vwave i').forEach((b) => b.classList.remove('on')); el.querySelector('.vdur').textContent = fmtDur(Number(el.dataset.dur));
}
_player.addEventListener('timeupdate', paintVoiceProgress);
_player.addEventListener('ended', () => { if (_playing) resetVoice(_playing); _playing = null; });
function voiceFailed(path, why) {
  resetVoice(path); if (_playing === path) _playing = null;
  toast(why === 'format'
    ? "Ce message vocal a été enregistré par une ancienne version de l'appli dans un format que cet appareil ne lit pas. Les nouveaux messages vocaux se lisent partout."
    : why || 'Message vocal illisible pour le moment. Vérifiez votre connexion et réessayez.', 'error');
}
async function toggleVoice(el) {
  const path = el.dataset.voice; if (!path) return;
  if (_playing === path && _player.src && !el.classList.contains('loading')) {
    if (_player.paused) { _player.play().then(() => voiceUi(el, true)).catch(() => voiceFailed(path)); } else { _player.pause(); voiceUi(el, false); }
    return;
  }
  if (_playing) { _player.pause(); resetVoice(_playing); }
  const token = ++_playToken; _playing = path;
  const type = audioTypeOf(path);
  if (!path.startsWith('local:') && _player.canPlayType(type) === '') return voiceFailed(path, 'format');
  let url = _voiceBlobs.get(path) || (/^blob:/.test(signedUrl(path)) ? signedUrl(path) : '');
  if (!url) {
    // Toucher en cours : on débloque le son (iPhone), puis on télécharge
    if (SILENCE) { _player.src = SILENCE; _player.play().catch(() => {}); }
    voiceUi(el, false, true);
    try { url = await voiceBlobUrl(path); } catch (e) { if (token === _playToken) voiceFailed(path, e.message); return; }
    if (token !== _playToken) return;
  }
  _player.pause(); _player.src = url;
  try { _player.load(); } catch (_) {}
  _player.play().then(() => { if (token === _playToken) voiceUi(el, true); })
    .catch((e) => { if (token !== _playToken) return; voiceFailed(path, e && e.name === 'NotSupportedError' ? 'format' : e && e.name === 'NotAllowedError' ? 'Touchez de nouveau le bouton lecture.' : null); });
}
function seekVoice(el, e) {
  if (_playing !== el.dataset.voice || !_player.duration) return;
  const r = el.querySelector('.vwave').getBoundingClientRect();
  _player.currentTime = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width)) * _player.duration;
}

/* Visionneuse de photos */
function openLightbox(path) {
  const url = signedUrl(path); if (!url) return;
  let lb = $('lightbox');
  if (!lb) {
    lb = document.createElement('div'); lb.id = 'lightbox'; lb.className = 'lightbox'; lb.setAttribute('role', 'dialog'); lb.setAttribute('aria-label', 'Photo');
    document.body.appendChild(lb);
    lb.addEventListener('click', (e) => { if (e.target === lb || e.target.closest('[data-lb-close]')) lb.classList.remove('show'); });
  }
  lb.innerHTML = `<div class="lb-bar"><a class="icon-btn" href="${esc(url)}" download="photo.jpg" target="_blank" rel="noopener" aria-label="Télécharger">${ic('download')}</a>
    <button class="icon-btn" data-lb-close aria-label="Fermer">${ic('x')}</button></div><img src="${esc(url)}" alt="Photo">`;
  requestAnimationFrame(() => lb.classList.add('show'));
}

/* Photo : redimensionnée (1600 px max) et compressée avant l'envoi */
async function compressImage(file) {
  if (!/^image\/(jpeg|png|webp)$/.test(file.type) || file.size < 350 * 1024) return { blob: file, mime: file.type || 'image/jpeg' };
  try {
    const bmp = await createImageBitmap(file);
    const k = Math.min(1, 1600 / Math.max(bmp.width, bmp.height));
    const c = document.createElement('canvas'); c.width = Math.round(bmp.width * k); c.height = Math.round(bmp.height * k);
    c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
    const blob = await new Promise((ok) => c.toBlob(ok, 'image/jpeg', 0.82));
    return blob && blob.size < file.size ? { blob, mime: 'image/jpeg' } : { blob: file, mime: file.type };
  } catch (_) { return { blob: file, mime: file.type || 'image/jpeg' }; }
}
const DOC_TYPES = { pdf: 'application/pdf', doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xls: 'application/vnd.ms-excel', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', txt: 'text/plain',
  jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp', heic: 'image/heic' };
const MAX_FILE = 10 * 1024 * 1024;

/* Enregistreur de messages vocaux — MP3 (lisible partout : Android, iPhone, ordinateur).
   Le son du micro est capté directement (Web Audio), ramené en mono 22 050 Hz, puis encodé en MP3 à 32 kbit/s
   (≈ 240 Ko par minute). Si l'encodeur MP3 n'a pas pu être chargé, le message part en WAV (lisible partout lui aussi). */
const LAME_URL = 'https://cdn.jsdelivr.net/npm/lamejs@1.2.1/lame.min.js';
let _lameP = null;
function loadLame() {
  if (window.lamejs) return Promise.resolve(true);
  if (_lameP) return _lameP;
  _lameP = new Promise((ok) => {
    const sc = document.createElement('script'); sc.src = LAME_URL; sc.async = true;
    sc.onload = () => ok(!!window.lamejs); sc.onerror = () => { _lameP = null; ok(false); };
    document.head.appendChild(sc);
  });
  return _lameP;
}
const VOICE_RATE = 22050;
function encodeWav(pcm, rate) {
  const b = new ArrayBuffer(44 + pcm.length * 2), v = new DataView(b), w = (o, t) => [...t].forEach((c, i) => v.setUint8(o + i, c.charCodeAt(0)));
  w(0, 'RIFF'); v.setUint32(4, 36 + pcm.length * 2, true); w(8, 'WAVE'); w(12, 'fmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, rate, true); v.setUint32(28, rate * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, pcm.length * 2, true);
  new Int16Array(b, 44).set(pcm); return new Blob([b], { type: 'audio/wav' });
}
function encodeMp3(pcm, rate) {
  const enc = new window.lamejs.Mp3Encoder(1, rate, 32), parts = [];
  for (let i = 0; i < pcm.length; i += 1152) { const o = enc.encodeBuffer(pcm.subarray(i, i + 1152)); if (o.length) parts.push(new Uint8Array(o)); }
  const end = enc.flush(); if (end.length) parts.push(new Uint8Array(end));
  return new Blob(parts, { type: 'audio/mpeg' });
}
const Recorder = {
  rec: null, stream: null, ctx: null, proc: null, src: null, t0: 0, timer: null, chunks: [], level: 0,
  supported: () => !!(navigator.mediaDevices?.getUserMedia && (window.AudioContext || window.webkitAudioContext)),
  async start(onTick) {
    loadLame();
    // Le contexte audio est créé pendant le toucher (obligatoire sur iPhone), avant d'attendre le micro
    const AC = window.AudioContext || window.webkitAudioContext;
    this.ctx = new AC(); try { this.ctx.resume(); } catch (_) {}
    try {
      this.stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true, channelCount: 1 } });
    } catch (e) { try { this.ctx.close(); } catch (_) {} this.ctx = null; throw e; }
    if (this.ctx.state === 'suspended') { try { await this.ctx.resume(); } catch (_) {} }
    const inRate = this.ctx.sampleRate, step = inRate / VOICE_RATE;
    const alpha = Math.min(1, (2 * Math.PI * 7000) / inRate); // filtre passe-bas avant la conversion de fréquence
    let lp = 0, prev = 0, pos = 0;
    this.chunks = []; this.level = 0;
    this.src = this.ctx.createMediaStreamSource(this.stream);
    this.proc = this.ctx.createScriptProcessor(4096, 1, 1);
    this.proc.onaudioprocess = (e) => {
      const inp = e.inputBuffer.getChannelData(0), n = inp.length;
      const f = new Float32Array(n); let peak = 0;
      for (let i = 0; i < n; i++) { lp += alpha * (inp[i] - lp); f[i] = lp; const a = Math.abs(inp[i]); if (a > peak) peak = a; }
      this.level = Math.min(1, peak * 1.6);
      const out = new Int16Array(Math.ceil((n - pos) / step) + 1); let k = 0;
      while (pos < n - 1) {
        const i = Math.floor(pos), t = pos - i;
        const a = i < 0 ? prev : f[i], b2 = i < 0 ? f[0] : f[i + 1];
        const v = Math.max(-1, Math.min(1, a + (b2 - a) * t));
        out[k++] = v < 0 ? v * 0x8000 : v * 0x7fff; pos += step;
      }
      pos -= n; prev = f[n - 1];
      if (k) this.chunks.push(out.subarray(0, k));
      e.outputBuffer.getChannelData(0).fill(0);
    };
    const mute = this.ctx.createGain(); mute.gain.value = 0;
    this.src.connect(this.proc); this.proc.connect(mute); mute.connect(this.ctx.destination);
    this.rec = { state: 'recording' }; this.t0 = Date.now();
    this.timer = setInterval(() => onTick(Date.now() - this.t0, Math.max(0.12, this.level)), 100);
  },
  async stop() {
    clearInterval(this.timer);
    const dur = this.t0 ? Date.now() - this.t0 : 0;
    try { this.src?.disconnect(); this.proc?.disconnect(); } catch (_) {}
    if (this.proc) this.proc.onaudioprocess = null;
    this.stream?.getTracks().forEach((t) => t.stop());
    try { await this.ctx?.close(); } catch (_) {}
    const total = this.chunks.reduce((n, c) => n + c.length, 0), pcm = new Int16Array(total);
    let o = 0; for (const c of this.chunks) { pcm.set(c, o); o += c.length; }
    this.rec = null; this.stream = null; this.ctx = null; this.proc = null; this.src = null; this.chunks = []; this.t0 = 0;
    if (!total) return { blob: new Blob([], { type: 'audio/mpeg' }), mime: 'audio/mpeg', duration: dur };
    const hasLame = await Promise.race([loadLame(), new Promise((r) => setTimeout(() => r(false), 6000))]);
    if (hasLame) { try { return { blob: encodeMp3(pcm, VOICE_RATE), mime: 'audio/mpeg', duration: dur }; } catch (_) {} }
    return { blob: encodeWav(pcm, VOICE_RATE), mime: 'audio/wav', duration: dur };
  },
};
const extOfMime = (m) => ({ 'audio/webm': 'webm', 'audio/mp4': 'm4a', 'audio/ogg': 'ogg', 'audio/aac': 'aac', 'audio/mpeg': 'mp3', 'audio/wav': 'wav', 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/heic': 'heic' }[m] || 'bin');

/* ---------- Écran de conversation (client et admin) ---------- */
function chatScreenHtml({ back, avatar, title, subtitle, actions = '', note = '' }) {
  return `<div class="chat-screen" id="chatScreen">
    <header class="chat-head">
      <a class="icon-btn chat-back" href="#${back}" aria-label="Retour">${ic('back')}</a>
      <div class="chat-avatar">${avatar}</div>
      <div class="chat-title"><strong>${title}</strong><span>${subtitle}</span></div>
      <div class="chat-actions">${actions}</div>
    </header>
    ${note}
    <div class="chat-body" id="thread" aria-live="polite"></div>
    <button type="button" class="chat-down" id="chatDown" hidden aria-label="Aller aux derniers messages">${ic('back')}</button>
    <div class="chat-context" id="chatContext" hidden></div>
    <div class="composer2" id="composer">
      <div class="attach-wrap">
        <button type="button" class="cbtn" id="attachBtn" aria-label="Joindre une photo ou un document" aria-expanded="false">${ic('clip')}</button>
        <div class="attach-menu" id="attachMenu" hidden>
          <button type="button" data-pick="pickImage"><span class="am-ic am-photo">${ic('image')}</span>Photo</button>
          <button type="button" data-pick="pickCamera"><span class="am-ic am-cam">${ic('camera')}</span>Appareil photo</button>
          <button type="button" data-pick="pickFile"><span class="am-ic am-doc">${ic('file')}</span>Document</button>
        </div>
      </div>
      <div class="cinput"><textarea id="chatInput" rows="1" maxlength="1000" placeholder="Message" aria-label="Votre message"></textarea></div>
      <button type="button" class="cbtn cmain" id="chatMain" aria-label="Enregistrer un message vocal">${ic('mic')}</button>
      <input type="file" id="pickImage" accept="image/*" hidden>
      <input type="file" id="pickCamera" accept="image/*" capture="environment" hidden>
      <input type="file" id="pickFile" accept=".pdf,.doc,.docx,.xls,.xlsx,.txt,image/*" hidden>
    </div>
    <div class="recbar" id="recBar" hidden>
      <button type="button" class="cbtn rec-cancel" id="recCancel" aria-label="Annuler l'enregistrement">${ic('trash')}</button>
      <span class="rec-dot"></span><span class="rec-time" id="recTime">0:00</span>
      <div class="rec-level" id="recLevel">${'<i></i>'.repeat(24)}</div>
      <button type="button" class="cbtn cmain" id="recSend" aria-label="Envoyer le message vocal">${ic('send')}</button>
    </div>
    <div class="attach-sheet" id="attachSheet" hidden></div>
  </div>`;
}

/* Branche toute la logique d'une conversation. send(payload) appelle la bonne fonction serveur. */
function mountChat({ clientId, me, load, send, markRead, reqLabel, emptyText, context }) {
  if (Recorder.supported()) setTimeout(loadLame, 1500); // l'encodeur MP3 est prêt avant le premier vocal
  let msgs = [];
  const thread = $('thread'), input = $('chatInput'), main = $('chatMain');
  const atBottom = () => thread.scrollHeight - thread.scrollTop - thread.clientHeight < 80;
  const toBottom = (smooth) => thread.scrollTo({ top: thread.scrollHeight, behavior: smooth ? 'smooth' : 'auto' });
  let ctx = context || null;
  const paintContext = () => {
    const el = $('chatContext');
    el.hidden = !ctx;
    if (ctx) el.innerHTML = `<span>${ic('doc', 'ic-sm')} ${esc(MSG_CATS[ctx.category] || 'Question')}${ctx.request && reqLabel(ctx.request) ? ' · ' + esc(reqLabel(ctx.request)) : ''}</span><button type="button" class="icon-btn" aria-label="Retirer" id="ctxClear">${ic('x', 'ic-sm')}</button>`;
    if (ctx) $('ctxClear').onclick = () => { ctx = null; paintContext(); };
  };
  paintContext();
  const paint = (keepScroll) => {
    const stay = keepScroll && !atBottom(); const prev = thread.scrollTop;
    thread.innerHTML = threadHtml(msgs, me, reqLabel, emptyText);
    if (stay) thread.scrollTop = prev; else toBottom(false);
  };
  const refresh = async (fromEvent) => {
    try {
      const fresh = await load();
      const pending = msgs.filter((m) => m._pending || m._failed);
      const wasBottom = atBottom();
      const newOnes = fresh.length > msgs.filter((m) => !m._pending && !m._failed).length;
      await signUrls(fresh.filter((m) => m.kind !== 'text').map((m) => m.attachment_path));
      prefetchVoices(fresh.filter((m) => m.kind === 'voice').map((m) => m.attachment_path));
      msgs = [...fresh, ...pending];
      if (!$('thread')) return;
      paint(!wasBottom);
      if (fromEvent && newOnes && !wasBottom) $('chatDown').hidden = false;
      if (fresh.some((m) => m.sender !== me && !m.read_at) && !document.hidden) markRead().then(() => { refreshMsgBadge(); }).catch(() => {});
    } catch (_) {}
  };
  _threadRefresh = () => refresh(true);

  // bouton « derniers messages »
  thread.addEventListener('scroll', () => { if (atBottom()) $('chatDown').hidden = true; }, { passive: true });
  $('chatDown').onclick = () => { toBottom(true); $('chatDown').hidden = true; };
  // lecture des vocaux, photos
  thread.addEventListener('click', (e) => {
    const v = e.target.closest('.voice');
    if (v) { if (e.target.closest('.vplay')) toggleVoice(v); else if (e.target.closest('.vwave')) seekVoice(v, e); return; }
    const im = e.target.closest('[data-img]'); if (im) openLightbox(im.dataset.img);
  });

  // zone de saisie : grandit avec le texte ; micro ↔ envoyer
  const sync = () => {
    input.style.height = 'auto'; input.style.height = Math.min(140, input.scrollHeight) + 'px';
    const has = input.value.trim().length > 0;
    main.innerHTML = ic(has ? 'send' : 'mic'); main.setAttribute('aria-label', has ? 'Envoyer' : 'Enregistrer un message vocal');
    main.classList.toggle('is-send', has);
  };
  input.addEventListener('input', sync);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !matchMedia('(pointer: coarse)').matches) { e.preventDefault(); main.click(); } });

  const deliver = async (payload) => {
    const temp = { id: 'tmp-' + Date.now() + Math.random().toString(36).slice(2, 6), sender: me, client_id: clientId, created_at: new Date().toISOString(),
      kind: payload.kind, body: payload.body || null, attachment_name: payload.name, attachment_size: payload.blob?.size, duration_ms: payload.duration,
      category: me === 'client' ? ctx?.category || 'question' : null, request_id: me === 'client' ? ctx?.request || null : null, _pending: true };
    if (payload.blob) { temp.attachment_path = 'local:' + temp.id; _signed.set(temp.attachment_path, { url: URL.createObjectURL(payload.blob), exp: Infinity }); }
    msgs.push(temp); paint(false);
    const sentCtx = ctx; if (me === 'client') { ctx = null; paintContext(); }
    try {
      let path = null;
      if (payload.blob) {
        if (payload.blob.size > MAX_FILE) throw new AppError('Fichier trop lourd (10 Mo maximum).');
        path = `${clientId}/${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}.${extOfMime(payload.mime)}`;
        const { error } = await sb.storage.from('chat').upload(path, payload.blob, { contentType: payload.mime, cacheControl: '3600', upsert: false });
        if (error) throw new AppError(/size|large|payload/i.test(error.message || '') ? 'Fichier trop lourd (10 Mo maximum).' : /mime|type/i.test(error.message || '') ? 'Type de fichier non accepté.' : "Envoi du fichier impossible. Vérifiez votre connexion.");
        _signed.set(path, { url: _signed.get(temp.attachment_path).url, exp: Date.now() + 3300e3 });
      }
      await send({ p_body: payload.body || null, p_kind: payload.kind, p_path: path, p_name: payload.name || null, p_mime: payload.mime || null,
        p_size: payload.blob ? payload.blob.size : null, p_duration: payload.duration ? Math.round(payload.duration) : null,
        p_category: sentCtx?.category || 'question', p_request: sentCtx?.request || null });
      msgs = msgs.filter((m) => m !== temp);
      await refresh(false);
      invalidateData();
    } catch (err) {
      temp._pending = false; temp._failed = true; paint(true);
      toast(err.message || "Message non envoyé.", 'error');
      if (me === 'client' && sentCtx) { ctx = sentCtx; paintContext(); }
    }
  };

  // Texte
  const sendText = () => {
    const t = input.value.trim();
    if (!t) return;
    if (me === 'client' && t.length < 2) return toast('Message trop court.', 'error');
    input.value = ''; sync(); input.focus();
    deliver({ kind: 'text', body: t });
  };

  // Vocal
  const recBar = $('recBar'), composer = $('composer');
  let recording = false;
  const recUi = (on) => { recording = on; recBar.hidden = !on; composer.hidden = on; };
  const startRec = async () => {
    if (!Recorder.supported()) return toast("Les messages vocaux ne sont pas disponibles sur ce navigateur. Mettez-le à jour ou utilisez Chrome / Safari.", 'error');
    try {
      recUi(true); $('recTime').textContent = '0:00';
      const bars = [...$('recLevel').children];
      await Recorder.start((ms, level) => {
        if (!$('recTime')) return;
        $('recTime').textContent = fmtDur(ms);
        bars.push(bars.shift()); bars.forEach((b, i) => { if (i === bars.length - 1) b.style.height = Math.max(12, level * 100) + '%'; });
        $('recLevel').append(...bars);
        if (ms >= 5 * 60 * 1000) finishRec(true);
      });
      if (navigator.vibrate) navigator.vibrate(15);
    } catch (e) {
      recUi(false);
      toast(e && (e.name === 'NotAllowedError' || e.name === 'SecurityError')
        ? "Autorisez l'accès au micro pour envoyer un message vocal (réglages du navigateur)." : "Micro indisponible sur cet appareil.", 'error');
    }
  };
  const finishRec = async (doSend) => {
    if (!recording) return;
    const r = await Recorder.stop(); recUi(false);
    if (!doSend) return;
    if (r.duration < 800 || !r.blob.size) return toast('Message vocal trop court.', 'error');
    deliver({ kind: 'voice', blob: r.blob, mime: r.mime, duration: r.duration, name: `vocal.${extOfMime(r.mime)}` });
  };
  $('recCancel').onclick = () => finishRec(false);
  $('recSend').onclick = () => finishRec(true);
  main.onclick = () => (input.value.trim() ? sendText() : startRec());

  // Photos et documents
  const menu = $('attachMenu'), attachBtn = $('attachBtn');
  const closeMenu = () => { menu.hidden = true; attachBtn.setAttribute('aria-expanded', 'false'); };
  attachBtn.onclick = (e) => { e.stopPropagation(); menu.hidden = !menu.hidden; attachBtn.setAttribute('aria-expanded', String(!menu.hidden)); };
  $('chatScreen').addEventListener('click', (e) => { if (!e.target.closest('.attach-wrap')) closeMenu(); });
  menu.querySelectorAll('[data-pick]').forEach((b) => { b.onclick = () => { closeMenu(); $(b.dataset.pick).click(); }; });
  const sheet = $('attachSheet');
  const showSheet = (file, isImage) => {
    const url = URL.createObjectURL(file);
    sheet.innerHTML = `<div class="as-card">
      <div class="as-head"><strong>${isImage ? 'Envoyer la photo' : 'Envoyer le document'}</strong><button type="button" class="icon-btn" id="asClose" aria-label="Annuler">${ic('x')}</button></div>
      ${isImage ? `<img class="as-img" src="${url}" alt="Aperçu">` : `<div class="b-file as-file"><span class="bf-icon">${esc(fileExt(file.name) || 'DOC')}</span><span class="bf-info"><span class="bf-name">${esc(file.name)}</span><span class="bf-meta">${esc(fmtSize(file.size))}</span></span></div>`}
      <div class="as-foot"><input id="asCaption" maxlength="500" placeholder="Ajouter une légende (facultatif)" aria-label="Légende"><button type="button" class="cbtn cmain is-send" id="asSend" aria-label="Envoyer">${ic('send')}</button></div>
    </div>`;
    sheet.hidden = false;
    return new Promise((resolve) => {
      $('asClose').onclick = () => { sheet.hidden = true; URL.revokeObjectURL(url); resolve(null); };
      $('asSend').onclick = () => { const c = $('asCaption').value.trim(); sheet.hidden = true; URL.revokeObjectURL(url); resolve({ caption: c }); };
    });
  };
  const onPick = async (inputEl, forceImage) => {
    const file = inputEl.files && inputEl.files[0]; inputEl.value = '';
    if (!file) return;
    const isImage = /^image\//.test(file.type) && !/heic|heif/.test(file.type);
    if (file.size > (isImage ? 25 : 10) * 1024 * 1024) return toast('Fichier trop lourd (10 Mo maximum).', 'error');
    const ext = (file.name.split('.').pop() || '').toLowerCase();
    if (!isImage && !DOC_TYPES[ext]) return toast('Format non accepté. Envoyez une photo, un PDF, un document Word ou Excel.', 'error');
    const ok = await showSheet(file, isImage);
    if (!ok) return;
    if (isImage || forceImage) {
      const c = await compressImage(file);
      if (c.blob.size > MAX_FILE) return toast('Photo trop lourde (10 Mo maximum).', 'error');
      deliver({ kind: 'image', blob: c.blob, mime: c.mime, name: file.name.replace(/\.\w+$/, '') + '.' + extOfMime(c.mime), body: ok.caption });
    } else {
      deliver({ kind: 'file', blob: file, mime: file.type || DOC_TYPES[ext], name: file.name, body: ok.caption });
    }
  };
  $('pickImage').onchange = (e) => onPick(e.target, true);
  $('pickCamera').onchange = (e) => onPick(e.target, true);
  $('pickFile').onchange = (e) => onPick(e.target, false);

  // Temps réel : nouveaux messages et accusés de lecture
  if (_chatChannel) { try { sb.removeChannel(_chatChannel); } catch (_) {} }
  let deb;
  _chatChannel = sb.channel('chat-' + clientId)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'messages', filter: `client_id=eq.${clientId}` }, () => { clearTimeout(deb); deb = setTimeout(() => refresh(true), 250); })
    .subscribe();

  sync();
  return refresh(false);
}
function leaveChat() {
  document.body.classList.remove('chat-open');
  if (_chatChannel) { try { sb.removeChannel(_chatChannel); } catch (_) {} _chatChannel = null; }
  if (Recorder.rec) Recorder.stop();
  if (_playing) { _player.pause(); _playing = null; }
  _threadRefresh = null;
}
function refreshMessages(link) {
  const h = location.hash.replace(/^#/, '');
  const inChat = (currentUser?.role === 'client' && h === '/client/messages/chat' && link.startsWith('/client/messages'))
    || (currentUser?.role === 'admin' && h === link);
  if (_threadRefresh && inChat) { _threadRefresh(); return true; }
  if (h === '/admin/messages' || h === '/client/messages') { invalidateData(); route(); }
  return false;
}

/* ---------- Client ---------- */
async function loadClientMsgs() {
  const { data } = await q(sb.from('messages').select(MSG_COLS).eq('client_id', currentUser.id).order('created_at', { ascending: true }).limit(400));
  return data || [];
}
async function renderClientMessages() {
  const paint = painter();
  const msgs = await loadClientMsgs();
  if (!paint()) return;
  const last = msgs[msgs.length - 1];
  const unread = msgs.filter((m) => m.sender === 'admin' && !m.read_at).length;
  $('content').innerHTML = `
    <div class="page-head"><div><h1 class="page-title">Messages</h1><p class="page-subtitle">Discutez avec nous par écrit, en vocal, avec photos et documents.</p></div>${urgentBtn()}</div>
    <div class="conv-list card">
      <a class="conv ${unread ? 'unread' : ''}" href="#/client/messages/chat">
        <div class="conv-avatar brand">N</div>
        <div class="conv-main"><div class="conv-top"><strong>Nexus Crédit</strong><span class="conv-time">${last ? esc(convTime(last.created_at)) : ''}</span></div>
          <div class="conv-last">${last ? (last.sender === 'client' ? `<span class="tick ${last.read_at ? 'read' : 'sent'}">${ic(last.read_at ? 'checks' : 'check', 'ic-sm')}</span>` : '') + previewOf(last) : '<span class="muted">Service client · écrivez-nous ici</span>'}</div></div>
        ${unread ? `<span class="conv-unread">${unread}</span>` : ic('chevron')}
      </a>
    </div>
    <p class="muted conv-hint">${ic('shield', 'ic-sm')} Vos messages, photos et documents ne sont visibles que par vous et Nexus Crédit.</p>`;
}
async function renderClientChat() {
  const paint = painter();
  const reqs = await listWithCache('client-list', sb.from('requests').select(LIST_COLS).eq('client_id', currentUser.id).order('created_at', { ascending: false }).limit(200)).catch(() => []);
  if (!paint()) return;
  const reqLabel = (id) => { const r = reqs.find((x) => x.id === id); return r ? `Prêt de ${fcfa(r.montant)} du ${fmtDate(r.created_at)}` : ''; };
  const pre = _msgPrefill; _msgPrefill = null;
  document.body.classList.add('chat-open');
  $('content').innerHTML = chatScreenHtml({ back: '/client/messages', avatar: '<span class="brand">N</span>', title: 'Nexus Crédit', subtitle: 'Service client', actions: urgentBtn('compact') });
  await mountChat({
    clientId: currentUser.id, me: 'client', reqLabel, context: pre,
    emptyText: 'Écrivez-nous ou envoyez un message vocal. Vous serez notifié dès que nous répondons.',
    load: loadClientMsgs,
    send: (a) => rpc('send_message', a),
    markRead: () => rpc('mark_messages_read', {}),
  });
  if (pre) $('chatInput').focus();
}

/* ---------- Admin ---------- */
const AVATAR_TINTS = ['#059669', '#2563eb', '#d97706', '#7c3aed', '#db2777', '#0891b2', '#65a30d'];
function avatarOf(name, id) {
  let h = 0; for (const c of String(id)) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  const ini = String(name || '?').trim().split(/\s+/).slice(0, 2).map((w) => w.charAt(0).toUpperCase()).join('') || '?';
  return `<div class="conv-avatar" style="--tint:${AVATAR_TINTS[h % AVATAR_TINTS.length]}">${esc(ini)}</div>`;
}
let _convFilter = 'all', _convSearch = '';
function convListHtml(convs, activeId) {
  const term = _convSearch.trim().toLowerCase();
  const rows = convs.filter((c) => (_convFilter === 'all' || c.unread) && (!term || `${c.full_name} ${c.email} ${c.phone}`.toLowerCase().includes(term)));
  if (!rows.length) return `<div class="conv-empty">${convs.length ? 'Aucune conversation ne correspond.' : 'Aucun message pour le moment. Les clients vous écrivent depuis « Messages ».'}</div>`;
  return rows.map((c) => `<a class="conv ${c.unread ? 'unread' : ''} ${c.client_id === activeId ? 'active' : ''}" href="#/admin/messages/${esc(c.client_id)}">
      ${avatarOf(c.full_name || c.email, c.client_id)}
      <div class="conv-main"><div class="conv-top"><strong>${esc(c.full_name || c.email || 'Client')}</strong>${trustBadge(c.client_id)}<span class="conv-time">${esc(convTime(c.last_at))}</span></div>
        <div class="conv-last">${c.last_sender === 'admin' ? `<span class="tick ${c.last_read ? 'read' : 'sent'}">${ic(c.last_read ? 'checks' : 'check', 'ic-sm')}</span>` : ''}${esc(c.last_body || '')}</div></div>
      ${c.unread ? `<span class="conv-unread">${c.unread}</span>` : ''}
    </a>`).join('');
}
function bindConvTools(convs, activeId) {
  const draw = () => { $('convList').innerHTML = convListHtml(convs, activeId); };
  document.querySelectorAll('[data-conv-filter]').forEach((b) => { b.onclick = () => { _convFilter = b.dataset.convFilter; document.querySelectorAll('[data-conv-filter]').forEach((x) => x.classList.toggle('active', x === b)); draw(); }; });
  $('convSearch').oninput = (e) => { _convSearch = e.target.value; draw(); };
}
function convPaneHtml(convs, activeId) {
  const unread = convs.reduce((t, c) => t + c.unread, 0);
  return `<div class="conv-pane">
    <div class="conv-tools">
      <div class="search-box">${ic('search', 'ic-sm')}<input id="convSearch" placeholder="Rechercher un client" value="${esc(_convSearch)}" aria-label="Rechercher un client"></div>
      <div class="seg"><button type="button" data-conv-filter="all" class="${_convFilter === 'all' ? 'active' : ''}">Toutes</button><button type="button" data-conv-filter="unread" class="${_convFilter === 'unread' ? 'active' : ''}">Non lues${unread ? ` (${unread})` : ''}</button></div>
    </div>
    <div class="conv-list" id="convList">${convListHtml(convs, activeId)}</div>
  </div>`;
}
async function renderAdminMessages() {
  const paint = painter();
  const [convs] = await Promise.all([rpc('admin_conversations', {}), loadScores()]);
  if (!paint()) return;
  const unread = convs.reduce((t, c) => t + c.unread, 0);
  $('content').innerHTML = `
    <div class="page-head"><div><h1 class="page-title">Messages</h1><p class="page-subtitle">${pl(convs.length, 'conversation')}${unread ? ` · <strong style="color:var(--green)">${pl(unread, 'non lu', 'non lus')}</strong>` : ''}</p></div></div>
    <div class="card conv-card">${convPaneHtml(convs, null)}</div>`;
  bindConvTools(convs, null);
}
async function renderAdminThread(clientId) {
  const paint = painter();
  const wide = matchMedia('(min-width: 1100px)').matches;
  const [profRes, reqsRes, s, convs] = await Promise.all([
    q(sb.from('profiles').select('id,full_name,email,phone,role').eq('id', clientId).maybeSingle()),
    q(sb.from('requests').select(LIST_COLS).eq('client_id', clientId).order('created_at', { ascending: false }).limit(20)),
    getSettings().catch(() => null),
    wide ? rpc('admin_conversations', {}).catch(() => []) : Promise.resolve(null),
    loadScores(),
  ]);
  if (!paint()) return;
  const prof = profRes.data;
  if (!prof || prof.role !== 'client') { toast('Client introuvable.', 'error'); return navigate('/admin/messages'); }
  const reqs = reqsRes.data || [];
  const reqLabel = (id) => { const r = reqs.find((x) => x.id === id); return r ? `Prêt de ${fcfa(r.montant)} du ${fmtDate(r.created_at)}` : ''; };
  const phone = prof.phone || reqs[0]?.telephone || '';
  const active = reqs.find((r) => ['paid', 'repayment_requested'].includes(r.status));
  const quick = [
    'Bonjour, merci pour votre message.',
    active ? `Pour rembourser maintenant, envoyez ${fcfa(amountDue(active))} sur Wave au ${fmtPhone(s?.wave_number || '')}, puis touchez « J'ai remboursé » dans votre demande.` : null,
    "C'est bien reçu, merci !",
    'Pouvez-vous m\'envoyer une photo du reçu Wave ?',
  ].filter(Boolean);
  document.body.classList.add('chat-open');
  const chat = chatScreenHtml({
    back: '/admin/messages', avatar: avatarOf(prof.full_name || prof.email, clientId).replace('class="conv-avatar"', 'class="conv-avatar sm"'),
    title: `${esc(prof.full_name || prof.email)} ${trustBadge(clientId)}`,
    subtitle: esc([phone ? fmtPhone(phone) : '', active ? `Prêt en cours · ${fcfa(amountDue(active))} dû` : reqs.length ? pl(reqs.length, 'demande') : 'Aucune demande'].filter(Boolean).join(' · ')),
    actions: `${phone ? `<a class="icon-btn" target="_blank" rel="noopener" href="${esc(waLink(phone, 'Bonjour ' + (prof.full_name || '') + ', '))}" aria-label="WhatsApp du client" title="WhatsApp du client">${ic('chat')}</a>` : ''}
      ${reqs[0] ? `<a class="icon-btn" href="#/admin/requests/${esc((active || reqs[0]).id)}" aria-label="Voir la demande" title="Voir la demande">${ic('doc')}</a>` : ''}`,
    note: `<div class="quick-replies" id="quickReplies">${quick.map((t, i) => `<button type="button" class="chip" data-quick="${i}">${esc(t.length > 42 ? t.slice(0, 40) + '…' : t)}</button>`).join('')}</div>`,
  });
  $('content').innerHTML = wide && convs ? `<div class="chat-split card">${convPaneHtml(convs, clientId)}${chat}</div>` : chat;
  if (wide && convs) bindConvTools(convs, clientId);
  document.querySelectorAll('[data-quick]').forEach((b) => { b.onclick = () => { const i = $('chatInput'); i.value = (i.value ? i.value.trimEnd() + ' ' : '') + quick[Number(b.dataset.quick)]; i.dispatchEvent(new Event('input')); i.focus(); }; });
  await mountChat({
    clientId, me: 'admin', reqLabel,
    emptyText: 'Aucun message avec ce client pour le moment.',
    load: async () => { const { data } = await q(sb.from('messages').select(MSG_COLS).eq('client_id', clientId).order('created_at', { ascending: true }).limit(400)); return data || []; },
    send: (a) => rpc('admin_reply', { p_client: clientId, p_body: a.p_body, p_kind: a.p_kind, p_path: a.p_path, p_name: a.p_name, p_mime: a.p_mime, p_size: a.p_size, p_duration: a.p_duration }),
    markRead: () => rpc('mark_messages_read', { p_client: clientId }),
  });
}

/* =====================================================================
   AIDE (questions fréquentes) ET INFORMATIONS LÉGALES
   Textes à faire relire par un juriste avant le lancement à grande échelle.
   ===================================================================== */
const FAQ = [
  ['Comment faire une demande de prêt ?', [
    "Créez votre compte, puis touchez « Faire une demande ». Choisissez le montant (de 5 000 à 500 000 FCFA) et la durée (7 ou 14 jours), indiquez le bien laissé en garantie et votre numéro de passeport, puis lisez et signez le contrat sur votre téléphone. Cela prend environ 2 minutes."]],
  ['Combien vais-je rembourser ?', [
    "Les frais sont de 25 % pour 7 jours et de 35 % pour 14 jours. Exemple : pour 50 000 FCFA sur 7 jours, vous remboursez 62 500 FCFA. Le montant exact et la date limite sont affichés avant l'envoi de votre demande et dans votre contrat."]],
  ['Pourquoi une garantie, et comment l\'envoyer ?', [
    "Le prêt est accordé contre un bien (téléphone, ordinateur…) et votre passeport. Après votre demande, l'application vous affiche l'adresse et le numéro du destinataire : vous commandez une livraison Yango depuis votre téléphone, sans vous déplacer."]],
  ['Quand vais-je recevoir l\'argent ?', [
    "Dès réception de votre garantie, l'argent est envoyé sur votre numéro Wave. Vous êtes notifié à chaque étape et votre reçu est disponible dans l'application."]],
  ['Comment rembourser ?', [
    "Envoyez le montant dû sur le numéro Wave de Nexus Crédit indiqué dans votre prêt, puis touchez « J'ai remboursé » et indiquez la référence de la transaction. Vous pouvez rembourser plus tôt, sans frais supplémentaires."]],
  ['Que se passe-t-il en cas de retard ?', [
    "Une majoration de 2 500 FCFA s'ajoute par jour de retard. À partir du 4e jour de retard, la totalité de la somme due devient exigible immédiatement, conformément au contrat. En cas de difficulté, écrivez-nous au plus tôt dans Messages."]],
  ["Pourquoi deux contacts d'urgence ?", [
    "À chaque demande, vous indiquez deux proches joignables sur WhatsApp (nom et numéro). Ils ne sont contactés qu'en cas de retard de remboursement, comme le prévoit le contrat. Prévenez-les avant d'envoyer votre demande."]],
  ['Quand vais-je récupérer ma garantie ?', [
    "Votre bien et votre passeport vous sont rendus après votre remboursement. Vous recevez une notification « Garantie restituée » et l'étape apparaît dans le suivi de votre prêt."]],
  ['Mes informations sont-elles protégées ?', [
    "Oui. Vos données sont stockées de façon sécurisée et ne sont visibles que par vous et Nexus Crédit. Vos photos, messages vocaux et documents envoyés dans la messagerie sont privés. Voir la politique de confidentialité."]],
  ['Comment nous contacter ?', [
    "Depuis votre espace, ouvrez « Messages » pour nous écrire, envoyer un message vocal, une photo ou un document. En cas d'urgence, touchez le bouton « Urgence » pour nous joindre sur WhatsApp."]],
];
const LEGAL = {
  cgu: ['Conditions d\'utilisation', [
    ['Objet', "Les présentes conditions encadrent l'utilisation de l'application Nexus Crédit, qui permet de demander un prêt de courte durée garanti par un bien et un passeport, de signer le contrat de prêt, de suivre son prêt et d'échanger avec Nexus Crédit."],
    ['Compte', "L'inscription est gratuite. Vous vous engagez à fournir des informations exactes (nom, téléphone, numéro Wave, passeport) et à garder votre mot de passe confidentiel. Un seul prêt peut être en cours à la fois."],
    ['Contrat de prêt', "Chaque prêt fait l'objet d'un contrat signé électroniquement dans l'application. Le contrat précise le montant, les frais, la date limite, les majorations de retard et les conditions de la garantie. En cas de différence, le contrat signé prévaut sur les présentes conditions."],
    ['Signature électronique', "Votre signature manuscrite tracée à l'écran, la date et l'heure, l'adresse IP, l'appareil utilisé et une empreinte numérique sont enregistrés pour prouver votre accord. Le contrat signé ne peut plus être modifié."],
    ['Garantie', "Le bien et le passeport remis en garantie sont conservés pendant la durée du prêt et rendus après remboursement complet, dans les conditions prévues au contrat."],
    ['Messagerie et urgence', "La messagerie sert aux échanges liés à votre compte et à vos prêts. Merci de rester courtois : Nexus Crédit peut limiter l'accès en cas d'abus."],
    ['Responsabilité', "Nexus Crédit met tout en œuvre pour que l'application fonctionne en continu, sans pouvoir garantir l'absence d'interruption (réseau, maintenance). Vous restez responsable de l'usage de votre téléphone et de vos identifiants."],
    ['Droit applicable', "Les présentes conditions sont soumises au droit sénégalais. En cas de litige, une solution amiable est recherchée en priorité, avant toute action devant les juridictions compétentes de Dakar."],
  ]],
  confidentialite: ['Politique de confidentialité', [
    ['Responsable', "Nexus Crédit, Gueule Tapée, Dakar, est responsable du traitement de vos données, conformément à la loi n° 2008-12 du 25 janvier 2008 sur la protection des données à caractère personnel."],
    ['Données collectées', "Nom, adresse e-mail, téléphone, numéro Wave, numéro de passeport, description du bien en garantie, nom et numéro WhatsApp de vos deux contacts d'urgence, signature et éléments de preuve de signature, historique de vos prêts et remboursements, messages, photos, messages vocaux et documents que vous nous envoyez."],
    ['Pourquoi', "Étudier et gérer vos demandes de prêt, établir et prouver le contrat, verser l'argent et suivre les remboursements, vous envoyer des rappels et notifications, répondre à vos messages, prévenir la fraude et respecter nos obligations légales. Les contacts d'urgence ne sont joints qu'en cas de retard de remboursement ; vous vous engagez à les avoir prévenus."],
    ['Qui y a accès', "Uniquement vous et Nexus Crédit. Les données sont hébergées par nos prestataires techniques (base de données Supabase, hébergement du site), qui ne les utilisent pas pour leur propre compte. Elles ne sont jamais vendues."],
    ['Durée de conservation', "Pendant la durée de votre compte, puis le temps nécessaire au respect des obligations légales et à la preuve des contrats (prescription)."],
    ['Vos droits', "Vous pouvez demander l'accès, la rectification ou la suppression de vos données, ainsi que la suppression de votre compte (sauf données à conserver légalement, par exemple un prêt en cours). Faites-en la demande depuis « Mon profil » ou dans « Messages ». Vous pouvez aussi saisir la Commission de protection des données personnelles (CDP)."],
    ['Sécurité', "Connexion chiffrée (HTTPS), accès limité à vos seules données, fichiers de la messagerie privés et liens d'accès temporaires."],
  ]],
  mentions: ['Mentions légales', [
    ['Éditeur', "Nexus Crédit, 496 rue Serigne Ousmane Mbacké Noreyni, Gueule Tapée, Dakar, Sénégal. Contact : messagerie de l'application."],
    ['Hébergement', "Site hébergé par Render (render.com). Données hébergées par Supabase (supabase.com)."],
    ['Propriété', "Le nom, le logo et les contenus de l'application Nexus Crédit sont protégés. Toute reproduction sans autorisation est interdite."],
  ]],
};
let _docBack = null;
function renderDoc(path) {
  const body = $('docBody');
  if (path === '/help') {
    body.innerHTML = `<div class="doc-head"><span class="doc-ic">${ic('shield')}</span><h1>Comment ça marche ?</h1><p>Les réponses aux questions les plus fréquentes.</p></div>
      <div class="faq">${FAQ.map(([qq, a], i) => `<details class="faq-item" ${i === 0 ? 'open' : ''}><summary>${esc(qq)}${ic('chevron')}</summary>${a.map((t) => `<p>${esc(t)}</p>`).join('')}</details>`).join('')}</div>
      <div class="doc-cta">${currentUser?.role === 'client' ? `<a class="btn btn-primary btn-xl btn-block" href="#/client/messages/chat">${ic('chat')}Poser une question</a>` : `<a class="btn btn-primary btn-xl btn-block" href="#/register">Créer mon compte</a>`}</div>
      <nav class="legal-links"><a href="#/legal/cgu">Conditions d'utilisation</a><a href="#/legal/confidentialite">Confidentialité</a><a href="#/legal/mentions">Mentions légales</a></nav>`;
  } else {
    const key = path.split('/')[2]; const [title, parts] = LEGAL[key] || LEGAL.cgu;
    body.innerHTML = `<div class="doc-head"><span class="doc-ic">${ic('doc')}</span><h1>${esc(title)}</h1><p>Dernière mise à jour : novembre 2026</p></div>
      <article class="legal-doc">${parts.map(([h, t], i) => `<section><h2>${i + 1}. ${esc(h)}</h2><p>${esc(t)}</p></section>`).join('')}</article>
      <nav class="legal-links"><a href="#/help">Aide</a>${Object.entries(LEGAL).filter(([k]) => k !== key).map(([k, [t]]) => `<a href="#/legal/${k}">${esc(t)}</a>`).join('')}</nav>`;
  }
  $('docBack').onclick = () => (history.length > 1 ? history.back() : navigate(currentUser ? homeOf(currentUser) : '/home'));
  window.scrollTo({ top: 0, behavior: 'instant' });
}

/* Mot de passe oublié */
$('forgotForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = $('forgotEmail').value.trim().toLowerCase();
  if (!EMAIL_RE.test(email)) { markField($('forgotEmail')); return showAuthError('forgotError', 'Indiquez une adresse e-mail valide.'); }
  const btn = $('forgotBtn');
  await once('forgot', async () => {
    busy(btn, true, 'Envoi…');
    try {
      const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + location.pathname });
      if (error) return showAuthError('forgotError', authErrorMessage(error));
      $('forgotTo').textContent = email; $('loginEmail').value = email; $('forgotAsk').hidden = true; $('forgotDone').hidden = false; $('forgotForm').classList.add('is-done');
    } catch (err) { showAuthError('forgotError', friendly(err)); }
    finally { busy(btn, false); }
  });
});

/* =====================================================================
   Événements globaux & démarrage
   ===================================================================== */
document.addEventListener('click', (e) => {
  const blocked = e.target.closest('[data-new-request].is-disabled');
  if (blocked) { e.preventDefault(); toast(BLOCK_MSG, 'error'); return; }
  const go = e.target.closest('[data-go]');
  if (go) { e.preventDefault(); navigate(go.dataset.go); return; }
  const pw = e.target.closest('.pw-toggle');
  if (pw) { const i = $(pw.dataset.pw); const show = i.type === 'password'; i.type = show ? 'text' : 'password'; pw.innerHTML = ic(show ? 'eye-off' : 'eye'); pw.setAttribute('aria-label', show ? 'Masquer le mot de passe' : 'Afficher le mot de passe'); return; }
  if (e.target.closest('[data-theme-toggle]')) { applyTheme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark'); return; }
  if (e.target.closest('[data-bell]')) { e.stopPropagation(); toggleNotifPanel(); return; }
  if (!e.target.closest('#notifPanel')) $('notifPanel').classList.remove('show');
  if (e.target.closest('.sb-link')) closeSidebar();
});
$('menuBtn').addEventListener('click', () => { $('sidebar').classList.add('open'); $('sidebarOverlay').classList.add('show'); });
$('sidebarOverlay').addEventListener('click', closeSidebar);
$('pdfModalClose').addEventListener('click', closeDoc);
$('pdfModal').addEventListener('click', (e) => { if (e.target.id === 'pdfModal') closeDoc(); });
$('contractClose').addEventListener('click', closeContractViewer);
$('installClose').addEventListener('click', () => $('installModal').classList.remove('show'));
$('installModal').addEventListener('click', (e) => { if (e.target.id === 'installModal') $('installModal').classList.remove('show'); });
$('contractModal').addEventListener('click', (e) => { if (e.target.id === 'contractModal') closeContractViewer(); });
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') { closeDoc(); closeContractViewer(); $('notifPanel').classList.remove('show'); } });
window.addEventListener('hashchange', route);

/* Saisie en cours : on ne recharge jamais la page sous les doigts de l'utilisateur. */
document.addEventListener('input', (e) => { const c = $('content'); if (c.contains(e.target) && e.target.id !== 'adminSearch') c.dataset.dirty = '1'; });
$('updateBtn').addEventListener('click', async () => { if ($('content').dataset.dirty === '1' && !(await askDialog({ title: 'Actualiser la page ?', message: 'Votre saisie en cours sera perdue.', confirmText: 'Actualiser', icon: 'refresh' }))) return; route(); });

/* Connexion perdue / retrouvée */
function setOnline(on) {
  $('netBanner').hidden = on;
  document.body.classList.toggle('offline', !on);
}
window.addEventListener('offline', () => setOnline(false));
window.addEventListener('online', () => {
  setOnline(true); toast('Connexion rétablie.', 'info');
  if (currentUser) { loadNotifications(); if (isEditing()) showUpdateBar(); else route(); }
});
setOnline(navigator.onLine);

/* Retour sur l'onglet (téléphone en veille…) : notifications et page à jour. */
let _hiddenAt = 0;
document.addEventListener('visibilitychange', () => {
  if (document.hidden) { _hiddenAt = Date.now(); return; }
  if (currentUser && Date.now() - _hiddenAt > 30000) { loadNotifications(); if (!isEditing()) route(); }
});

// Fonctions appelées depuis les attributs onclick
Object.assign(window, { guaranteeReturned, contactAbout, resendSms, copyText, openDoc, adminSet, markPaid, openNotif, enablePush, route, installApp, goNewRequest,
  showInstallHelp, hideInstallBanner, exportCsv });

registerSW();
loadContact();
(async () => {
  await loadProfile(true);
  if (currentUser && ['', '#/home', '#/login', '#/register'].includes(location.hash)) location.hash = '#' + homeOf(currentUser);
  else route();
})();
