import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
SUPA = '<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.119.2"></script>'
OLD_FONTS = 'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Fraunces:ital,wght@0,700;0,900;1,700&family=JetBrains+Mono:wght@500;700&display=swap'
FONTS = 'https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&display=swap'
css = open('base.css').read() + open('extra.css').read() + open('design.css').read() + open('pro.css').read() + open('v15.css').read() + open('v17.css').read(); body = open('body.html').read(); js = open('app.js').read()
import re as _re
css = _re.sub(r"'Fraunces',\s*serif", "'Manrope', system-ui, sans-serif", css)
css = _re.sub(r"'JetBrains Mono',\s*monospace", "'Manrope', system-ui, sans-serif", css)
s = open('index.html').read(); head = s[:s.index('<style>')].replace(OLD_FONTS, FONTS).replace("img-src 'self' data: blob:; worker-src", "img-src 'self' data: blob: https://qhdvrrpiqtfvppnaxelj.supabase.co; media-src 'self' blob: https://qhdvrrpiqtfvppnaxelj.supabase.co; worker-src")
head = head.replace(SUPA + '\n', '')
head = head.replace('<link rel="icon" type="image/png" sizes="32x32" href="favicon-32.png">', '<link rel="icon" type="image/svg+xml" href="'+'data:image/svg+xml,%3Csvg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"%3E%3Cdefs%3E%3ClinearGradient id="b" x1="0" y1="0" x2="1" y2="1"%3E%3Cstop offset="0" stop-color="#16406e"/%3E%3Cstop offset=".55" stop-color="#0e2a4f"/%3E%3Cstop offset="1" stop-color="#081a33"/%3E%3C/linearGradient%3E%3ClinearGradient id="n" x1="0" y1="1" x2="1" y2="0"%3E%3Cstop offset="0" stop-color="#0ea47a"/%3E%3Cstop offset="1" stop-color="#4ee6b4"/%3E%3C/linearGradient%3E%3CradialGradient id="g" cx=".85" cy=".1" r=".7"%3E%3Cstop offset="0" stop-color="#34d399" stop-opacity=".35"/%3E%3Cstop offset="1" stop-color="#34d399" stop-opacity="0"/%3E%3C/radialGradient%3E%3C/defs%3E%3Crect width="512" height="512" rx="116" fill="url%28#b%29"/%3E%3Crect width="512" height="512" rx="116" fill="url%28#g%29"/%3E%3Cpath d="M150 372V146l212 220V140" fill="none" stroke="url%28#n%29" stroke-width="56" stroke-linecap="round" stroke-linejoin="round"/%3E%3Ccircle cx="362" cy="140" r="34" fill="#e9c25a"/%3E%3C/svg%3E%0A'+'">\n<link rel="icon" type="image/png" sizes="32x32" href="favicon-32.png">') if 'image/svg+xml' not in head else head
head = head.replace('<meta name="theme-color" content="#070b08">', '<meta name="theme-color" content="#0b1f3a">')
# Polices chargées sans bloquer l'affichage (le texte s'affiche tout de suite avec la police du système)
head = head.replace(f'<link href="{FONTS}" rel="stylesheet">',
    f'<link rel="preload" as="style" href="{FONTS}" onload="this.onload=null;this.rel=\'stylesheet\'">\n<noscript><link rel="stylesheet" href="{FONTS}"></noscript>')
head = head.replace('<link rel="preconnect" href="https://qhdvrrpiqtfvppnaxelj.supabase.co" crossorigin>',
    '<link rel="preconnect" href="https://qhdvrrpiqtfvppnaxelj.supabase.co" crossorigin>\n<link rel="preconnect" href="https://cdn.jsdelivr.net">\n<link rel="preload" as="script" href="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2.119.2">') if 'cdn.jsdelivr.net">' not in head else head
BOOT = '<script>try{var h=location.hash;if((!h||h==="#/home"||h==="#/")&&!Object.keys(localStorage).some(function(k){return /^sb-.*-auth-token$/.test(k)}))document.documentElement.classList.add("boot-home")}catch(e){}</script>\n'
if 'boot-home' not in head: head = head.replace('<meta charset="UTF-8">\n', '<meta charset="UTF-8">\n' + BOOT, 1)
# Minification (le code source reste lisible dans app.js / *.css ; seul index.html est compacté)
import subprocess, os
open('/tmp/_app.js', 'w').write(js); open('/tmp/_app.css', 'w').write(css)
subprocess.run(['terser', '/tmp/_app.js', '-c', 'passes=2,drop_debugger=true', '-m', '--ecma', '2020', '--comments', 'false', '-o', '/tmp/_app.min.js'], check=True)
subprocess.run(['csso', '/tmp/_app.css', '-o', '/tmp/_app.min.css', '--no-restructure'], check=True)
js = open('/tmp/_app.min.js').read(); css = open('/tmp/_app.min.css').read()
body = '\n'.join(l.strip() for l in body.split('\n') if l.strip())
open('index.html', 'w').write(head + '<style>' + css + '</style>\n</head>\n<body>\n' + body + '\n' + SUPA + '\n<script>\n' + js + '\n</script>\n</body>\n</html>\n')
print('ok', len(open('index.html').read()))
