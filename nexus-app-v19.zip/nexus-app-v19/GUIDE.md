# Nexus Crédit — version 19

## Mise à jour v19 (déconnexion, rapidité, nouveau logo)
**Pas de script SQL cette fois** (si vous avez bien collé le correctif de la v18).
1. **GitHub** : remplacez `index.html`, `sw.js` et `manifest.json` (copier / coller).
2. **GitHub → Add file → Upload files** : glissez les **10 icônes** ci-dessous (elles remplacent les anciennes, gardez exactement les mêmes noms) :
   `icon-192.png`, `icon-512.png`, `icon-maskable-192.png`, `icon-maskable-512.png`,
   `apple-touch-icon.png`, `apple-touch-icon-167.png`, `apple-touch-icon-152.png`, `apple-touch-icon-120.png`,
   `favicon-32.png`, `favicon-16.png`.
   Vérification : ouvrez https://nexus-credit.onrender.com/icon-512.png → le nouveau logo doit s'afficher.
3. Sur les téléphones : touchez **Actualiser** quand la barre de mise à jour apparaît.
4. **Pour voir la nouvelle icône sur l'écran d'accueil**, il faut réinstaller l'appli (le téléphone garde l'ancienne icône en mémoire) :
   - iPhone : appui long sur l'icône → Supprimer l'app → rouvrir le site dans Safari → Partager → « Sur l'écran d'accueil ».
   - Android : appui long → Désinstaller → rouvrir le site dans Chrome → « Installer l'application ».


## Mise à jour v18 (preuve de versement Wave + vitesse)
1. **Supabase → SQL Editor** : collez **tout** `supabase/nexus_v18.sql`, puis **Run** (« Success »). **Obligatoire.**
   Il ajoute la preuve de versement, le départ de l'échéance à la consultation de la preuve et la version C du contrat.
   Faites-le **juste avant** de remplacer les fichiers sur GitHub (l'ancien site n'est plus accepté par la base après le script).
2. **GitHub** : remplacez `index.html` et `sw.js`.
3. Sur les téléphones : touchez **Actualiser** quand la barre de mise à jour apparaît.

### Comment ça marche
- Envoyez l'argent depuis votre appli Wave, faites une **capture d'écran du reçu**, puis touchez **« Marquer comme payé »** dans Nexus Crédit et joignez la capture (obligatoire). Sur ordinateur, vous pouvez aussi la glisser ou la coller (Ctrl+V).
- Le client reçoit « 💸 Votre argent a été envoyé » ; en ouvrant l'appli, il voit le reçu en grand et peut le télécharger.
- **Échéance** : elle démarre au moment où le client voit la capture (ex. vue le 26/11 → 7 jours → avant le 03/12). S'il ne l'ouvre pas, elle démarre **automatiquement 24 h après le versement**. Le détail admin indique si la preuve a été vue.
- Le contrat (section 5) a été mis à jour en conséquence : version NXC-CONTRAT-2026-11-C. **À faire relire par un juriste.**


## Mise à jour v17 (contacts d'urgence + nouveau design « Nuit & Émeraude »)
1. **Supabase → SQL Editor** : collez **tout** `supabase/nexus_v17.sql`, puis **Run** (« Success »). **Obligatoire** :
   il ajoute les 4 colonnes des contacts d'urgence, les contrôles côté serveur et la nouvelle version du contrat (NXC-CONTRAT-2026-11-B).
   Faites-le **en même temps** que la mise en ligne du site : l'ancien site n'est plus accepté par la base après le script, et inversement.
2. **GitHub** : remplacez `index.html`, `sw.js` et `manifest.json`.
3. **GitHub → Upload files** : envoyez les 5 nouvelles icônes (`icon-192.png`, `icon-512.png`, `icon-maskable-512.png`, `apple-touch-icon.png`, `favicon-32.png`).
4. Sur les téléphones : touchez **Actualiser** quand la barre de mise à jour apparaît.

Les anciennes demandes n'ont pas de contacts d'urgence : la fiche admin l'indique (« Non renseignés »).
Chaque nouvelle demande en exige deux ; ils sont repris automatiquement à la demande suivante du même client.


## Mise à jour v16 (messages vocaux réparés)
1. **GitHub** : remplacez `index.html` et `sw.js` (copier / coller). C'est tout : la base de données ne change pas.
2. Render redéploie tout seul. Sur chaque téléphone, touchez **Actualiser** quand la barre « Nouvelle version disponible » apparaît.
3. Vérification facultative dans Supabase → SQL Editor : `select allowed_mime_types from storage.buckets where id = 'chat';`
   La liste doit contenir `audio/mpeg`. Si ce n'est pas le cas, relancez `supabase/nexus_v15.sql` (sans risque).

Les messages vocaux sont maintenant enregistrés en **MP3** sur tous les appareils (Android, iPhone, ordinateur) et se lisent partout.
Les anciens vocaux enregistrés en WebM depuis Android restent lisibles sur Android et sur ordinateur. Sur un iPhone qui ne lit pas ce format, un message clair l'explique.


## Mise à jour v15 : ce qu'il faut faire (10 minutes)
1. **Supabase → SQL Editor** : collez **tout** `supabase/nexus_v15.sql`, puis **Run**. Vous devez voir « Success ». Obligatoire : il ajoute la « restitution de la garantie ». Il se relance sans risque.
2. **GitHub** : remplacez `index.html`, `sw.js` et `manifest.json` (copier / coller comme d'habitude).
3. **GitHub → Add file → Upload files** : glissez les 5 nouvelles icônes `icon-192.png`, `icon-512.png`, `icon-maskable-512.png`, `apple-touch-icon.png`, `favicon-32.png` (elles remplacent les anciennes). Facultatif, mais sinon l'icône du téléphone garde l'ancien logo.
4. **Supabase → Authentication → Emails** : collez les e-mails en français de `supabase/emails_fr.md` (une seule fois).
5. Render redéploie tout seul. Sur le téléphone, la barre « Nouvelle version disponible » apparaît : touchez **Actualiser**.

Sur iPhone, l'icône de l'écran d'accueil ne change que si le client supprime l'appli de l'écran d'accueil et l'ajoute à nouveau. Le contenu, lui, se met à jour tout seul.

## Nouveautés v15
- Nouvelle palette « confiance » (émeraude-sarcelle et bleu nuit), fonds en dégradés doux, nouveau logo et nouvelles icônes.
- Plus aucun émoji dans l'interface : icônes vectorielles partout (vos messages et ceux des clients gardent leurs émojis).
- Écran « Mot de passe oublié », pages Aide (questions fréquentes), Conditions d'utilisation, Confidentialité, Mentions légales. **Faites relire ces textes par un juriste.**
- Fenêtres de confirmation de l'appli à la place des fenêtres grises du navigateur ; refus avec motif obligatoire et motifs rapides.
- **Garantie restituée** : sur une demande remboursée (ou refusée après réception de la garantie), bouton « Garantie restituée ». Le client est notifié et l'étape apparaît dans son suivi.
- Profil avec en-tête, téléphone formaté, Aide, confidentialité et demande de suppression de compte (elle arrive dans vos Messages).
- Étape garantie en un seul champ (numéro Wave), boutons « Copier » compacts, demandes en cartes compactes sur téléphone.


## 1. Base de données (obligatoire)
Dans Supabase, ouvrez **SQL Editor**, effacez le contenu, collez **tout** `supabase/nexus_v15.sql`, puis cliquez sur **Run**. Vous devez voir « Success ».
Ce script est complet : il remplace les versions v4 à v14 et se lance sans risque par-dessus.

## 2. Site (obligatoire)
Mettez en ligne **tous** les fichiers dans le même dossier :
`index.html`, `sw.js`, `manifest.json`, `icon-192.png`, `icon-512.png`, `icon-maskable-512.png`, `apple-touch-icon.png`, `favicon-32.png`.

- Le site doit être en **https** (c'est le cas sur Netlify, Vercel, GitHub Pages…). Sans https, l'installation et les notifications ne marchent pas.
- `sw.js` doit être **à côté** de `index.html`, pas dans un sous-dossier.
- Faites ensuite **Ctrl + F5**. Pour les prochaines mises à jour, les clients verront « Nouvelle version disponible → Mettre à jour ».

## 3. Comment vos clients installent l'application
- **Android (Chrome)** : la bannière « Installez l'application Nexus Crédit » apparaît sur l'accueil. Le client touche **Installer**, et l'icône arrive sur son écran.
- **iPhone** : il doit ouvrir le site dans **Safari**, toucher **Partager ⬆︎**, puis **« Sur l'écran d'accueil »** et **Ajouter**. La bannière lui montre ces étapes. S'il est dans Chrome sur iPhone, elle lui dit d'ouvrir Safari.
- Une fois installée, l'appli s'ouvre en plein écran avec le logo, sans barre d'adresse.
- Le bouton « Installer » est aussi dans **Mon profil**.

## 4. Notifications même appli fermée (facultatif, recommandé)
Sans cette étape, les notifications marchent tant que l'appli est ouverte. Avec elle, le téléphone sonne même appli fermée.
Toutes les commandes se tapent dans le terminal, dans le dossier du projet.

1. Générer les clés : `npx web-push generate-vapid-keys`
   Vous obtenez une **Public Key** et une **Private Key**. Ne collez jamais la Private Key dans le site ni dans une discussion.
2. Choisir un mot de passe long pour `PUSH_SECRET` (par exemple 40 lettres et chiffres au hasard).
3. Enregistrer les secrets :
   `npx supabase secrets set VAPID_PUBLIC_KEY=... VAPID_PRIVATE_KEY=... VAPID_SUBJECT=mailto:votre@email.com PUSH_SECRET=...`
4. Déployer la fonction : `npx supabase functions deploy send-push --no-verify-jwt`
5. Dans Supabase → **Database → Extensions**, activez **pg_net**.
6. Dans **SQL Editor**, lancez (remplacez `VOTRE_PUSH_SECRET` par le même mot de passe qu'à l'étape 2) :
   ```sql
   insert into private.push_config (id, function_url, secret)
   values (1, 'https://qhdvrrpiqtfvppnaxelj.supabase.co/functions/v1/send-push', 'VOTRE_PUSH_SECRET')
   on conflict (id) do update set function_url = excluded.function_url, secret = excluded.secret;
   ```
7. Dans l'appli, connecté en admin : **Paramètres → Clé publique VAPID**, collez la **Public Key**, puis **Enregistrer**.
8. Chaque utilisateur active ensuite les notifications (cloche 🔔 ou Mon profil).

**iPhone** : les notifications ne marchent que si l'appli est **installée** sur l'écran d'accueil, avec **iOS 16.4 ou plus récent**, et activées depuis l'appli installée.

## 5. Rappels SMS automatiques (Orange SMS API Sénégal)
Sans cette étape, tout le reste marche ; les SMS restent simplement « en attente ».

**Coût** : forfaits Orange payés avec votre crédit ou Orange Money, par exemple 100 SMS pour 2 000 FCFA, 1 000 SMS pour 12 000 FCFA. Un prêt utilise au maximum 5 SMS (argent envoyé, J-2, jour J, retard, retard de plus de 3 jours), souvent 2 ou 3.

1. Créez un compte sur **developer.orange.com** (il faut une puce Orange Sénégal).
2. **My Apps → Create a new app**, puis ajoutez l'API **« SMS Senegal »** et achetez un forfait (**Configure**).
3. Dans votre application, copiez le **Client ID** et le **Client Secret**. Ne les collez jamais dans le site ni dans une discussion.
4. Choisissez un mot de passe long pour `SMS_SECRET`, puis dans le terminal :
   `npx supabase secrets set SMS_SECRET=... ORANGE_CLIENT_ID=... ORANGE_CLIENT_SECRET=...`
5. Déployez la fonction : `npx supabase functions deploy send-sms --no-verify-jwt`
   Si le terminal refuse (erreur 403), créez-la dans Supabase → **Edge Functions → Deploy a new function → Via Editor**, nommez-la `send-sms`, collez le contenu de `supabase/functions/send-sms/index.ts`, déployez, puis désactivez **Verify JWT** dans ses réglages.
6. Vérifiez que **pg_net** est activé (Database → Extensions).
7. Dans **SQL Editor** (remplacez `VOTRE_SMS_SECRET` par le mot de passe de l'étape 4) :
   ```sql
   insert into private.sms_config (id, function_url, secret)
   values (1, 'https://qhdvrrpiqtfvppnaxelj.supabase.co/functions/v1/send-sms', 'VOTRE_SMS_SECRET')
   on conflict (id) do update set function_url = excluded.function_url, secret = excluded.secret;
   ```
8. Dans l'appli : **Paramètres → Tester l'envoi de SMS** avec votre numéro. Quand le SMS arrive, cochez **« Envoyer les SMS automatiquement »** et enregistrez.

- Les rappels partent chaque matin à 8 h (pg_cron activé), ou à l'ouverture du tableau de bord admin.
- **Nom d'expéditeur** : sans nom validé par Orange, les SMS arrivent avec le nom par défaut de votre compte. Pour afficher « NEXUSCREDIT », demandez sa validation dans votre application Orange, puis saisissez-le dans Paramètres.
- Un SMS en échec (forfait épuisé, numéro faux) apparaît en rouge dans Paramètres et dans la demande, avec un bouton **Renvoyer**.
- Autre fournisseur possible : Twilio (plus cher, environ 0,55 $ par SMS vers le Sénégal). Ajoutez `SMS_PROVIDER=twilio TWILIO_ACCOUNT_SID=... TWILIO_AUTH_TOKEN=... TWILIO_FROM=...` aux secrets.

## Nouvelle interface (refonte complète du design)
- La base de données ne change pas : inutile de relancer le script SQL si la v12 (ou `nexus_final.sql`) est déjà installée.
- **Tout tient dans l'écran** : accueil, connexion, inscription, demande de prêt, tableau de bord, messages et tableau de bord admin. 228 éléments essentiels vérifiés sur 5 tailles de téléphone + ordinateur : 228 visibles sans défiler (137 avant).
- **Accueil, connexion, inscription** : logo mis en avant, fond dégradé, grands champs arrondis avec icônes, œil pour afficher le mot de passe, gros boutons toujours sous le pouce.
- **Barre du bas** : Accueil · Mes prêts · Messages · Profil.
- **Demande en 3 clics** : « Faire une demande » → « Continuer » → « Envoyer ma demande ». Étape 1 : montant (curseur), durée, total, garantie. Étape 2 : contrat (à faire défiler ou en plein écran), case « J'ai lu et j'accepte les conditions du contrat », signature.
- **États vides illustrés** : un client sans prêt voit une illustration et un bouton « Faire ma première demande ».
- **Admin** : chiffres clés en grand avec icônes, cartes cliquables.
- Transitions douces entre les pages, effet au toucher sur les boutons, petite vibration sur Android à la validation.

## Version finale (vérification complète)
- La base de données ne change pas par rapport à la v12 : si vous avez déjà lancé le script v12, inutile de relancer. `nexus_final.sql` est le même script (complet, relançable sans risque).
- Parcours testé de bout en bout (inscription → remboursement) sur petit Android, grand iPhone et ordinateur ; affichage vérifié sur 6 tailles d'écran (320 px à 1920 px) : aucun débordement, aucun texte coupé, aucun bouton caché.
- Écran de chargement élégant, suivi du statut en ligne de progression, icônes nettes dans tous les boutons, notifications à l'écran plus claires, boutons avec indicateur de chargement.
- Code compacté (minifié) : la page pèse 68 Ko compressée. Sur connexion lente, l'accueil s'affiche en moins d'une seconde ; ensuite l'application s'ouvre instantanément depuis le téléphone.

## Nouveautés v12
- **Nouveau design** : une seule police moderne (Manrope), icônes vectorielles nettes à la place des émojis dans les menus et les titres, couleurs émeraude et ambre harmonisées en mode clair et sombre, ombres et arrondis cohérents, animations douces (désactivées si le téléphone demande moins d'animations). Une police en moins à télécharger : chargement plus rapide.
- **Messagerie complète** (menu **Messages**) :
  - liste des conversations, puis discussion en bulles façon WhatsApp, avec l'heure de chaque message ;
  - **✓ envoyé**, **✓✓ lu** (bleu) ;
  - **messages vocaux** : touchez le micro, parlez, puis la flèche pour envoyer (la poubelle annule) ; lecture avec barre de progression ; 5 minutes maximum ;
  - **photos** (galerie ou appareil photo, compressées automatiquement) et **documents** (PDF, Word, Excel), avec aperçu et légende avant l'envoi ; 10 Mo maximum ;
  - sur téléphone, la conversation s'ouvre en plein écran ;
  - côté admin : conversations non lues en haut, recherche, filtre « Non lues », réponses rapides, et sur ordinateur la liste et la conversation côte à côte ;
  - notification à chaque nouveau message (dans l'appli et, si configuré, sur le téléphone appli fermée) ; quand la conversation est ouverte, le message s'affiche directement ;
  - les fichiers sont privés : seuls le client concerné et vous pouvez les ouvrir.
- **Coordonnées retirées** : plus de numéro, de bouton WhatsApp ni de bouton « Appeler » dans l'appli. Seul le **numéro Wave de paiement** reste affiché dans l'étape « Rembourser », car le client en a besoin pour payer.
- **Bouton « Urgence »** (en haut de l'écran sur téléphone, en bas du menu sur ordinateur, et dans Messages) : ouvre directement WhatsApp vers le 78 664 90 62, sans afficher le numéro. Modifiable dans **Paramètres → Bouton « Urgence »**.
- Le script SQL crée tout seul l'espace de stockage privé « chat » et active le temps réel des messages.
- Messages vocaux : Chrome sur Android et ordinateur, Safari sur iPhone (iOS 14.3 ou plus récent). Le navigateur demande l'autorisation du micro la première fois.

## Nouveautés v11
- **Vos coordonnées partout** : un bouton vert 💬 en bas à droite de toutes les pages (accueil et espace client) ouvre « Écrire sur WhatsApp » (la discussion s'ouvre directement avec votre numéro) et « Appeler ». Elles sont aussi affichées en bas de l'accueil et du tableau de bord client.
- Numéro WhatsApp, numéro d'appel et horaires se modifient dans **Paramètres → Vos coordonnées**. WhatsApp : 78 664 90 62 ; appels : 78 632 52 75.
- **Messagerie dans l'appli** (menu **💬 Messages**) :
  - le client choisit un sujet (question, problème, remboursement anticipé, autre) et peut indiquer le prêt concerné ;
  - dans le détail d'un prêt versé, le bouton **« Rembourser plus tôt »** ouvre la messagerie avec le bon sujet ;
  - vous êtes notifié de chaque message ; une pastille rouge indique les messages non lus ;
  - vous répondez depuis **Messages** (réponses rapides proposées, dont le montant exact à envoyer sur Wave) ;
  - le client reçoit une notification « 💬 Réponse de Nexus Crédit » (aussi appli fermée si les notifications push sont configurées) ;
  - le client voit quand vous avez lu ses messages (✓✓ lu).
- Si vous utilisez les notifications push (section 4), redéployez la fonction : `npx supabase functions deploy send-push --no-verify-jwt` (elle ouvre maintenant directement la conversation).

## Nouveautés v10
- **Plus rapide** : la page d'accueil s'affiche immédiatement, même sur une connexion lente (le texte n'attend plus les polices ni la bibliothèque Supabase). Les listes déjà vues se réaffichent instantanément puis se mettent à jour seules. La liste admin affiche 50 demandes à la fois (« Afficher plus »), la recherche porte sur toutes. Nouveaux index dans la base pour les listes et les rappels.
- **Badge de fiabilité** à côté de chaque client (liste, tableau de bord, échéancier, détail) :
  🟢 **Fiable** (tous ses prêts remboursés à l'heure) · 🟠 **Nouveau** (aucun prêt remboursé) · 🟠 **À surveiller** (1 retard) · 🔴 **Risqué** (en retard maintenant, 2 retards ou plus, ou un retard de plus de 3 jours). Passez le doigt ou la souris dessus pour l'explication.
- **Rappels SMS automatiques** (section 5).
- **Signature renforcée** :
  - tracé fluide au doigt, au stylet ou à la souris ; la page ne défile plus pendant la signature ;
  - un point ou un petit trait est refusé ;
  - la signature apparaît en bas du contrat avant l'envoi ;
  - le serveur enregistre la date et l'heure exactes, l'adresse IP, l'appareil et une **empreinte SHA-256** de la signature ;
  - signature et contrat ne peuvent plus être modifiés après l'envoi, même par erreur ;
  - le PDF du contrat contient un encadré « Preuve de signature électronique » ;
  - dans le détail d'une demande, **« Afficher et vérifier la signature »** confirme qu'elle est intacte.
  Les demandes envoyées avant la v10 n'ont pas d'empreinte : la vérification l'indique.

## Nouveautés v9
- **Application installable** sur Android et iPhone, avec bannière d'aide adaptée au téléphone.
- **Hors connexion** : l'appli s'ouvre quand même et affiche les dernières données consultées, avec un message « données hors connexion ». Les actions (demande, paiement…) attendent le retour du réseau.
- **Calculatrice de prêt** sur l'accueil : montant, 7 ou 14 jours, frais, total à rembourser, date butoir, rappel des majorations.
- **Historique client** (Mes demandes) : total emprunté, prêts remboursés, pourcentage remboursé à l'heure.
- **Note de satisfaction** de 1 à 5 étoiles après remboursement. L'admin est notifié.
- **Statistiques admin** (menu Statistiques) : montant prêté, encaissé, frais gagnés, encours, taux de remboursement, clients en retard, satisfaction, graphique sur 6 mois.
- **Fiche de fiabilité** dans le détail d'une demande : historique du client, retards, refus.
- **Export Excel (CSV)** de toutes les demandes, depuis Statistiques.

## Modifier le texte du contrat plus tard
Le texte se trouve dans `index.html`, dans la constante `CONTRACT`. Si vous le changez, changez aussi `CONTRACT_VERSION` (par exemple `NXC-CONTRAT-2027-01`) et la même valeur dans le script SQL (`'NXC-CONTRAT-2026-11'`). Sinon, les nouvelles demandes seront refusées.
